import { DurableObject } from 'cloudflare:workers';
import * as E from '../public/lib/engine.js';
import * as AI from '../public/lib/ai.js';
import * as L from '../public/lib/lives.js';
import * as RT from '../public/lib/rating.js';
export { Hub } from './hub.js';
export { Community } from './community.js';

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const CLEANUP_AFTER = 7 * 24 * 3600 * 1000; // stanze ferme da 7 giorni vengono cancellate
const EMPTY_CLOSE = 5 * 60 * 1000; // stanza senza nessuno collegato da 5 minuti: si chiude
const HOST_TAKEOVER_AFTER = 60_000;
const CHAT_KEEP = 150;
const MAX_AVATAR = 80_000; // byte della foto (già rimpicciolita dall'app)
const LEVELS = ['facile', 'medio', 'difficile'];

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });

function randomId(bytes = 6) {
  const a = crypto.getRandomValues(new Uint8Array(bytes));
  return [...a].map((b) => b.toString(16).padStart(2, '0')).join('');
}
function randomCode() {
  const a = crypto.getRandomValues(new Uint8Array(5));
  return [...a].map((b) => CODE_CHARS[b % CODE_CHARS.length]).join('');
}
const rng = () => crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296;
const archive = (env) => env.ARCHIVE.get(env.ARCHIVE.idFromName('archivio'));
const hub = (env) => env.HUB.get(env.HUB.idFromName('hub'));
// verifica la sessione dell'account (null se non c'è o è scaduta)
async function sessionUser(env, token) {
  if (!token) return null;
  const r = await hub(env).fetch('https://h/internal/session', { method: 'POST', body: JSON.stringify({ token }) });
  return r.ok ? r.json() : null;
}

// ---------------------------------------------------------------- Worker (instradamento)

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const parts = url.pathname.split('/').filter(Boolean);
    if (parts[0] !== 'api') return env.ASSETS.fetch(request);
    try {
      if (parts[1] === 'ping') return json({ ok: true });
      if (parts[1] === 'records' && request.method === 'POST') return archive(env).fetch('https://a/put', { method: 'POST', body: await request.text() });
      if (parts[1] === 'profiles') return archive(env).fetch('https://a/profiles');
      if (parts[1] === 'event' && request.method === 'POST') return archive(env).fetch('https://a/event', { method: 'POST', body: await request.text() });
      // pannello admin: con la chiave, oppure con la sessione di un account abilitato
      const keyOk = async () => {
        if (env.STATS_KEY && (url.searchParams.get('key') || request.headers.get('x-key')) === env.STATS_KEY) return true;
        const s = url.searchParams.get('session') || request.headers.get('x-session');
        if (!s) return false;
        const r = await hub(env).fetch('https://h/internal/isadmin', { method: 'POST', body: JSON.stringify({ token: s }) });
        return r.ok;
      };
      if (parts[1] === 'stats') {
        if (!(await keyOk())) return json({ error: 'Chiave sbagliata' }, 403);
        return archive(env).fetch('https://a/stats');
      }
      // avatar: elenco pubblico (solo quelli visibili) e immagini, con cache lunga
      if (parts[1] === 'avatars' && parts[2] === 'img' && parts[3]) {
        const cache = caches.default;
        const hit = await cache.match(request);
        if (hit) return hit;
        const res = await archive(env).fetch(`https://a/avatar-img?id=${encodeURIComponent(parts[3])}&kind=${parts[4] === 'full' ? 'full' : 'circle'}`);
        if (res.ok) await cache.put(request, res.clone());
        return res;
      }
      if (parts[1] === 'avatars') return archive(env).fetch('https://a/avatars');
      if (parts[1] === 'admin') {
        if (!(await keyOk())) return json({ error: 'Chiave sbagliata' }, 403);
        if (parts[2] === 'avatars' && request.method === 'POST') return archive(env).fetch('https://a/admin-avatars', { method: 'POST', body: await request.text() });
        if (parts[2] === 'hub' && request.method === 'POST') return hub(env).fetch('https://h/admin', { method: 'POST', body: await request.text() });
        if (parts[2] === 'backup') {
          const day = new Date().toISOString().slice(0, 10);
          return new Response(await makeBackup(env), { headers: { 'content-type': 'application/json', 'content-disposition': `attachment; filename="bisca-backup-${day}.json"`, 'cache-control': 'no-store' } });
        }
        // backup automatici (uno a settimana, si tengono gli ultimi 6)
        if (parts[2] === 'backups') {
          const v = vault(env);
          if (parts[3]) {
            const res = await v.fetch(`https://v/get?id=${encodeURIComponent(parts[3])}`);
            if (!res.ok) return json({ error: 'Non trovato' }, 404);
            return new Response(res.body, { headers: { 'content-type': 'application/json', 'content-disposition': `attachment; filename="bisca-backup-${parts[3]}.json"`, 'cache-control': 'no-store' } });
          }
          if (request.method === 'POST') { await v.fetch('https://v/put', { method: 'POST', body: await makeBackup(env) }); }
          return v.fetch('https://v/list');
        }
        if (parts[2] === 'avatars') return archive(env).fetch('https://a/avatars?all=1');
        return json({ error: 'Non trovato' }, 404);
      }
      // partite in corso e stanze in attesa, per gli spettatori
      if (parts[1] === 'live') return archive(env).fetch('https://a/live');
      // segnavite per le partite dal vivo
      if (parts[1] === 'lives' && parts.length === 2 && request.method === 'POST') {
        const body = await request.text();
        for (let i = 0; i < 6; i++) {
          const code = randomCode();
          const res = await env.LIVES.get(env.LIVES.idFromName(code)).fetch(`https://do/init?code=${code}`, { method: 'POST', body });
          if (res.status !== 409) return res;
        }
        return json({ error: 'Riprova' }, 500);
      }
      if (parts[1] === 'lives' && parts[2]) {
        const code = parts[2].toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        const target = new URL(`https://do/${parts[3] || 'info'}`);
        target.search = url.search;
        return env.LIVES.get(env.LIVES.idFromName(code)).fetch(new Request(target, request));
      }
      // account: tutte le operazioni passano dall'Hub
      if (parts[1] === 'u' && parts.length === 2 && request.method === 'POST') {
        return hub(env).fetch('https://h/rpc', { method: 'POST', body: await request.text(), headers: { 'x-origin': url.origin } });
      }
      // foto profilo degli account e loghi delle community (con versione nell'indirizzo: cache lunga)
      if ((parts[1] === 'uphoto' || parts[1] === 'clogo') && parts[2]) {
        return hub(env).fetch(`https://h/${parts[1] === 'uphoto' ? 'photo' : 'logo'}?id=${encodeURIComponent(parts[2].slice(0, 40))}`);
      }
      // file degli oggetti (dorsi, emote, emote personali): con versione nell'indirizzo, cache lunga
      if (parts[1] === 'asset' && parts[2]) return hub(env).fetch(`https://h/asset?id=${encodeURIComponent(parts[2].slice(0, 80))}`);
      if (parts[1] === 'u' && parts[2] === 'ws') {
        const target = new URL('https://h/ws'); target.search = url.search; target.searchParams.set('upgrade', request.headers.get('Upgrade') === 'websocket' ? '1' : '0');
        return hub(env).fetch(new Request(target, request));
      }
      // chat delle community: il worker controlla l'account, la community controlla che sia un membro
      if (parts[1] === 'c' && parts[2] && (parts[3] === 'ws' || parts[3] === 'history' || parts[3] === 'audio')) {
        const cid = parts[2].toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        const r = await hub(env).fetch('https://h/internal/member', { method: 'POST', body: JSON.stringify({ token: url.searchParams.get('token'), cid }) });
        if (!r.ok) return json({ error: 'Accedi di nuovo' }, 401);
        const u = await r.json();
        if (!u.role) return json({ error: 'Non sei in questa community' }, 403);
        const target = new URL(`https://c/${parts[3]}`); target.search = url.search; target.searchParams.delete('token');
        const req = new Request(target, request);
        const headers = new Headers(req.headers); headers.set('x-user', JSON.stringify({ id: u.id, username: u.username, avatar: u.avatar }));
        return env.COMM.get(env.COMM.idFromName(cid)).fetch(new Request(target, { method: req.method, headers }));
      }
      if (parts[1] === 'games' && parts.length === 2 && request.method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const user = await sessionUser(env, body.session);
        if (!user) return json({ error: 'Per giocare online serve un account: accedi o registrati', auth: false }, 401);
        for (let i = 0; i < 6; i++) {
          const code = randomCode();
          const stub = env.GAME.get(env.GAME.idFromName(code));
          const res = await stub.fetch('https://do/init', { method: 'POST', body: JSON.stringify({ code, name: user.username, device: body.device, pick: user.avatar, user }) });
          if (res.status !== 409) return res;
        }
        return json({ error: 'Riprova' }, 500);
      }
      if (parts[1] === 'games' && parts[2] && parts[3] === 'join' && request.method === 'POST') {
        const code = parts[2].toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        const body = await request.json().catch(() => ({}));
        const user = await sessionUser(env, body.session);
        if (body.as !== 'spectator' && !user) return json({ error: 'Per giocare online serve un account: accedi o registrati', auth: false }, 401);
        if (user) Object.assign(body, { user, name: user.username, pick: user.avatar });
        delete body.session;
        return env.GAME.get(env.GAME.idFromName(code)).fetch('https://do/join', { method: 'POST', body: JSON.stringify(body) });
      }
      if (parts[1] === 'games' && parts[2]) {
        const code = parts[2].toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        const stub = env.GAME.get(env.GAME.idFromName(code));
        const target = new URL(`https://do/${parts[3] || 'info'}`);
        target.search = url.search;
        return stub.fetch(new Request(target, request));
      }
    } catch (e) {
      return json({ error: 'Errore del server' }, 500);
    }
    return json({ error: 'Non trovato' }, 404);
  },
  // backup automatico: una volta a settimana (lunedì notte), vedi [triggers] in wrangler.toml
  async scheduled(ev, env, ctx) {
    ctx.waitUntil((async () => { await vault(env).fetch('https://v/put', { method: 'POST', body: await makeBackup(env) }); })());
  },
};

async function makeBackup(env) {
  const [a1, h1] = await Promise.all([archive(env).fetch('https://a/backup').then((r) => r.json()), hub(env).fetch('https://h/admin', { method: 'POST', body: '{"op":"backup"}' }).then((r) => r.json())]);
  return JSON.stringify({ made: new Date().toISOString(), archivio: a1, account: h1 });
}
const vault = (env) => env.VAULT.get(env.VAULT.idFromName('backup'));

// ---------------------------------------------------------------- Cassaforte dei backup automatici
// Ogni backup è spezzato in pezzi (un valore può essere al massimo 2 MB). Si tengono gli ultimi KEEP.
const VAULT_KEEP = 6, PIECE = 1_000_000;
export class Vault extends DurableObject {
  async fetch(request) {
    const url = new URL(request.url);
    const st = this.ctx.storage;
    const list = (await st.get('list')) || [];
    if (url.pathname === '/put') {
      const text = await request.text();
      const id = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
      const n = Math.ceil(text.length / PIECE);
      for (let i = 0; i < n; i++) await st.put(`b:${id}:${i}`, text.slice(i * PIECE, (i + 1) * PIECE));
      list.unshift({ id, n, size: text.length, made: Date.now() });
      while (list.length > VAULT_KEEP) { const old = list.pop(); for (let i = 0; i < old.n; i++) await st.delete(`b:${old.id}:${i}`); }
      await st.put('list', list);
      return json({ ok: true, id });
    }
    if (url.pathname === '/get') {
      const b = list.find((x) => x.id === url.searchParams.get('id'));
      if (!b) return new Response('', { status: 404 });
      let i = 0;
      const stream = new ReadableStream({
        async pull(c) { if (i >= b.n) return c.close(); c.enqueue(new TextEncoder().encode(await st.get(`b:${b.id}:${i++}`))); },
      });
      return new Response(stream);
    }
    return json({ list });
  }
}

// ---------------------------------------------------------------- Archivio: partite registrate e profili

// Statistiche d'uso: una riga per ogni evento (visita, partita iniziata o finita).
const EVENT_TYPES = ['visit', 'sp_start', 'sp_end', 'room', 'mp_start', 'mp_end', 'mp_seat'];
const clip = (v, n) => (v == null ? null : String(v).slice(0, n));

export class Archive extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.sql = ctx.storage.sql;
    this.sql.exec(`CREATE TABLE IF NOT EXISTS events (ts INTEGER, day TEXT, type TEXT, device TEXT, name TEXT, game TEXT, players INTEGER, humans INTEGER, rounds INTEGER, installed INTEGER)`);
    this.sql.exec('CREATE INDEX IF NOT EXISTS ev_day ON events(day)');
    this.sql.exec(`CREATE TABLE IF NOT EXISTS avatars (id TEXT PRIMARY KEY, name TEXT, pose TEXT, dir TEXT, say TEXT, hidden INTEGER DEFAULT 0, ord INTEGER DEFAULT 0, v INTEGER)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS rooms (code TEXT PRIMARY KEY, phase TEXT, info TEXT, updated INTEGER)`);
  }

  // ---- avatar
  avatarList(all) {
    const rows = this.sql.exec(`SELECT id, name, pose, dir, say, hidden, ord, v FROM avatars ${all ? '' : 'WHERE hidden = 0'} ORDER BY ord, name`).toArray();
    return rows.map((r) => ({ id: r.id, name: r.name, pose: r.pose || 'stand', dir: r.dir || null, say: r.say || '', hidden: !!r.hidden, ord: r.ord, v: r.v }));
  }

  async adminAvatars(body) {
    const okImg = (d) => typeof d === 'string' && /^data:image\/(webp|png|jpeg);base64,/.test(d) && d.length < 1_500_000;
    const slug = (t) => String(t || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
    if (body.action === 'delete') {
      const id = String(body.id || '');
      this.sql.exec('DELETE FROM avatars WHERE id = ?', id);
      await this.ctx.storage.delete(['img:' + id + ':full', 'img:' + id + ':circle']);
      return { ok: true };
    }
    if (body.action === 'order') {
      (body.ids || []).forEach((id, i) => this.sql.exec('UPDATE avatars SET ord = ? WHERE id = ?', i, String(id)));
      return { ok: true };
    }
    if (body.action === 'save') {
      const it = body.item || {};
      let id = it.id ? String(it.id) : slug(it.name);
      if (!id) throw new Error('Manca il nome');
      const exists = this.sql.exec('SELECT 1 FROM avatars WHERE id = ?', id).toArray().length;
      if (!it.id && exists) { let k = 2; while (this.sql.exec('SELECT 1 FROM avatars WHERE id = ?', `${id}-${k}`).toArray().length) k++; id = `${id}-${k}`; }
      if (!exists && !(okImg(body.full) && okImg(body.circle))) throw new Error('Serve un\'immagine');
      const pose = ['point', 'up', 'cross', 'stand'].includes(it.pose) ? it.pose : 'stand';
      const dir = it.dir === 'left' ? 'left' : null;
      const name = clip(String(it.name || id).replace(/\s+/g, ' ').trim(), 22);
      const say = clip(String(it.say || '').trim(), 60);
      const ord = Number.isFinite(it.ord) ? it.ord : (this.sql.exec('SELECT COALESCE(MAX(ord), 0) + 1 AS n FROM avatars').toArray()[0].n);
      let v = it.v || Date.now();
      if (okImg(body.full) && okImg(body.circle)) {
        await this.ctx.storage.put({ ['img:' + id + ':full']: body.full, ['img:' + id + ':circle']: body.circle });
        v = Date.now();
      }
      this.sql.exec(`INSERT INTO avatars (id, name, pose, dir, say, hidden, ord, v) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET name = excluded.name, pose = excluded.pose, dir = excluded.dir, say = excluded.say, hidden = excluded.hidden, ord = excluded.ord, v = excluded.v`,
        id, name, pose, dir, say, it.hidden ? 1 : 0, ord, v);
      return { ok: true, id, v };
    }
    throw new Error('Azione sconosciuta');
  }

  // ---- stanze in corso (aggiornate dalle stanze stesse)
  setRoom(r) {
    if (!r?.code) return;
    if (r.phase === 'gone' || r.phase === 'finished' || !r.humans) { this.sql.exec('DELETE FROM rooms WHERE code = ?', r.code); return; }
    this.sql.exec(`INSERT INTO rooms (code, phase, info, updated) VALUES (?, ?, ?, ?) ON CONFLICT(code) DO UPDATE SET phase = excluded.phase, info = excluded.info, updated = excluded.updated`,
      clip(r.code, 8), clip(r.phase, 12), JSON.stringify(r).slice(0, 4000), Date.now());
  }

  liveRooms() {
    const since = Date.now() - 20 * 60_000; // stanze ferme da più di 20 minuti non compaiono
    this.sql.exec('DELETE FROM rooms WHERE updated < ?', Date.now() - 24 * 3600_000);
    // in partita: solo se c'è qualcuno collegato; in sala d'attesa: anche fino a 5 minuti dopo l'ultima attività
    const recent = Date.now() - 5 * 60_000;
    return this.sql.exec('SELECT info, updated FROM rooms WHERE updated >= ? ORDER BY updated DESC LIMIT 80', since).toArray()
      .map((r) => ({ ...JSON.parse(r.info), updated: r.updated }))
      .filter((g) => g.online > 0 || (g.phase === 'lobby' && g.updated >= recent))
      .slice(0, 50);
  }

  addEvent(e) {
    if (!EVENT_TYPES.includes(e.type)) return false;
    const ts = Date.now();
    const day = new Date(ts + 3600_000).toISOString().slice(0, 10); // giorno italiano (circa)
    // una sola visita al giorno per telefono
    if (e.type === 'visit') {
      const seen = this.sql.exec('SELECT 1 FROM events WHERE type = ? AND day = ? AND device = ? LIMIT 1', 'visit', day, clip(e.device, 40)).toArray();
      if (seen.length) { if (e.installed) this.sql.exec('UPDATE events SET installed = 1 WHERE type = ? AND day = ? AND device = ?', 'visit', day, clip(e.device, 40)); return true; }
    }
    this.sql.exec('INSERT INTO events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', ts, day, e.type, clip(e.device, 40), clip(e.name, 22), clip(e.game, 60),
      Number(e.players) || null, Number(e.humans) || null, Number(e.rounds) || null, e.installed ? 1 : 0);
    return true;
  }

  stats() {
    const q = (sql, ...a) => this.sql.exec(sql, ...a).toArray();
    const one = (sql, ...a) => Object.values(q(sql, ...a)[0] || { v: 0 })[0] || 0;
    const since = (d) => new Date(Date.now() + 3600_000 - d * 86400_000).toISOString().slice(0, 10);
    const count = (type) => one('SELECT COUNT(*) FROM events WHERE type = ?', type);
    const days = [];
    for (let i = 29; i >= 0; i--) days.push(since(i));
    const byDay = (type, distinct) => Object.fromEntries(q(`SELECT day, ${distinct ? 'COUNT(DISTINCT device)' : 'COUNT(*)'} AS n FROM events WHERE type = ? AND day >= ? GROUP BY day`, type, days[0]).map((r) => [r.day, r.n]));
    const vis = byDay('visit', true), sp = byDay('sp_start'), mp = byDay('mp_start');
    return {
      updated: Date.now(),
      people: {
        total: one('SELECT COUNT(DISTINCT device) FROM events WHERE device IS NOT NULL'),
        today: one('SELECT COUNT(DISTINCT device) FROM events WHERE device IS NOT NULL AND day = ?', since(0)),
        week: one('SELECT COUNT(DISTINCT device) FROM events WHERE device IS NOT NULL AND day >= ?', since(6)),
        month: one('SELECT COUNT(DISTINCT device) FROM events WHERE device IS NOT NULL AND day >= ?', since(29)),
        installed: one('SELECT COUNT(DISTINCT device) FROM events WHERE installed = 1'),
      },
      games: {
        spStarted: count('sp_start'), spFinished: count('sp_end'),
        rooms: count('room'), mpStarted: count('mp_start'), mpFinished: count('mp_end'),
        avgTable: Math.round(one('SELECT AVG(players) FROM events WHERE type = ?', 'mp_start') * 10) / 10,
        avgHumans: Math.round(one('SELECT AVG(humans) FROM events WHERE type = ?', 'mp_start') * 10) / 10,
        rounds: one("SELECT SUM(rounds) FROM events WHERE type IN ('sp_end', 'mp_end')"),
      },
      daily: days.map((d) => ({ day: d, people: vis[d] || 0, sp: sp[d] || 0, mp: mp[d] || 0 })),
      players: q("SELECT name, COUNT(*) AS games, MAX(ts) AS last FROM events WHERE type IN ('sp_start', 'mp_seat') AND name IS NOT NULL GROUP BY lower(name) ORDER BY games DESC LIMIT 20"),
      recent: q("SELECT ts, type, name, players, humans, rounds FROM events WHERE type IN ('sp_start', 'sp_end', 'mp_start', 'mp_end') ORDER BY ts DESC LIMIT 25"),
    };
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/event') {
      const e = await request.json().catch(() => null);
      if (!e) return json({ error: 'Dati mancanti' }, 400);
      const list = Array.isArray(e) ? e.slice(0, 20) : [e];
      for (const x of list) this.addEvent(x || {});
      return json({ ok: true });
    }
    if (url.pathname === '/stats') return json(this.stats());
    if (url.pathname === '/backup') {
      const imgs = await this.ctx.storage.list({ prefix: 'img:' });
      return json({
        events: this.sql.exec('SELECT * FROM events').toArray(),
        avatars: this.sql.exec('SELECT * FROM avatars').toArray(),
        images: Object.fromEntries(imgs),
      });
    }
    if (url.pathname === '/avatars') return json(this.avatarList(url.searchParams.get('all') === '1'));
    if (url.pathname === '/avatar-img') {
      const data = await this.ctx.storage.get('img:' + url.searchParams.get('id') + ':' + url.searchParams.get('kind'));
      if (!data) return new Response('', { status: 404 });
      const [head, b64] = data.split(',');
      const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      return new Response(bin, { headers: { 'content-type': head.slice(5, head.indexOf(';')), 'cache-control': 'public, max-age=31536000, immutable' } });
    }
    if (url.pathname === '/admin-avatars') {
      try { return json(await this.adminAvatars(await request.json())); } catch (e) { return json({ error: e.message || 'Errore' }, 400); }
    }
    if (url.pathname === '/room' && request.method === 'POST') { this.setRoom(await request.json().catch(() => null)); return json({ ok: true }); }
    if (url.pathname === '/live') return json(this.liveRooms());
    if (url.pathname === '/put') {
      const { id, record } = await request.json();
      if (!id || !record) return json({ error: 'Dati mancanti' }, 400);
      await this.ctx.storage.put('rec:' + String(id).slice(0, 80), record);
      this.cache = null;
      return json({ ok: true });
    }
    if (url.pathname === '/profiles') {
      if (!this.cache || Date.now() - this.cache.at > 60_000) {
        const all = await this.ctx.storage.list({ prefix: 'rec:' });
        const pr = AI.learnProfiles([...all.values()]);
        this.cache = { at: Date.now(), data: pr };
      }
      return json(this.cache.data);
    }
    return json({ error: 'Non trovato' }, 404);
  }
}

// ---------------------------------------------------------------- Stanza di gioco

const LAST_AUTO_MS = 2000; // ultima mano: l'unica carta rimasta scende da sola dopo 2 secondi
const TURN_PUSH_MS = 5000; // fuori dall'app da 5 secondi quando tocca a te: notifica
const PAUSE_MAX = 10 * 60 * 1000; // pausa: al massimo 10 minuti
const CLOSE_VOTE_MS = 60 * 1000; // la richiesta di chiudere resta aperta un minuto
const RESUME_WAIT = 60 * 1000; // ripresa: chi non preme "Pronto" entro un minuto viene aspettato dalla CPU
const EMOTE_GAP = 3500;

export class GameRoom extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.env = env;
    this.turnMs = Number(env.TURN_MS || 60000); // tempo massimo per una mossa
    this.offlineMs = Number(env.OFFLINE_MS || 30000); // tempo per rientrare se si va offline
    this.proxyDelay = this.offlineMs;
    this.cpuDelay = Number(env.CPU_DELAY_MS || 5000); // attesa prima di ogni mossa delle CPU
    this.emptyClose = Number(env.EMPTY_CLOSE_MS || EMPTY_CLOSE);
    this.subMs = Number(env.SUB_MS || 7000); // dopo il subentro, attesa prima di ogni mossa al posto di chi è offline
    this.ctx.blockConcurrencyWhile(async () => {
      const st = await this.ctx.storage.get(['state', 'tokens', 'offline', 'rec', 'meta', 'chat']);
      this.state = st.get('state') || null;
      this.tokens = st.get('tokens') || {};
      this.offline = st.get('offline') || {};
      this.rec = st.get('rec') || {};
      this.meta = st.get('meta') || { gameNo: 0, cpuSeq: 0, nextAt: 0, lastActivity: Date.now() };
      this.chat = st.get('chat') || [];
      this.devices = (await this.ctx.storage.get('devices')) || {};
    });
  }

  async save() {
    this.meta.lastActivity = Date.now();
    if (this.state?.phase === 'finished' && this.meta.statEnd !== this.meta.gameNo) {
      this.meta.statEnd = this.meta.gameNo;
      await this.statGame('mp_end');
    }
    if (this.state?.phase === 'finished' && this.meta.resultFor !== this.meta.gameNo && (await this.reportResult())) this.meta.resultFor = this.meta.gameNo;
    await this.ctx.storage.put({ state: this.state, tokens: this.tokens, offline: this.offline, rec: this.rec, meta: this.meta });
    await this.reschedule();
    await this.reportLive();
  }

  // Risultato all'Hub (statistiche e ranking). La chiave della partita evita doppioni anche se si ripete.
  async reportResult() {
    const s = this.state;
    if (!this.env.HUB) return true;
    const order = RT.finalOrder(s, this.meta.away || {});
    const players = order.map((o) => {
      const p = this.player(o.id);
      const st = RT.playerStats(s, o.id);
      return { uid: p?.uid || null, name: p?.name, cpu: o.cpu, place: o.place, won: o.won, surv: o.surv, away: this.meta.away?.[o.id] != null, calls: st.calls, exact: st.exact, bcall: st.bcall, bzero: st.bzero, rounds: st.surv };
    });
    const gkey = `${s.code}:${this.meta.gameNo}:${this.meta.startedAt || 0}`;
    try {
      const r = await this.env.HUB.get(this.env.HUB.idFromName('hub')).fetch('https://h/internal/mp-result', { method: 'POST', body: JSON.stringify({ gkey, code: s.code, rounds: s.roundNo, players }) });
      return r.ok;
    } catch { return false; }
  }

  // Avvisa l'archivio di com'è la stanza, per l'elenco delle partite live (al massimo ogni 20 s
  // se non cambia niente di importante).
  async reportLive(gone = false) {
    const s = this.state;
    if (!s && !gone) return;
    const humans = s ? s.players.filter((p) => !p.cpu).length : 0;
    const info = gone ? { code: this.meta.code, phase: 'gone' } : {
      code: s.code, phase: s.phase, roundNo: s.roundNo, cards: s.round?.cards || null, humans,
      host: this.player(s.hostId)?.name || '', spectators: s.spectators.length,
      players: s.players.map((p) => ({ name: p.name, lives: p.lives, cpu: !!p.cpu, out: !!p.eliminated })),
      online: this.connectedSet().size,
      open: s.phase === 'lobby' && s.players.length < E.MAX_PLAYERS,
    };
    if (s) this.meta.code = s.code;
    const sig = JSON.stringify(info);
    const now = Date.now();
    if (sig === this.meta.liveSig && now - (this.meta.liveAt || 0) < 20_000) return;
    this.meta.liveSig = sig; this.meta.liveAt = now;
    try { await archive(this.env).fetch('https://a/room', { method: 'POST', body: sig }); } catch {}
  }

  // Turno da 1 carta: finite le chiamate si scoprono tutte le carte. L'asso di denari lo
  // decide la CPU (o chi la sostituisce); una persona sceglie da sé.
  reveal() {
    const s = this.state;
    if (!s?.round || s.phase !== 'playing' || s.round.cards !== 1) return;
    E.revealOneCard(s, (pid) => (this.isCpu(pid) ? AI.decideJolly(s, pid) : undefined));
  }

  // ---- emote: preimpostate, la propria (registrata nel profilo) o registrata al volo
  async emote(pid, msg, ws) {
    const who = this.member(pid);
    if (!who) return;
    const now = Date.now();
    (this.emoteAt ||= {});
    if (now - (this.emoteAt[pid] || 0) < EMOTE_GAP) { try { ws.send(JSON.stringify({ t: 'error', msg: 'Piano con le emote: una ogni qualche secondo' })); } catch {} return; }
    let out = null;
    const id = (v) => String(v || '').replace(/[^a-z0-9_-]/gi, '').slice(0, 80);
    const r = msg.kind === 'rx' ? who.look?.rx?.[Number(msg.slot)] : null;
    if (r) out = { kind: 'rx', id: r.id, v: r.v, name: r.name };
    else if (msg.kind === 'live' && typeof msg.data === 'string' && /^data:audio\/(wav|mp4|aac|x-m4a|webm|ogg);base64,/.test(msg.data) && msg.data.length <= 300_000) out = { kind: 'live', data: msg.data };
    if (!out) return;
    this.emoteAt[pid] = now;
    const text = JSON.stringify({ t: 'emote', pid, ...out });
    for (const w of this.ctx.getWebSockets()) { if (w.readyState === WebSocket.OPEN) { try { w.send(text); } catch {} } }
  }

  // ---- notifica "Tocca a te": a chi è fuori dall'app (o scollegato) da 5 secondi quando tocca a lui
  planTurnPush() {
    const s = this.state;
    this.meta.pushAt = 0;
    if (!s?.round || (s.phase !== 'calling' && s.phase !== 'playing') || this.meta.pause?.at) return;
    const pid = s.round.pendingJolly || s.round.turnId;
    const p = this.player(pid);
    if (!p || p.cpu || !p.uid || this.meta.subbed?.[pid]) return;
    const key = `${this.meta.gameNo}:${s.round.n}:${s.phase}:${s.round.trickNo}:${pid}`;
    if (this.meta.pushedKey === key) return;
    const away = this.meta.bg?.[pid] || (!this.connectedSet().has(pid) ? (this.offline[pid] || Date.now()) : 0);
    if (!away) return;
    this.meta.pushKey = key;
    this.meta.pushAt = Math.max(Date.now(), Math.max(away, s.round.turnStartedAt || 0) + TURN_PUSH_MS);
  }
  async turnPush() {
    const s = this.state;
    if (!s?.round || (s.phase !== 'calling' && s.phase !== 'playing') || this.meta.pause?.at) return;
    const pid = s.round.pendingJolly || s.round.turnId;
    const p = this.player(pid);
    const key = `${this.meta.gameNo}:${s.round.n}:${s.phase}:${s.round.trickNo}:${pid}`;
    if (!p?.uid || this.meta.pushKey !== key || this.meta.pushedKey === key) return;
    const still = this.meta.bg?.[pid] || !this.connectedSet().has(pid);
    if (!still) return;
    this.meta.pushedKey = key;
    const what = s.phase === 'calling' ? 'chiamare' : 'tirare una carta';
    try {
      await this.env.HUB.get(this.env.HUB.idFromName('hub')).fetch('https://h/internal/push', { method: 'POST', body: JSON.stringify({ uids: [p.uid], kind: 'turn', title: 'Tocca a te!', body: `Stanza ${s.code}: è il tuo turno di ${what}.`, url: `./?join=${s.code}`, tag: `turn-${s.code}` }) });
    } catch {}
  }

  // ---- pausa: il creatore la mette subito; gli altri la chiedono e devono dire sì tutti
  humansIn() { const c = this.connectedSet(); return this.state.players.filter((p) => !p.cpu && !p.eliminated && c.has(p.id)); }
  async pauseMsg(pid, msg) {
    const s = this.state;
    const live = s.phase === 'calling' || s.phase === 'playing' || s.phase === 'roundEnd';
    const pz = this.meta.pause;
    const me = this.player(pid);
    if (!me || me.cpu) throw new E.GameError('Solo chi gioca può farlo');
    switch (msg.t) {
      case 'pause':
        if (pid !== s.hostId) throw new E.GameError('La pausa diretta la mette chi ha creato la stanza: tu puoi chiederla');
        if (!live || pz?.at) return;
        return this.startPause(pid);
      case 'pauseReq':
        if (!live || pz?.at || pz?.req) return;
        this.meta.pause = { req: { by: pid, yes: [pid], at: Date.now() } };
        if (this.humansIn().every((p) => this.meta.pause.req.yes.includes(p.id))) return this.startPause(pid);
        return;
      case 'pauseVote': {
        if (!pz?.req) return;
        if (!msg.yes) { this.meta.pause = null; return; }
        if (!pz.req.yes.includes(pid)) pz.req.yes.push(pid);
        if (this.humansIn().every((p) => pz.req.yes.includes(p.id))) return this.startPause(pz.req.by);
        return;
      }
      case 'resume':
        if (!pz?.at || pz.resuming) return;
        if (pid !== s.hostId && pid !== pz.by) throw new E.GameError('La ripresa la decide chi ha messo la pausa');
        return this.startResume();
      case 'pauseReady':
        if (!pz?.resuming) return;
        if (!pz.resuming.ready.includes(pid)) pz.resuming.ready.push(pid);
        if (this.humansIn().every((p) => pz.resuming.ready.includes(p.id))) this.endPause();
    }
  }
  // giocatori veri presenti (collegati) che non hanno ancora messo Pronto; chi ha creato la stanza no
  missingReady() {
    const s = this.state, c = this.connectedSet(), ready = new Set(s.lobbyReady || []), out = new Set(s.sitOut || []);
    return s.players.filter((p) => !p.cpu && p.id !== s.hostId && c.has(p.id) && !ready.has(p.id) && !out.has(p.id));
  }
  // ---- chiudere la partita: la chiede chi gioca, serve il sì di almeno il 75% dei giocatori veri.
  // Le CPU non votano; chi è fuori da più di 2 turni (o eliminato e uscito) conta come CPU.
  closeVoters() {
    const s = this.state, c = this.connectedSet(), away = this.meta.away || {};
    return s.players.filter((p) => !p.cpu && !(away[p.id] != null && s.roundNo - away[p.id] >= 2) && !(p.eliminated && !c.has(p.id)));
  }
  closeInfo() {
    const cl = this.meta.close;
    if (!cl || Date.now() - cl.at > CLOSE_VOTE_MS) return null;
    const voters = this.closeVoters().map((p) => p.id);
    return { ...cl, voters, need: Math.ceil(voters.length * 0.75), until: cl.at + CLOSE_VOTE_MS };
  }
  closeMsg(pid, msg) {
    const s = this.state;
    if (!['calling', 'playing', 'roundEnd'].includes(s.phase)) throw new E.GameError('Non c\'è una partita in corso');
    const voters = this.closeVoters().map((p) => p.id);
    if (!voters.includes(pid)) throw new E.GameError('Solo chi gioca può votare');
    let cl = this.meta.close && Date.now() - this.meta.close.at <= CLOSE_VOTE_MS ? this.meta.close : null;
    if (msg.t === 'closeReq') {
      if (cl) throw new E.GameError('C\'è già una richiesta in corso');
      cl = this.meta.close = { by: pid, at: Date.now(), yes: [pid], no: [] };
    } else {
      if (!cl) return false;
      cl.yes = cl.yes.filter((x) => x !== pid); cl.no = cl.no.filter((x) => x !== pid);
      (msg.yes ? cl.yes : cl.no).push(pid);
    }
    const yes = cl.yes.filter((x) => voters.includes(x)).length, no = cl.no.filter((x) => voters.includes(x)).length;
    const need = Math.ceil(voters.length * 0.75);
    if (yes >= need) { this.closeGame(); return true; }
    if (voters.length - no < need) this.meta.close = null; // non ci si arriva più
    return false;
  }
  // partita chiusa: si torna tutti in sala d'attesa, niente classifica né statistiche
  closeGame() {
    const s = this.state;
    s.phase = 'finished'; s.winners = [];
    E.resetToLobby(s);
    s.lastWinners = [];
    Object.assign(this.meta, { close: null, pause: null, pushAt: 0, nextAt: 0, away: {}, subbed: {} });
  }
  startPause(by) { this.meta.pause = { at: Date.now(), by }; this.meta.pushAt = 0; }
  async startResume() {
    const pz = this.meta.pause;
    if (!pz?.at) return;
    pz.resuming = { at: Date.now(), ready: [] };
    // chi era uscito dall'app riceve la notifica che si riparte
    const uids = this.state.players.filter((p) => !p.cpu && !p.eliminated && p.uid).map((p) => p.uid);
    if (uids.length) {
      try { await this.env.HUB.get(this.env.HUB.idFromName('hub')).fetch('https://h/internal/push', { method: 'POST', body: JSON.stringify({ uids, kind: 'turn', title: 'La partita sta per riprendere', body: `Stanza ${this.state.code}: premi "Pronto" per ripartire.`, url: `./?join=${this.state.code}`, tag: `resume-${this.state.code}` }) }); } catch {}
    }
  }
  endPause() {
    const pz = this.meta.pause;
    if (!pz?.at) { this.meta.pause = null; return; }
    // il tempo del turno riparte da dove si era fermato
    const r = this.state.round;
    if (r?.turnStartedAt) r.turnStartedAt += Date.now() - pz.at;
    for (const k of Object.keys(this.offline || {})) this.offline[k] += Date.now() - pz.at;
    this.meta.pause = null;
  }

  // Ultima mano (turni da 2 carte in su): ognuno ha una carta sola. Parte dall'allarme quando chi è
  // di turno non l'ha tirata entro 2 secondi: la sua carta scende da sola (se è l'asso di denari,
  // poi sceglie alta o bassa col tempo normale del turno).
  revealLast() {
    const s = this.state;
    if (!s?.round || !E.inLastTrick(s)) return false;
    return E.stepLastTrick(s, (pid) => (this.isCpu(pid) ? AI.decideJolly(s, pid) : undefined));
  }

  async closeRoom() {
    for (const ws of this.ctx.getWebSockets()) { try { ws.close(1000, 'Stanza chiusa'); } catch {} }
    await this.reportLive(true);
    await this.ctx.storage.deleteAll();
    this.state = null;
  }

  // Un solo allarme: la prossima mossa della CPU (o il turno automatico) oppure la pulizia.
  async reschedule() {
    let cleanup = this.meta.lastActivity + CLEANUP_AFTER;
    if (this.meta.emptySince) cleanup = Math.min(cleanup, this.meta.emptySince + this.emptyClose + 1000);
    let at = this.meta.nextAt ? Math.min(this.meta.nextAt, cleanup) : cleanup;
    if (this.meta.pushAt) at = Math.min(at, this.meta.pushAt);
    await this.ctx.storage.setAlarm(at);
  }

  async alarm() {
    if (!this.state) return;
    const now = Date.now();
    // nessuno collegato da 5 minuti: la stanza si chiude per sempre
    if (this.meta.emptySince && now - this.meta.emptySince >= this.emptyClose && this.connectedSet().size === 0) return this.closeRoom();
    if (this.meta.pushAt && now >= this.meta.pushAt - 25) {
      this.meta.pushAt = 0;
      await this.turnPush();
      await this.save();
    }
    if (this.meta.pause?.at && this.meta.nextAt && now >= this.meta.nextAt - 25) {
      // pausa finita (10 minuti) o ripresa senza tutti pronti dopo un minuto
      const pz = this.meta.pause;
      if (!pz.resuming) await this.startResume();
      else this.endPause();
      this.planNext(); this.planTurnPush();
      await this.save();
      this.broadcast();
      return;
    }
    if (this.meta.nextAt && now >= this.meta.nextAt - 25) {
      this.meta.nextAt = 0;
      let lastDone = false, trickDone = false;
      try {
        if (this.revealLast()) lastDone = this.state.phase !== 'playing';
        else {
          const r0 = this.state.round, before = r0 ? { n: r0.n, t: r0.trickNo, phase: this.state.phase } : null;
          this.autoStep(); this.reveal();
          const r = this.state.round;
          trickDone = !!(before && r && before.phase === 'playing' && (this.state.phase !== 'playing' || r.trickNo !== before.t || r.n !== before.n));
        }
      } catch (e) { console.error(e); }
      if (lastDone && (this.state.phase === 'roundEnd' || this.state.phase === 'finished')) await this.pushRecords();
      this.planNext(trickDone || lastDone);
      this.planTurnPush();
      await this.save();
      this.broadcast();
      return;
    }
    if (now - this.meta.lastActivity >= CLEANUP_AFTER) {
      for (const ws of this.ctx.getWebSockets()) ws.close(1000, 'Stanza scaduta');
      await this.reportLive(true);
      await this.ctx.storage.deleteAll();
      this.state = null;
      return;
    }
    await this.reschedule();
  }

  player(id) { return this.state.players.find((p) => p.id === id); }
  isCpu(id) { return !!this.player(id)?.cpu; }

  connectedSet() {
    const set = new Set();
    for (const ws of this.ctx.getWebSockets()) {
      if (ws.readyState !== WebSocket.OPEN) continue;
      const a = ws.deserializeAttachment();
      if (a?.pid) set.add(a.pid);
    }
    return set;
  }

  // Scadenza della mossa di un giocatore: un minuto dall'inizio del turno; se è offline,
  // 30 secondi per rientrare (sempre dentro il minuto). Allo scadere gioca la CPU per lui.
  // Dopo il primo subentro (chi è offline non ha giocato nei 30 secondi) la CPU continua
  // al suo posto con 7 secondi per mossa, finché il giocatore non si ricollega.
  deadlineFor(pid, connected = this.connectedSet()) {
    const r = this.state.round;
    const start = r.turnStartedAt || Date.now();
    let d = start + this.turnMs;
    if (!connected.has(pid)) {
      if (this.meta.subbed?.[pid]) return start + this.subMs;
      d = Math.min(d, Math.max(start, this.offline[pid] || start) + this.offlineMs);
    }
    return d;
  }

  // Decide quando deve muoversi la CPU (o partire il turno successivo da solo).
  planNext(justFinishedTrick = false) {
    const s = this.state;
    this.meta.nextAt = 0;
    if (!s) return;
    const pz = this.meta.pause;
    if (pz?.at) { this.meta.nextAt = pz.resuming ? pz.resuming.at + RESUME_WAIT : pz.at + PAUSE_MAX; return; }
    const humansAlive = s.players.filter((p) => !p.cpu && !p.eliminated);
    const fast = humansAlive.length === 0 ? 0.5 : 1;
    if (E.inLastTrick(s) && !this.isCpu(s.round.turnId)) {
      // ultima mano: chi ha una carta sola e non la tira entro 2 secondi se la vede scendere da sola
      // (2 secondi da quando vede il suo turno: se la mano prima è appena finita, dopo la pausa per vederla)
      this.meta.nextAt = Date.now() + (justFinishedTrick ? 1500 : 0) + LAST_AUTO_MS;
      return;
    }
    if (s.phase === 'calling' || s.phase === 'playing') {
      const r = s.round;
      const actor = r.pendingJolly || r.turnId;
      if (actor && this.isCpu(actor)) {
        const base = Math.max(this.cpuDelay, justFinishedTrick ? 1700 : 0);
        this.meta.nextAt = Date.now() + base * fast;
      } else if (actor) this.meta.nextAt = this.deadlineFor(actor);
    } else if (s.phase === 'roundEnd') {
      const connected = this.connectedSet();
      const waiting = humansAlive.filter((p) => connected.has(p.id) && !s.ready.includes(p.id));
      if (!waiting.length) this.meta.nextAt = Date.now() + (humansAlive.length ? 1500 : 3000);
    }
  }

  cpuCfg(pid, level) {
    const p = this.player(pid);
    const models = {};
    for (const q of this.state.players) if (!q.cpu) models[q.id] = AI.profileFor(this.profiles, { device: this.devices[q.id], name: q.name });
    return { level: level || p.cpu?.level || 'medio', persona: p.cpu?.persona || AI.makePersona(rng), rng, models };
  }

  // Mossa automatica: CPU di turno, oppure turno successivo quando tutti sono pronti.
  autoStep() {
    const s = this.state;
    if (s.phase === 'roundEnd') { E.nextRound(s, { rng }); return; }
    if (s.phase !== 'calling' && s.phase !== 'playing') return;
    const r = s.round;
    const pid = r.pendingJolly || r.turnId;
    if (this.isCpu(pid)) return this.cpuMove(pid);
    // tempo scaduto: la CPU gioca al posto del giocatore
    const connected = this.connectedSet();
    if (pid && Date.now() >= this.deadlineFor(pid, connected) - 50) {
      if (!connected.has(pid)) {
        (this.meta.subbed ||= {})[pid] = true;
        // abbandono: chi resta sostituito fino alla fine conta come eliminato da questo turno
        (this.meta.away ||= {})[pid] ??= this.state.roundNo;
      }
      this.cpuMove(pid, 'medio');
    }
  }

  cpuMove(pid, level) {
    const s = this.state;
    const r = s.round;
    const cfg = this.cpuCfg(pid, level);
    if (s.phase === 'calling') E.makeCall(s, pid, AI.decideCall(s, pid, cfg));
    else if (r.pendingJolly === pid) E.chooseJolly(s, pid, AI.decideJolly(s, pid));
    else { const d = AI.decidePlay(s, pid, cfg); E.playCard(s, pid, d.card, d.jolly); }
  }

  newIdentity() {
    const id = randomId(5);
    const token = randomId(18);
    this.tokens[token] = id;
    return { id, token };
  }

  isMember(pid) {
    const s = this.state;
    return s.players.some((p) => p.id === pid && !p.cpu) || s.spectators.some((p) => p.id === pid);
  }

  async fetch(request) {
    const url = new URL(request.url);
    const action = url.pathname.slice(1);
    try {
      if (action === 'init') {
        if (this.state) return json({ error: 'exists' }, 409);
        const body = await request.json();
        const who = this.newIdentity();
        this.state = E.createGame({ code: body.code, hostId: who.id, hostName: body.name });
        const pick0 = this.cleanPick(body.pick);
        if (pick0) this.state.players[0].avatar = { pick: pick0 };
        if (body.user?.id) { this.state.players[0].uid = body.user.id; this.state.players[0].look = this.cleanLook(body.user); }
        this.devices = { [who.id]: clip(body.device, 40) };
        this.meta.emptySince = Date.now();
        await this.ctx.storage.put('devices', this.devices);
        await this.save();
        await this.stat([{ type: 'room', device: body.device, name: body.name, game: body.code }]);
        return json({ code: body.code, playerId: who.id, token: who.token });
      }
      if (!this.state) return json({ error: 'Stanza non trovata. Controlla il codice.' }, 404);

      if (action === 'info') {
        const s = this.state;
        return json({
          code: s.code, phase: s.phase,
          players: s.players.map((p) => p.name),
          picks: [...s.players, ...s.spectators].filter((p) => p.avatar?.pick).map((p) => ({ pick: p.avatar.pick, name: p.name })),
          names: [...s.players, ...s.spectators].map((p) => p.name),
          canJoinAsPlayer: s.phase === 'lobby' && s.players.length < E.MAX_PLAYERS,
        });
      }

      if (action === 'join' && request.method === 'POST') {
        const body = await request.json();
        const s = this.state;
        if (body.as !== 'spectator' && s.phase !== 'lobby') return json({ error: 'La partita è già iniziata: puoi entrare come spettatore', started: true }, 400);
        const pick = this.cleanPick(body.pick); // lo stesso personaggio lo possono avere in tanti
        // lo stesso account che rientra (anche da un altro telefono) ritrova il suo posto
        const same = body.user?.id && [...s.players, ...s.spectators].find((p) => p.uid === body.user.id);
        if (same) {
          const token = randomId(18);
          this.tokens[token] = same.id;
          same.look = this.cleanLook(body.user);
          await this.save();
          return json({ code: s.code, playerId: same.id, token });
        }
        const who = this.newIdentity();
        if (body.as === 'spectator') E.addSpectator(s, { id: who.id, name: body.name });
        else E.addPlayer(s, { id: who.id, name: body.name });
        if (pick) this.member(who.id).avatar = { pick };
        if (body.user?.id) { this.member(who.id).uid = body.user.id; this.member(who.id).look = this.cleanLook(body.user); }
        this.devices[who.id] = clip(body.device, 40);
        await this.ctx.storage.put('devices', this.devices);
        await this.save();
        this.broadcast();
        return json({ code: s.code, playerId: who.id, token: who.token });
      }

      if (action === 'ws') {
        const pid = this.tokens[url.searchParams.get('token')];
        if (!pid || !this.isMember(pid)) return json({ error: 'Non fai parte di questa stanza' }, 403);
        if (request.headers.get('Upgrade') !== 'websocket') return json({ ok: true }, 426);
        const pair = new WebSocketPair();
        this.ctx.acceptWebSocket(pair[1], [pid]);
        pair[1].serializeAttachment({ pid });
        try { pair[1].send(JSON.stringify({ t: 'chatAll', msgs: this.chat })); } catch {}
        if (this.offline[pid]) delete this.offline[pid];
        if (this.meta.subbed?.[pid]) delete this.meta.subbed[pid];
        if (this.meta.away?.[pid] != null) delete this.meta.away[pid];
        this.meta.emptySince = 0;
        this.planNext();
        await this.save();
        this.broadcast();
        return new Response(null, { status: 101, webSocket: pair[0] });
      }

      // il telefono è passato a un'altra stanza: esce da questa (se si può)
      if (action === 'leave' && request.method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const pid = this.tokens[body.token];
        if (pid && this.member(pid) && (this.state.phase === 'lobby' || this.state.phase === 'finished')) {
          await this.handle(pid, { t: 'leave' });
          await this.save();
          this.broadcast();
        }
        return json({ ok: true });
      }

      // foto profilo: caricata dall'app già ritagliata e rimpicciolita
      if (action === 'avatar' && request.method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const pid = this.tokens[body.token];
        const who = pid && this.member(pid);
        if (!who) return json({ error: 'Non fai parte di questa stanza' }, 403);
        if (body.clear) { delete who.avatar; await this.ctx.storage.delete('av:' + pid); }
        else if (body.pick) {
          who.avatar = { pick: this.cleanPick(body.pick) };
          if (body.look && who.uid) who.look = this.cleanLook(body.look);
        }
        else if (body.look) { if (who.uid) who.look = this.cleanLook(body.look); }
        else {
          const data = String(body.data || '');
          if (!/^data:image\/(jpeg|webp|png);base64,/.test(data) || data.length > MAX_AVATAR) return json({ error: 'Foto non valida o troppo grande' }, 400);
          await this.ctx.storage.put('av:' + pid, data);
          who.avatar = { photo: Date.now() };
        }
        await this.save();
        this.broadcast();
        return json({ ok: true });
      }
      if (action === 'avatar') {
        const data = await this.ctx.storage.get('av:' + url.searchParams.get('pid'));
        if (!data) return new Response('', { status: 404 });
        const [head, b64] = data.split(',');
        const type = head.slice(5, head.indexOf(';'));
        const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
        return new Response(bin, { headers: { 'content-type': type, 'cache-control': 'public, max-age=604800' } });
      }
    } catch (e) {
      if (e instanceof E.GameError) return json({ error: e.message }, 400);
      console.error(e);
      return json({ error: 'Errore del server' }, 500);
    }
    return json({ error: 'Non trovato' }, 404);
  }

  broadcast(skipWs, goneId) {
    if (!this.state) return;
    const connected = this.connectedSet();
    if (goneId) connected.delete(goneId);
    const now = Date.now();
    let deadline = null, deadlineFor = null;
    const st = this.state;
    if (st.round && (st.phase === 'calling' || st.phase === 'playing')) {
      const actor = st.round.pendingJolly || st.round.turnId;
      if (actor && !this.isCpu(actor)) { deadlineFor = actor; deadline = this.deadlineFor(actor, connected); }
    }
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === skipWs) continue;
      const a = ws.deserializeAttachment();
      if (!a?.pid) continue;
      if (!this.isMember(a.pid)) {
        try { ws.send(JSON.stringify({ t: 'kicked' })); ws.close(1000, 'kicked'); } catch {}
        continue;
      }
      try {
        ws.send(JSON.stringify({
          t: 'state', now, me: a.pid,
          s: E.maskState(this.state, a.pid),
          online: [...connected], offline: this.offline,
          proxyDelay: this.proxyDelay, hostTakeoverAfter: HOST_TAKEOVER_AFTER,
          deadline, deadlineFor, pause: this.meta.pause || null, close: this.closeInfo(),
        }));
      } catch {}
    }
  }

  async webSocketMessage(ws, raw) {
    const { pid } = ws.deserializeAttachment() || {};
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (msg.t === 'ping') return ws.send(JSON.stringify({ t: 'pong', now: Date.now() }));
    if (msg.t === 'chat') {
      try { await this.chatMessage(pid, msg.text); } catch (e) { ws.send(JSON.stringify({ t: 'error', msg: e instanceof E.GameError ? e.message : 'Messaggio non inviato' })); }
      return;
    }
    if (msg.t === 'emote') return this.emote(pid, msg, ws);
    // l'app è andata in secondo piano (o è tornata): serve per la notifica "Tocca a te"
    if (msg.t === 'bg') {
      (this.meta.bg ||= {});
      if (msg.on) this.meta.bg[pid] = Date.now(); else delete this.meta.bg[pid];
      this.planTurnPush();
      await this.save();
      return;
    }
    if (msg.t === 'closeReq' || msg.t === 'closeVote') {
      let closed = false;
      try { closed = this.closeMsg(pid, msg); } catch (e) { ws.send(JSON.stringify({ t: 'error', msg: e instanceof E.GameError ? e.message : 'Errore' })); return; }
      if (closed) for (const w of this.ctx.getWebSockets()) { try { w.send(JSON.stringify({ t: 'closed' })); } catch {} }
      this.planNext(); this.planTurnPush();
      await this.save();
      this.broadcast();
      return;
    }
    if (['pause', 'pauseReq', 'pauseVote', 'resume', 'pauseReady'].includes(msg.t)) {
      try { await this.pauseMsg(pid, msg); } catch (e) { ws.send(JSON.stringify({ t: 'error', msg: e instanceof E.GameError ? e.message : 'Errore' })); return; }
      this.planNext(); this.planTurnPush();
      await this.save();
      this.broadcast();
      return;
    }
    try {
      const before = this.state.round ? { n: this.state.round.n, t: this.state.round.trickNo, phase: this.state.phase } : null;
      await this.handle(pid, msg);
      this.reveal();
      const r = this.state.round;
      const trickDone = !!(before && r && before.phase === 'playing' && (this.state.phase !== 'playing' || r.trickNo !== before.t || r.n !== before.n));
      this.planNext(trickDone); this.planTurnPush();
      await this.save();
      this.broadcast();
    } catch (e) {
      const text = e instanceof E.GameError ? e.message : 'Errore imprevisto';
      if (!(e instanceof E.GameError)) console.error(e);
      ws.send(JSON.stringify({ t: 'error', msg: text }));
    }
  }

  pushEntry(pid, entry) {
    if (!entry) return;
    const rec = (this.rec[pid] ||= { calls: [], plays: [] });
    (entry.kind === 'call' ? rec.calls : rec.plays).push(entry.e);
  }

  // Personaggio già scelto da qualcun altro nella stanza?
  pickTaken(pick, exceptId) {
    const s = this.state;
    return [...s.players, ...s.spectators].find((p) => p.id !== exceptId && p.avatar?.pick === pick) || null;
  }
  cleanPick(v) { return v ? String(v).replace(/[^a-z0-9_-]/gi, '').slice(0, 40) : null; }
  // come si presenta: accessori sull'avatar, dorso delle carte, emote personale (dall'account)
  cleanLook(l) {
    if (!l || typeof l !== 'object') return null;
    const id = (v, n) => (v ? String(v).replace(/[^a-z0-9_-]/gi, '').slice(0, n) : null);
    const rx = [].concat(l.rx || []).slice(0, 4).map((r) => (r && id(r.id, 80) ? { id: id(r.id, 80), name: String(r.name || '').slice(0, 24), v: Math.max(1, Number(r.v) || 1) } : null));
    const acc = [].concat(l.acc || []).map((x) => id(x, 60)).filter(Boolean).slice(0, 8);
    return { back: id(l.back, 60), rx, king: !!l.king, acc };
  }

  member(pid) { return this.state.players.find((p) => p.id === pid && !p.cpu) || this.state.spectators.find((p) => p.id === pid); }

  // Chat della stanza: i tag @nome valgono per le persone presenti (non per le CPU).
  async chatMessage(pid, text) {
    const who = this.member(pid);
    if (!who) throw new E.GameError('Non fai parte della stanza');
    const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 300);
    if (!t) return;
    const people = [...this.state.players.filter((p) => !p.cpu), ...this.state.spectators];
    const low = t.toLowerCase();
    // @tutti: tagga tutte le persone della stanza
    const all = /(^|\s)@tutti(?![\p{L}\p{N}_])/u.test(low);
    const mentions = people.filter((p) => {
      if (all && p.id !== pid) return true;
      const tag = '@' + p.name.toLowerCase();
      let i = low.indexOf(tag);
      while (i >= 0) {
        const after = low[i + tag.length];
        if (after === undefined || !/[\p{L}\p{N}_]/u.test(after)) return true;
        i = low.indexOf(tag, i + 1);
      }
      return false;
    }).map((p) => p.id);
    const m = { id: randomId(6), pid, name: who.name, text: t, at: Date.now(), mentions };
    this.chat.push(m);
    if (this.chat.length > CHAT_KEEP) this.chat = this.chat.slice(-CHAT_KEEP);
    this.meta.lastActivity = Date.now();
    await this.ctx.storage.put({ chat: this.chat, meta: this.meta });
    const out = JSON.stringify({ t: 'chat', msg: m });
    for (const ws of this.ctx.getWebSockets()) { try { ws.send(out); } catch {} }
    // chi è taggato ma non è nell'app riceve la notifica sul telefono
    const conn = this.connectedSet();
    const uids = people.filter((p) => mentions.includes(p.id) && p.uid && !conn.has(p.id)).map((p) => p.uid);
    if (uids.length) {
      try { await this.env.HUB.get(this.env.HUB.idFromName('hub')).fetch('https://h/internal/push', { method: 'POST', body: JSON.stringify({ uids, title: `${who.name} nella stanza ${this.state.code}`, body: t.slice(0, 140), url: `./?join=${this.state.code}`, tag: `chat-${this.state.code}` }) }); } catch {}
    }
  }

  recordEntry(pid, kind, data) {
    const p = this.player(pid);
    if (!p || p.cpu || !this.state.round) return null;
    const r = this.state.round;
    if (r.turnId !== pid && r.pendingJolly !== pid) return null;
    const rec = { calls: [], plays: [] };
    if (kind === 'call') {
      const e = { cards: r.cards, n: r.seats.length, call: data.n, dealer: r.dealerId === pid, pos: r.seats.indexOf(pid) };
      if (r.cards === 1) { e.visible = r.seats.filter((id) => id !== pid).map((id) => r.hands[id][0]); e.pool = 40 - e.visible.length; }
      else e.hand = r.hands[pid].slice();
      rec.calls.push(e);
    } else if (kind === 'play' && r.cards > 1) {
      const h = r.hands[pid];
      const low = Math.min(...h.map((c) => (c === E.JOLLY ? 0 : c + 1)));
      const sv = data.card === E.JOLLY ? (data.jolly === 'high' ? 41 : 0) : data.card + 1;
      rec.plays.push({ trick: r.trickNo, options: h.length, lowest: sv === low, need: (r.calls[pid] ?? 0) - r.won[pid] });
    }
    if (rec.calls.length) return { kind: 'call', e: rec.calls[0] };
    if (rec.plays.length) return { kind: 'play', e: rec.plays[0] };
    return null;
  }

  // Statistiche: inizio e fine di ogni partita della stanza.
  async stat(events) {
    try { await archive(this.env).fetch('https://a/event', { method: 'POST', body: JSON.stringify(events) }); } catch {}
  }

  async statGame(kind) {
    const s = this.state;
    const humans = s.players.filter((p) => !p.cpu);
    const game = `${s.code}-${this.meta.gameNo}`;
    const ev = [{ type: kind, game, players: s.players.length, humans: humans.length, rounds: kind === 'mp_end' ? s.roundNo : null, device: this.devices[s.hostId] }];
    if (kind === 'mp_start') for (const p of humans) ev.push({ type: 'mp_seat', game, name: p.name, device: this.devices[p.id], players: s.players.length });
    await this.stat(ev);
  }

  async pushRecords() {
    const s = this.state;
    const jobs = [];
    for (const [pid, rec] of Object.entries(this.rec)) {
      const p = this.player(pid);
      if (!p || (!rec.calls.length && !rec.plays.length)) continue;
      const record = { v: 1, player: p.name, device: this.devices[pid] || null, level: 'online', at: Date.now(), players: s.players.length, rounds: s.roundNo, calls: rec.calls, plays: rec.plays };
      jobs.push(archive(this.env).fetch('https://a/put', { method: 'POST', body: JSON.stringify({ id: `${s.code}-${this.meta.gameNo}-${pid}`, record }) }).catch(() => {}));
    }
    await Promise.all(jobs);
  }

  async loadProfiles() {
    try {
      const res = await archive(this.env).fetch('https://a/profiles');
      this.profiles = await res.json();
    } catch { this.profiles = null; }
  }

  async handle(pid, msg) {
    const s = this.state;
    const now = Date.now();
    if (this.meta.pause?.at && ['call', 'play', 'jolly', 'ready'].includes(msg.t)) throw new E.GameError('La partita è in pausa');
    const isHost = pid === s.hostId;
    const needHost = () => { if (!isHost) throw new E.GameError("Solo chi ha creato la stanza può farlo"); };
    const me = this.player(pid);

    switch (msg.t) {
      // ---- sala d'attesa
      case 'start': {
        needHost();
        if (s.phase === 'finished') E.resetToLobby(s);
        // servono i Pronto di tutti i giocatori veri presenti (chi ha creato la stanza avvia)
        const missing = this.missingReady();
        if (missing.length) throw new E.GameError(`Manca il Pronto di ${missing.map((p) => p.name).join(', ')}`);
        await this.loadProfiles();
        for (const p of s.players) if (p.cpu) p.cpu.persona = AI.makePersona(rng);
        this.rec = {};
        this.meta.gameNo += 1;
        this.meta.away = {};
        this.meta.startedAt = Date.now();
        s.rematch = null;
        E.startGame(s, { rng, now });
        await this.statGame('mp_start');
        return;
      }
      case 'lobbyReady': E.setLobbyReady(s, pid, msg.on !== false); return;
      case 'sitOut': E.setSitOut(s, pid, msg.on !== false); return;
      case 'wantsIn': E.setWantsIn(s, pid, msg.on !== false); return;
      case 'addCpu': {
        needHost();
        if (s.phase !== 'lobby') throw new E.GameError('Le CPU si aggiungono in sala d\'attesa');
        const level = LEVELS.includes(msg.level) ? msg.level : 'medio';
        const n = Math.max(1, Math.min(12, Number(msg.n) || 1));
        for (let i = 0; i < n; i++) {
          if (s.players.length >= E.MAX_PLAYERS) throw new E.GameError(`Massimo ${E.MAX_PLAYERS} al tavolo`);
          let name;
          do { this.meta.cpuSeq += 1; name = 'CPU' + this.meta.cpuSeq; } while (s.players.some((p) => p.name.toLowerCase() === name.toLowerCase()));
          E.addPlayer(s, { id: 'cpu' + randomId(3), name, cpu: { level } });
        }
        return;
      }
      case 'cpuLevel': {
        needHost();
        const p = this.player(msg.pid);
        if (!p?.cpu) throw new E.GameError('Non è una CPU');
        if (s.phase !== 'lobby') throw new E.GameError('Il livello si cambia in sala d\'attesa');
        p.cpu.level = LEVELS.includes(msg.level) ? msg.level : p.cpu.level;
        return;
      }
      case 'remove':
        needHost();
        if (msg.pid === s.hostId) throw new E.GameError('Non puoi togliere te stesso');
        if (s.phase === 'lobby') E.removeFromLobby(s, msg.pid);
        else E.setKick(s, msg.pid, true);
        return;
      case 'unkick':
        needHost();
        E.setKick(s, msg.pid, false);
        return;
      case 'rename':
        if (this.member(pid)?.uid) throw new E.GameError('Il nome è il tuo username: si cambia dal profilo');
        E.renamePlayer(s, pid, msg.name);
        return;
      case 'leave': {
        // uscita dalla stanza (in sala d'attesa o a partita finita)
        if (s.phase !== 'lobby' && s.phase !== 'finished') throw new E.GameError('Durante la partita non puoi uscire dalla stanza');
        if (s.phase === 'finished') E.resetToLobby(s);
        const humans = s.players.filter((p) => !p.cpu && p.id !== pid);
        if (pid === s.hostId) {
          if (!humans.length) { s.players = s.players.filter((p) => !p.cpu); }
          else s.hostId = humans[0].id;
        }
        s.players = s.players.filter((p) => p.id !== pid);
        s.spectators = s.spectators.filter((p) => p.id !== pid);
        for (const k of ['lobbyReady', 'sitOut', 'wantsIn']) s[k] = (s[k] || []).filter((x) => x !== pid);
        return;
      }
      case 'toLobby':
        if (s.phase === 'finished') E.resetToLobby(s);
        return;
      // rivincita: si torna tutti nella stessa sala d'attesa e gli altri vedono la proposta
      case 'rematch':
        if (s.phase === 'finished') E.resetToLobby(s);
        if (s.phase !== 'lobby') throw new E.GameError('La partita è in corso');
        s.rematch = { by: pid, name: this.member(pid)?.name || '', at: Date.now(), yes: [pid] };
        return;
      case 'rematchYes':
        if (s.rematch && !s.rematch.yes.includes(pid)) s.rematch.yes.push(pid);
        return;

      // ---- partita
      case 'call': {
        const entry = this.recordEntry(pid, 'call', { n: Number(msg.n) });
        E.makeCall(s, pid, Number(msg.n), { now });
        this.pushEntry(pid, entry);
        return;
      }
      case 'play': {
        const card = s.round?.cards === 1 ? s.round.hands[pid]?.[0] : msg.card;
        const entry = this.recordEntry(pid, 'play', { card, jolly: msg.jolly });
        E.playCard(s, pid, card, msg.jolly, { now });
        this.pushEntry(pid, entry);
        if (s.phase === 'roundEnd' || s.phase === 'finished') await this.pushRecords();
        return;
      }
      case 'jolly':
        E.chooseJolly(s, pid, msg.v, { now });
        if (s.phase === 'roundEnd' || s.phase === 'finished') await this.pushRecords();
        return;
      case 'ready': {
        if (s.phase !== 'roundEnd') return;
        E.setReady(s, pid);
        return;
      }
      case 'force':
        needHost();
        E.nextRound(s, { rng, now });
        return;
      case 'cpuFor': {
        // chi ha creato la stanza fa giocare la CPU al posto di un giocatore offline
        needHost();
        const r = s.round;
        if (!r || !['calling', 'playing'].includes(s.phase)) throw new E.GameError('Nessun turno in corso');
        const target = r.pendingJolly || r.turnId;
        if (msg.pid !== target) throw new E.GameError('Non è il suo turno');
        if (this.connectedSet().has(target)) throw new E.GameError('Il giocatore è collegato');
        const since = Math.max(r.turnStartedAt, this.offline[target] || 0);
        if (now - since < this.proxyDelay) throw new E.GameError('Aspetta ancora qualche secondo');
        this.cpuMove(target, 'medio');
        return;
      }
      // ---- angelo custode: chi guarda chiede di vedere le carte di un giocatore
      case 'peekAsk':
        E.askPeek(s, pid, msg.pid, now);
        return;
      case 'peekAnswer':
        E.answerPeek(s, pid, msg.viewer, !!msg.ok, now);
        return;
      case 'claimHost': {
        if (!me || me.cpu) throw new E.GameError('Solo un giocatore può diventare admin');
        if (this.connectedSet().has(s.hostId)) throw new E.GameError("L'admin è collegato");
        if (now - (this.offline[s.hostId] || 0) < HOST_TAKEOVER_AFTER) throw new E.GameError("Aspetta: l'admin potrebbe rientrare");
        s.hostId = pid;
        return;
      }
      default:
        throw new E.GameError('Azione sconosciuta');
    }
  }

  async markOffline(ws) {
    const a = ws.deserializeAttachment();
    if (!a?.pid || !this.state) return;
    const stillOn = this.ctx.getWebSockets(a.pid).some((w) => w !== ws && w.readyState === WebSocket.OPEN);
    if (!stillOn) this.offline[a.pid] = Date.now();
    const anyone = this.ctx.getWebSockets().some((w) => w !== ws && w.readyState === WebSocket.OPEN);
    if (!anyone) this.meta.emptySince = Date.now();
    this.planNext();
    await this.save();
    this.broadcast(ws, stillOn ? null : a.pid);
  }

  async webSocketClose(ws, code) {
    await this.markOffline(ws);
    try { ws.close(code === 1005 ? 1000 : code, 'bye'); } catch {}
  }

  async webSocketError(ws) {
    await this.markOffline(ws);
  }
}

// ---------------------------------------------------------------- Segnavite (partite dal vivo)
// Un tavolo per codice. Resta aperto anche senza nessuno collegato (il telefono si blocca tra un
// turno e l'altro): si cancella dopo 7 giorni senza modifiche, o quando chi l'ha creato lo chiude.
const LIVES_KEEP = 7 * 24 * 3600 * 1000;

export class LifeTable extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.closedShow = Number(env.LIVES_CLOSED_MS || L.CLOSED_SHOW);
    this.ctx.blockConcurrencyWhile(async () => { this.st = (await this.ctx.storage.get('st')) || null; });
  }

  async save() {
    await this.ctx.storage.put('st', this.st);
    await this.ctx.storage.setAlarm(Date.now() + LIVES_KEEP);
  }

  async alarm() {
    if (this.st?.closedAt && Date.now() < this.st.closedAt + this.closedShow - 1000) return this.ctx.storage.setAlarm(this.st.closedAt + this.closedShow);
    if (this.st && !this.st.closedAt && Date.now() - this.st.updated < LIVES_KEEP - 60_000) return this.ctx.storage.setAlarm(this.st.updated + LIVES_KEEP);
    for (const ws of this.ctx.getWebSockets()) { try { ws.send('{"t":"gone"}'); ws.close(1000, 'Tavolo chiuso'); } catch {} }
    this.st = null;
    await this.ctx.storage.deleteAll();
  }

  online() {
    const s = new Set();
    for (const ws of this.ctx.getWebSockets()) if (ws.readyState === 1) s.add(ws.deserializeAttachment()?.device);
    return s;
  }

  broadcast() {
    const on = this.online();
    for (const ws of this.ctx.getWebSockets()) {
      if (ws.readyState !== 1) continue;
      const { device } = ws.deserializeAttachment() || {};
      const v = L.viewFor(this.st, device, on);
      v.closedUntil = this.st.closedAt ? this.st.closedAt + this.closedShow : null;
      try { ws.send(JSON.stringify({ t: 'state', v, now: Date.now() })); } catch {}
    }
  }

  async fetch(request) {
    const url = new URL(request.url);
    const action = url.pathname.slice(1);
    if (action === 'init' && request.method === 'POST') {
      if (this.st) return json({ error: 'Codice occupato' }, 409);
      const body = await request.json().catch(() => ({}));
      const device = String(body.device || '').slice(0, 64);
      if (!device) return json({ error: 'Telefono sconosciuto' }, 400);
      try {
        this.st = L.createTable({ code: url.searchParams.get('code'), device, pub: randomId(4), name: body.name, players: body.players });
      } catch (e) { return json({ error: e.message }, 400); }
      await this.save();
      return json({ code: this.st.code });
    }
    if (!this.st) return json({ error: 'Tavolo non trovato' }, 404);
    if (action === 'info') return json({ code: this.st.code, players: this.st.players.length, updated: this.st.updated, closedAt: this.st.closedAt || null });
    if (action === 'ws') {
      if (request.headers.get('Upgrade') !== 'websocket') return json({ ok: true });
      const device = String(url.searchParams.get('device') || '').slice(0, 64);
      if (!device) return json({ error: 'Telefono sconosciuto' }, 400);
      L.touchDevice(this.st, device, url.searchParams.get('name'), randomId(4));
      await this.ctx.storage.put('st', this.st);
      const pair = new WebSocketPair();
      this.ctx.acceptWebSocket(pair[1]);
      pair[1].serializeAttachment({ device });
      queueMicrotask(() => this.broadcast());
      return new Response(null, { status: 101, webSocket: pair[0] });
    }
    return json({ error: 'Non trovato' }, 404);
  }

  async webSocketMessage(ws, raw) {
    if (!this.st) return;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'ping') return;
    const { device } = ws.deserializeAttachment() || {};
    // chiuso: resta visibile (senza modifiche) per 5 minuti, poi si cancella
    if (m.t === 'close' || m.t === 'reopen') {
      if (L.roleOf(this.st, device) !== 'owner') { try { ws.send(JSON.stringify({ t: 'error', msg: 'Solo chi ha creato il tavolo può farlo' })); } catch {} return; }
      if (m.t === 'close' && !this.st.closedAt) {
        this.st.closedAt = Date.now();
        await this.ctx.storage.put('st', this.st);
        await this.ctx.storage.setAlarm(this.st.closedAt + this.closedShow);
      } else if (m.t === 'reopen' && this.st.closedAt) {
        this.st.closedAt = null;
        this.st.updated = Date.now();
        await this.save();
      }
      return this.broadcast();
    }
    if (this.st.closedAt) { try { ws.send(JSON.stringify({ t: 'error', msg: 'Il tavolo è chiuso' })); } catch {} return; }
    if (m.t === 'hello') { L.touchDevice(this.st, device, m.name, randomId(4)); await this.ctx.storage.put('st', this.st); return this.broadcast(); }
    const err = L.apply(this.st, device, m);
    if (err) { try { ws.send(JSON.stringify({ t: 'error', msg: err })); } catch {} return; }
    await this.save();
    this.broadcast();
  }

  webSocketClose() { this.broadcast(); }
  webSocketError() { this.broadcast(); }
}
