// Chat di una community: un Durable Object per community, così una community grande non rallenta le altre.
// Chi può leggere e scrivere lo decide l'Hub: qui c'è una copia dell'elenco dei membri, aggiornata dall'Hub.

import { DurableObject } from 'cloudflare:workers';

const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
const PAGE = 50;

export class Community extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.env = env;
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS members (uid TEXT PRIMARY KEY, role TEXT)');
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS msgs (id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT, uname TEXT, avatar TEXT, text TEXT, ts INTEGER, men TEXT, del INTEGER DEFAULT 0)');
    for (const col of ['kind TEXT', 'code TEXT', 'secs REAL']) { try { ctx.storage.sql.exec(`ALTER TABLE msgs ADD COLUMN ${col}`); } catch {} }
    // messaggi vocali: l'audio sta a parte, il messaggio ha solo la durata
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS audio (id INTEGER PRIMARY KEY, data TEXT, ts INTEGER)');
    this.rate = new Map();
  }
  sql(s, ...a) { return this.ctx.storage.sql.exec(s, ...a).toArray(); }
  role(uid) { return this.sql('SELECT role FROM members WHERE uid = ?', uid)[0]?.role || null; }
  shape(m) { return { id: m.id, uid: m.uid, uname: m.uname, avatar: m.avatar, text: m.del ? '' : m.text, ts: m.ts, men: m.men ? JSON.parse(m.men) : [], del: !!m.del, kind: m.kind || null, code: m.code || null, secs: m.secs || null }; }
  page({ before, around } = {}) {
    if (around) {
      const a = Number(around);
      const older = this.sql('SELECT * FROM msgs WHERE id <= ? ORDER BY id DESC LIMIT ?', a, PAGE / 2).reverse();
      const newer = this.sql('SELECT * FROM msgs WHERE id > ? ORDER BY id ASC LIMIT ?', a, PAGE / 2);
      return [...older, ...newer].map((m) => this.shape(m));
    }
    const rows = before ? this.sql('SELECT * FROM msgs WHERE id < ? ORDER BY id DESC LIMIT ?', Number(before), PAGE) : this.sql('SELECT * FROM msgs ORDER BY id DESC LIMIT ?', PAGE);
    return rows.reverse().map((m) => this.shape(m));
  }
  broadcast(msg) { const s = JSON.stringify(msg); for (const w of this.ctx.getWebSockets()) { if (w.readyState === 1) { try { w.send(s); } catch {} } } }

  async fetch(request) {
    const url = new URL(request.url);
    const body = request.method === 'POST' ? await request.json().catch(() => ({})) : {};
    if (url.pathname === '/init') { await this.ctx.storage.put('info', { cid: body.cid, name: body.name }); return json({ ok: true }); }
    if (url.pathname === '/member') {
      if (!(await this.ctx.storage.get('info'))) await this.ctx.storage.put('info', { cid: body.cid });
      if (body.role) this.ctx.storage.sql.exec('INSERT OR REPLACE INTO members (uid, role) VALUES (?, ?)', body.uid, body.role);
      else {
        this.ctx.storage.sql.exec('DELETE FROM members WHERE uid = ?', body.uid);
        for (const w of this.ctx.getWebSockets(body.uid)) { try { w.close(4003, 'Non sei più nella community'); } catch {} }
      }
      return json({ ok: true });
    }
    // messaggio di sistema dall'Hub (partita avviata): non raggiungibile dall'app
    if (url.pathname === '/post') {
      const t = Date.now();
      this.ctx.storage.sql.exec('INSERT INTO msgs (uid, uname, avatar, text, ts, men, kind, code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', body.uid, body.uname, body.avatar || null, String(body.text || '').slice(0, 300), t, '[]', body.kind || null, body.code || null);
      const id = this.sql('SELECT last_insert_rowid() AS id')[0].id;
      this.broadcast({ t: 'msg', m: this.shape(this.sql('SELECT * FROM msgs WHERE id = ?', id)[0]) });
      return json({ ok: true, id });
    }
    if (url.pathname === '/wipe') {
      for (const w of this.ctx.getWebSockets()) { try { w.close(4004, 'Community eliminata'); } catch {} }
      await this.ctx.storage.deleteAll();
      return json({ ok: true });
    }
    // da qui in poi: richieste dell'app, già autenticate dal worker (header x-user)
    let user; try { user = JSON.parse(request.headers.get('x-user') || 'null'); } catch {}
    if (!user?.id || !this.role(user.id)) return json({ error: 'Non sei in questa community' }, 403);
    if (url.pathname === '/history') return json({ msgs: this.page({ before: url.searchParams.get('before'), around: url.searchParams.get('around') }) });
    if (url.pathname === '/audio') {
      const row = this.sql('SELECT a.data FROM audio a JOIN msgs m ON m.id = a.id WHERE a.id = ? AND m.del = 0', Number(url.searchParams.get('id')))[0];
      if (!row) return new Response('', { status: 404 });
      const [head, b64] = row.data.split(',');
      return new Response(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)), { headers: { 'content-type': head.slice(5, head.indexOf(';')), 'cache-control': 'private, max-age=31536000, immutable' } });
    }
    if (url.pathname === '/ws') {
      if (request.headers.get('Upgrade') !== 'websocket') return json({ ok: true });
      const pair = new WebSocketPair();
      this.ctx.acceptWebSocket(pair[1], [user.id]);
      pair[1].serializeAttachment({ uid: user.id, uname: user.username, avatar: user.avatar });
      const around = url.searchParams.get('around');
      pair[1].send(JSON.stringify({ t: 'history', msgs: this.page({ around }), around: around ? Number(around) : null }));
      return new Response(null, { status: 101, webSocket: pair[0] });
    }
    return json({ error: 'Non trovato' }, 404);
  }

  async webSocketMessage(ws, raw) {
    let m; try { m = JSON.parse(raw); } catch { return; }
    const a = ws.deserializeAttachment() || {};
    const role = this.role(a.uid);
    if (!role) { try { ws.close(4003, 'Non sei più nella community'); } catch {} return; }
    const err = (msg) => { try { ws.send(JSON.stringify({ t: 'error', msg })); } catch {} };
    if (m.t === 'more') { try { ws.send(JSON.stringify({ t: 'older', msgs: this.page({ before: m.before }) })); } catch {} return; }
    if (m.t === 'del') {
      const row = this.sql('SELECT * FROM msgs WHERE id = ?', Number(m.id))[0];
      if (!row) return;
      const modRole = this.role(row.uid);
      const can = row.uid === a.uid || role === 'owner' || (role === 'admin' && modRole === 'member');
      if (!can) return err('Non puoi cancellare questo messaggio');
      this.ctx.storage.sql.exec('UPDATE msgs SET del = 1 WHERE id = ?', row.id);
      return this.broadcast({ t: 'del', id: row.id });
    }
    if (m.t === 'profile') { ws.serializeAttachment({ ...a, uname: String(m.uname || a.uname).slice(0, 16), avatar: m.avatar ?? a.avatar }); return; }
    if (m.t !== 'msg') return;
    // anti-spam: un messaggio ogni 0,7 secondi e al massimo 20 al minuto
    const t = Date.now();
    const list = (this.rate.get(a.uid) || []).filter((x) => t - x < 60_000);
    if (list.length && t - list[list.length - 1] < 700) return err('Piano: un messaggio alla volta');
    if (list.length >= 20) return err('Troppi messaggi: aspetta un attimo');
    list.push(t); this.rate.set(a.uid, list);
    // messaggio vocale (massimo 20 secondi)
    if (m.audio) {
      if (typeof m.audio !== 'string' || !/^data:audio\/(wav|mp4|aac|x-m4a|webm|ogg);base64,/.test(m.audio) || m.audio.length > 700_000) return err('Messaggio vocale non valido o troppo lungo');
      const secs = Math.max(0.3, Math.min(20, Number(m.secs) || 0));
      this.ctx.storage.sql.exec('INSERT INTO msgs (uid, uname, avatar, text, ts, men, kind, secs) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', a.uid, a.uname, a.avatar || null, '🎙️ Messaggio vocale', t, '[]', 'audio', secs);
      const id = this.sql('SELECT last_insert_rowid() AS id')[0].id;
      this.ctx.storage.sql.exec('INSERT INTO audio (id, data, ts) VALUES (?, ?, ?)', id, m.audio, t);
      // i vocali più vecchi di 60 giorni si cancellano (resta il messaggio)
      this.ctx.storage.sql.exec('DELETE FROM audio WHERE ts < ?', t - 60 * 864e5);
      return this.broadcast({ t: 'msg', m: this.shape(this.sql('SELECT * FROM msgs WHERE id = ?', id)[0]) });
    }
    const text = String(m.text || '').replace(/\s+$/, '').slice(0, 1000);
    if (!text.trim()) return;
    const men = [...new Set([].concat(m.mentions || []).map(String))].filter((u) => u !== a.uid && this.role(u)).slice(0, 5);
    this.ctx.storage.sql.exec('INSERT INTO msgs (uid, uname, avatar, text, ts, men) VALUES (?, ?, ?, ?, ?, ?)', a.uid, a.uname, a.avatar || null, text, t, JSON.stringify(men));
    const id = this.sql('SELECT last_insert_rowid() AS id')[0].id;
    this.broadcast({ t: 'msg', m: { id, uid: a.uid, uname: a.uname, avatar: a.avatar || null, text, ts: t, men, del: false } });
    if (men.length) {
      const info = (await this.ctx.storage.get('info')) || {};
      try { await this.env.HUB.get(this.env.HUB.idFromName('hub')).fetch('https://h/internal/mention', { method: 'POST', body: JSON.stringify({ cid: info.cid, mid: id, from: a.uid, to: men, text }) }); } catch {}
    }
  }
}
