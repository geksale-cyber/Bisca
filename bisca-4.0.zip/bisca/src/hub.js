// Hub: account, sessioni, amici, presenza online, notifiche (in app e push), statistiche, ranking,
// elenco delle community con membri e ruoli. Un solo Durable Object con database SQLite.
// Le chat delle community stanno invece ognuna nel proprio Durable Object (src/community.js).

import { DurableObject } from 'cloudflare:workers';
import * as RT from '../public/lib/rating.js';
import * as SE from '../public/lib/season.js';
import { isQuiet, cleanQuiet, defaultQuiet } from '../public/lib/quiet.js';
import { genVapid, sendPush } from './push.js';

const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
const enc = new TextEncoder();
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const randHex = (n) => hex(crypto.getRandomValues(new Uint8Array(n)));
const ALNUM = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const randCode = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => ALNUM[b % ALNUM.length]).join('');
const sha = async (s) => hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));
const now = () => Date.now();

// Username: da 3 a 20 caratteri; lettere (anche accentate), numeri, spazi singoli, punto, trattino, trattino basso, apostrofo.
// Deve iniziare con una lettera o un numero. Maiuscole e minuscole contano come uguali.
export const USERNAME_RE = /^(?=.{3,20}$)[\p{L}\p{N}](?:[\p{L}\p{N}._'-]| (?! ))*$/u;
export const USERNAME_RULE = 'Username: da 3 a 20 caratteri, inizia con una lettera o un numero. Vanno bene lettere (anche accentate), numeri, spazi, punto, trattino e apostrofo.';
export const PASSWORD_MIN = 4;
export const cleanUsername = (s) => String(s || '').normalize('NFC').replace(/\s+/g, ' ').trim();
const PBKDF2_ITER = 100000;
const INVITE_TTL = 15 * 60 * 1000;
const CALL_COOLDOWN = 30 * 60 * 1000;
const MENTION_GAP = 60 * 1000; // stessa persona che menziona lo stesso utente: al massimo una push al minuto

async function hashPassword(pw, saltHex) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const salt = Uint8Array.from(saltHex.match(/../g).map((h) => parseInt(h, 16)));
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: PBKDF2_ITER }, key, 256));
}
const safeEq = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };

class Fail extends Error {}
const fail = (msg) => { throw new Fail(msg); };

// "iPhone · Safari 17" e simili, dal browser
function deviceOf(ua = '') {
  const os = /iPhone|iPad/.test(ua) ? (/iPad/.test(ua) ? 'iPad' : 'iPhone') + (ua.match(/OS (\d+)_/) ? ' iOS ' + ua.match(/OS (\d+)_/)[1] : '') : /Android/.test(ua) ? 'Android' + (ua.match(/Android (\d+)/) ? ' ' + ua.match(/Android (\d+)/)[1] : '') : /Mac OS/.test(ua) ? 'Mac' : /Windows/.test(ua) ? 'Windows' : 'altro';
  const br = /CriOS|Chrome/.test(ua) && !/Edg/.test(ua) ? 'Chrome' : /Edg/.test(ua) ? 'Edge' : /Firefox|FxiOS/.test(ua) ? 'Firefox' : /Safari/.test(ua) ? 'Safari' : '';
  return `${os}${br ? ' · ' + br : ''}${/standalone/.test(ua) ? ' (app)' : ''}`;
}
const HB_STALE = 90_000; // presenza: senza battito per 90 s si è offline
export class Hub extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.env = env;
    const q = (s) => ctx.storage.sql.exec(s);
    q(`CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, uname TEXT UNIQUE, name TEXT, salt TEXT, hash TEXT, avatar TEXT, created INTEGER,
      name_changes INTEGER DEFAULT 0, rating REAL DEFAULT ${RT.START}, rated INTEGER DEFAULT 0, mp_games INTEGER DEFAULT 0, mp_wins INTEGER DEFAULT 0,
      sp_games INTEGER DEFAULT 0, sp_wins INTEGER DEFAULT 0, seen INTEGER, banned INTEGER DEFAULT 0, tz TEXT, notif TEXT, quiet TEXT)`);
    q('CREATE TABLE IF NOT EXISTS sessions (hash TEXT PRIMARY KEY, uid TEXT, created INTEGER, seen INTEGER)');
    q('CREATE INDEX IF NOT EXISTS sess_uid ON sessions(uid)');
    q('CREATE TABLE IF NOT EXISTS friends (a TEXT, b TEXT, status TEXT, created INTEGER, PRIMARY KEY (a, b))');
    q('CREATE TABLE IF NOT EXISTS notifs (id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT, type TEXT, data TEXT, created INTEGER, read INTEGER DEFAULT 0, expires INTEGER)');
    q('CREATE INDEX IF NOT EXISTS notif_uid ON notifs(uid, id)');
    q('CREATE TABLE IF NOT EXISTS games (gkey TEXT PRIMARY KEY, mode TEXT, created INTEGER, rated INTEGER, grp TEXT, rounds INTEGER, data TEXT)');
    q('CREATE INDEX IF NOT EXISTS games_grp ON games(grp, created)');
    q('CREATE TABLE IF NOT EXISTS gplayers (gkey TEXT, uid TEXT, place INTEGER, won INTEGER, delta REAL, PRIMARY KEY (gkey, uid))');
    q('CREATE INDEX IF NOT EXISTS gp_uid ON gplayers(uid)');
    q('CREATE TABLE IF NOT EXISTS rhist (uid TEXT, ts INTEGER, rating REAL, delta REAL, gkey TEXT)');
    q('CREATE INDEX IF NOT EXISTS rh_uid ON rhist(uid, ts)');
    q('CREATE TABLE IF NOT EXISTS comms (id TEXT PRIMARY KEY, name TEXT, lname TEXT UNIQUE, descr TEXT, public INTEGER, owner TEXT, created INTEGER)');
    q('CREATE TABLE IF NOT EXISTS cmembers (cid TEXT, uid TEXT, role TEXT, joined INTEGER, PRIMARY KEY (cid, uid))');
    q('CREATE INDEX IF NOT EXISTS cm_uid ON cmembers(uid)');
    q('CREATE TABLE IF NOT EXISTS creqs (cid TEXT, uid TEXT, kind TEXT, by TEXT, created INTEGER, PRIMARY KEY (cid, uid, kind))');
    q('CREATE TABLE IF NOT EXISTS calls (cid TEXT PRIMARY KEY, code TEXT, by TEXT, created INTEGER)');
    q('CREATE TABLE IF NOT EXISTS callcool (cid TEXT, uid TEXT, ts INTEGER, PRIMARY KEY (cid, uid))');
    q('CREATE TABLE IF NOT EXISTS pushsubs (endpoint TEXT PRIMARY KEY, uid TEXT, p256dh TEXT, auth TEXT, created INTEGER)');
    q('CREATE INDEX IF NOT EXISTS ps_uid ON pushsubs(uid)');
    for (const col of ['admin INTEGER DEFAULT 0', 'admin_pw TEXT', 'photo TEXT', 'photo_v INTEGER']) { try { q(`ALTER TABLE users ADD COLUMN ${col}`); } catch {} }
    for (const col of ['logo TEXT', 'logo_v INTEGER']) { try { q(`ALTER TABLE comms ADD COLUMN ${col}`); } catch {} }
    try { q('ALTER TABLE calls ADD COLUMN notified INTEGER DEFAULT 0'); } catch {}
    for (const col of ['n INTEGER', 'calls INTEGER', 'exact INTEGER', 'bcall INTEGER', 'bzero INTEGER', 'surv INTEGER', 'ts INTEGER']) { try { q(`ALTER TABLE gplayers ADD COLUMN ${col}`); } catch {} }
    // 3.0: classifica a stagioni (punti per partita), sfide del giorno, oggetti da sbloccare
    q('CREATE TABLE IF NOT EXISTS spoints (id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT, season TEXT, day TEXT, gkey TEXT, kind TEXT, raw REAL, pts REAL, ts INTEGER)');
    q('CREATE INDEX IF NOT EXISTS sp_season ON spoints(season, uid)');
    q('CREATE INDEX IF NOT EXISTS sp_uid ON spoints(uid, ts)');
    q('CREATE TABLE IF NOT EXISTS daily (uid TEXT, day TEXT, started INTEGER, done INTEGER, ok INTEGER, PRIMARY KEY (uid, day))');
    q('CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT)');
    // oggetti: avatar bloccati, accessori, dorsi delle carte, emote. cond: free | pts | wins | king
    q('CREATE TABLE IF NOT EXISTS items (id TEXT PRIMARY KEY, kind TEXT, name TEXT, cond TEXT, n INTEGER, data TEXT, ord INTEGER, created INTEGER, hidden INTEGER DEFAULT 0, v INTEGER DEFAULT 1)');
    q('CREATE TABLE IF NOT EXISTS unlocks (uid TEXT, item TEXT, ts INTEGER, seen INTEGER DEFAULT 0, PRIMARY KEY (uid, item))');
    q('CREATE TABLE IF NOT EXISTS assets (id TEXT PRIMARY KEY, mime TEXT, data BLOB, v INTEGER DEFAULT 1)');
    // posizione di ogni accessorio su ogni avatar (dalla tavola dell'admin): centro x/y e larghezza in frazioni
    // dell'immagine intera dell'avatar, rotazione in gradi; off = su questo avatar non va
    // 4.0: errori arrivati dai telefoni (per l'admin)
    // 4.0: chi è stato attivo in un giorno (per i numeri da "data room" nell'admin)
    // 4.0: chat privata 1:1 (solo i due possono leggerla), blocchi, richieste di password dimenticata
    q('CREATE TABLE IF NOT EXISTS dms (id INTEGER PRIMARY KEY, a TEXT, b TEXT, sender TEXT, text TEXT, ts INTEGER, rd INTEGER DEFAULT 0)');
    q('CREATE INDEX IF NOT EXISTS dms_pair ON dms (a, b, id)');
    q('CREATE TABLE IF NOT EXISTS blocks (uid TEXT, other TEXT, PRIMARY KEY (uid, other))');
    q('CREATE TABLE IF NOT EXISTS pwreq (id INTEGER PRIMARY KEY, ts INTEGER, uname TEXT, contact TEXT, uid TEXT, done INTEGER DEFAULT 0)');
    // 4.0: codice casuale salvato nel browser (non un ID del telefono): serve all'admin per vedere
    // account forse collegati, come indizio e non come prova
    q('CREATE TABLE IF NOT EXISTS devs (uid TEXT, dev TEXT, first INTEGER, last INTEGER, PRIMARY KEY (uid, dev))');
    q('CREATE TABLE IF NOT EXISTS act (day TEXT, uid TEXT, PRIMARY KEY (day, uid))');
    q('CREATE TABLE IF NOT EXISTS errs (id INTEGER PRIMARY KEY, ts INTEGER, uid TEXT, kind TEXT, msg TEXT, stack TEXT, ua TEXT, url TEXT)');
    q('CREATE TABLE IF NOT EXISTS places (av TEXT, acc TEXT, x REAL, y REAL, s REAL, r REAL, off INTEGER DEFAULT 0, f INTEGER DEFAULT 0, PRIMARY KEY (av, acc))');
    try { q('ALTER TABLE places ADD COLUMN f INTEGER DEFAULT 0'); } catch {}
    for (const col of ['acc TEXT', 'back TEXT', 'clip TEXT', 'rx TEXT']) { try { q(`ALTER TABLE users ADD COLUMN ${col}`); } catch {} }
    try { q('ALTER TABLE unlocks ADD COLUMN gift INTEGER DEFAULT 0'); } catch {}
    try { q('ALTER TABLE daily ADD COLUMN tries INTEGER DEFAULT 1'); } catch {}
    this.fails = new Map(); // tentativi di accesso sbagliati per username
    ctx.blockConcurrencyWhile(async () => { this.migrate3(); this.migrate4(); this.seedItems(); this.seedAcc(); this.backfillAct(); });
    this.mentionGap = new Map();
  }

  sql(s, ...a) { return this.ctx.storage.sql.exec(s, ...a).toArray(); }
  one(s, ...a) { return this.sql(s, ...a)[0] || null; }
  run(s, ...a) { this.ctx.storage.sql.exec(s, ...a); }

  // ------------------------------------------------------------ utenti
  user(id) { return id ? this.one('SELECT * FROM users WHERE id = ?', id) : null; }
  userByName(n) { return this.one('SELECT * FROM users WHERE uname = ?', String(n || '').toLowerCase()); }
  pub(u, extra = {}) {
    if (!u) return null;
    return { id: u.id, username: u.name, avatar: u.avatar || null, rating: Math.round(u.rating), rated: u.rated, ...this.look(u), ...extra };
  }
  // come si presenta al tavolo: dorso delle carte e le sue 4 reazioni vocali
  look(u) {
    const king = this.kings().has(u.id);
    let acc = [];
    if (this.accOn()) {
      try { acc = JSON.parse(u.acc || '[]'); } catch {}
      const ok = new Set(this.sql("SELECT id FROM items WHERE kind = 'acc' AND cond != 'king' AND (hidden = 0 OR id IN (SELECT item FROM unlocks WHERE uid = ? AND gift = 1))", u.id).map((r) => r.id));
      acc = acc.filter((x) => ok.has(x));
      if (king) for (const r of this.sql("SELECT id FROM items WHERE kind = 'acc' AND hidden = 0 AND cond = 'king'")) acc.push(r.id);
    }
    return { back: u.back || null, rx: this.reactions(u), king, acc };
  }
  // Le 4 reazioni vocali: quelle scelte (di base dall'admin o registrate da sé); i posti vuoti
  // prendono le prime reazioni di base per tutti.
  reactions(u) {
    let mine = [];
    try { mine = JSON.parse(u.rx || '[]'); } catch {}
    const base = this.sql("SELECT id, name, v, cond FROM items WHERE kind = 'emote' AND hidden = 0 AND data LIKE '%\"asset\":true%' ORDER BY ord, created");
    const byId = Object.fromEntries(base.map((b) => [b.id, b]));
    for (const g of this.sql("SELECT i.id, i.name, i.v, i.cond FROM unlocks u JOIN items i ON i.id = u.item WHERE u.uid = ? AND u.gift = 1 AND i.kind = 'emote' AND i.hidden = 1", u.id)) byId[g.id] = g;
    const used = new Set();
    const out = [];
    for (let i = 0; i < 4; i++) {
      const x = mine[i];
      if (x?.own) { out.push({ id: x.own, name: x.name || 'La mia', v: 1, own: true }); continue; }
      const b = x?.id && byId[x.id];
      if (b && this.owns(u, b)) { out.push({ id: b.id, name: b.name, v: b.v || 1 }); used.add(b.id); continue; }
      out.push(null);
    }
    // posti vuoti: le reazioni di base libere non ancora usate
    const free = base.filter((b) => b.cond === 'free' && !used.has(b.id));
    return out.map((r) => r || (free.length ? (({ id, name, v }) => ({ id, name, v: v || 1 }))(free.shift()) : null));
  }
  async sessionUser(token) {
    if (!token || typeof token !== 'string') return null;
    const s = this.one('SELECT * FROM sessions WHERE hash = ?', await sha(token));
    if (!s) return null;
    const u = this.user(s.uid);
    if (!u || u.banned) return null;
    if (now() - (s.seen || 0) > 3600_000) this.run('UPDATE sessions SET seen = ? WHERE hash = ?', now(), s.hash);
    return u;
  }
  async newSession(uid) {
    const token = randHex(24);
    this.run('INSERT INTO sessions (hash, uid, created, seen) VALUES (?, ?, ?, ?)', await sha(token), uid, now(), now());
    return token;
  }
  me(u) {
    const n = this.one('SELECT COUNT(*) AS n FROM notifs WHERE uid = ? AND read = 0 AND (expires IS NULL OR expires > ?)', u.id, now()).n;
    return {
      ...this.pub(u), nameChanges: u.name_changes, canRename: u.name_changes < 1,
      notif: this.notifCfg(u), quiet: u.quiet ? JSON.parse(u.quiet) : defaultQuiet(), tz: u.tz || 'Europe/Rome',
      admin: !!u.admin, unread: n, dmUnread: this.one('SELECT COUNT(*) AS n FROM dms WHERE (a = ? OR b = ?) AND sender != ? AND rd = 0', u.id, u.id, u.id).n,
      pwReq: u.admin ? this.one('SELECT COUNT(*) AS n FROM pwreq WHERE done = 0').n : 0, pushDevices: this.one('SELECT COUNT(*) AS n FROM pushsubs WHERE uid = ?', u.id).n,
      unseenUnlocks: this.one('SELECT COUNT(*) AS n FROM unlocks WHERE uid = ? AND seen = 0', u.id).n,
    };
  }
  notifCfg(u) { const d = { invites: true, calls: true, mentions: true, turn: true }; try { return { ...d, ...(u.notif ? JSON.parse(u.notif) : {}) }; } catch { return d; } }
  checkAvatar(a) { return a == null || a === '' ? null : String(a).slice(0, 60); }

  // ------------------------------------------------------------ stagioni
  kvGet(k) { return this.one('SELECT v FROM kv WHERE k = ?', k)?.v ?? null; }
  kvSet(k, v) { this.run('INSERT OR REPLACE INTO kv (k, v) VALUES (?, ?)', k, String(v)); }
  seasonTotal(uid, season) { return this.one('SELECT COALESCE(SUM(pts), 0) AS t FROM spoints WHERE uid = ? AND season = ?', uid, season).t; }
  addPoints(uid, gkey, kind, raw, ts = now()) {
    const season = SE.seasonOf(ts);
    const pts = SE.applyFloor(this.seasonTotal(uid, season), raw);
    this.run('INSERT INTO spoints (uid, season, day, gkey, kind, raw, pts, ts) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', uid, season, SE.dayOf(ts), gkey, kind, raw, pts, ts);
    return pts;
  }
  // punti e livello di una partita online già registrata in games/gplayers (anche per il ricalcolo)
  mpScore(gkey, ts, ratingOnly = false) {
    const rows = this.sql('SELECT uid, place, surv FROM gplayers WHERE gkey = ?', gkey).filter((r) => r.uid && this.user(r.uid));
    const ranked = SE.rerank(rows);
    const places = ranked.map((r) => r.place);
    const pts = {};
    if (!ratingOnly) for (const r of ranked) pts[r.uid] = this.addPoints(r.uid, gkey, 'mp', SE.gamePoints(r.place, places), ts);
    const users = Object.fromEntries(ranked.map((r) => [r.uid, this.user(r.uid)]));
    const deltas = RT.rate(ranked.map((r) => ({ uid: r.uid, rating: users[r.uid].rating, games: users[r.uid].rated, place: r.place, surv: r.surv })));
    for (const r of ranked) {
      const d = deltas[r.uid] || 0;
      this.run('UPDATE gplayers SET delta = ? WHERE gkey = ? AND uid = ?', d, gkey, r.uid);
      this.run('UPDATE users SET rating = rating + ?, rated = rated + 1 WHERE id = ?', d, r.uid);
      this.run('INSERT INTO rhist (uid, ts, rating, delta, gkey) VALUES (?, ?, ?, ?, ?)', r.uid, ts, this.user(r.uid).rating, d, gkey);
    }
    return { pts, deltas };
  }
  // Una volta sola: le partite online già giocate si ricalcolano con le regole nuove
  // (punti a stagioni e livello senza media). Il single player conta da qui in avanti.
  migrate3() {
    if (this.kvGet('migr3')) return;
    this.run('DELETE FROM spoints');
    this.run('DELETE FROM rhist');
    this.run(`UPDATE users SET rating = ${RT.START}, rated = 0`);
    for (const g of this.sql("SELECT gkey, created FROM games WHERE mode = 'mp' AND rated = 1 ORDER BY created")) this.mpScore(g.gkey, g.created);
    this.kvSet('migr3', now());
  }
  // 4.0: il livello si ricalcola con la formula nuova (media × radice del tavolo, K 40/24).
  // I punti della classifica mensile non si toccano.
  migrate4() {
    if (this.kvGet('migr4')) return;
    this.recomputeRatings();
    this.kvSet('migr4', now());
  }
  // classifica di una stagione
  standings(season) {
    const rows = this.sql(`SELECT s.uid, SUM(s.pts) AS pts, SUM(CASE WHEN s.kind = 'mp' THEN 1 ELSE 0 END) AS mp, SUM(CASE WHEN s.kind = 'sp' THEN 1 ELSE 0 END) AS sp,
        SUM(CASE WHEN s.kind = 'daily' THEN 1 ELSE 0 END) AS daily, SUM(CASE WHEN s.kind = 'mp' THEN s.pts ELSE 0 END) AS mpPts,
        SUM(CASE WHEN s.kind = 'sp' THEN s.pts ELSE 0 END) AS spPts, SUM(CASE WHEN s.kind = 'daily' THEN s.pts ELSE 0 END) AS dPts
      FROM spoints s JOIN users u ON u.id = s.uid WHERE s.season = ? AND u.banned = 0 GROUP BY s.uid`, season);
    const wins = Object.fromEntries(this.sql(`SELECT s.uid, COUNT(*) AS w FROM spoints s JOIN gplayers g ON g.gkey = s.gkey AND g.uid = s.uid WHERE s.season = ? AND s.kind = 'mp' AND g.won = 1 GROUP BY s.uid`, season).map((r) => [r.uid, r.w]));
    rows.sort((a, b) => b.pts - a.pts || (wins[b.uid] || 0) - (wins[a.uid] || 0));
    let pos = 0, prev = null;
    return rows.map((r, i) => { if (prev == null || r.pts !== prev) pos = i + 1; prev = r.pts; return { ...r, pos, wins: wins[r.uid] || 0, games: r.mp + r.sp }; });
  }
  // Re della Bisca: chi ha vinto la stagione scorsa (a pari punti, tutti)
  kings() {
    const season = SE.prevSeason(SE.seasonOf());
    const key = `kings:${season}`;
    let v = this.kvGet(key);
    if (v == null || this.kvGet('kingsAt') < now() - 600_000) {
      const st = this.standings(season).filter((r) => r.pos === 1 && r.pts > 0);
      v = JSON.stringify(st.map((r) => r.uid));
      this.kvSet(key, v); this.kvSet('kingsAt', now());
    }
    return new Set(JSON.parse(v));
  }
  // ------------------------------------------------------------ oggetti da sbloccare
  seedItems() {
    if (this.kvGet('items1')) return;
    const add = (id, kind, name, cond, n, data, ord) => this.run('INSERT OR IGNORE INTO items (id, kind, name, cond, n, data, ord, created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', id, kind, name, cond, n, JSON.stringify(data), ord, now());
    // niente oggetti di partenza: dorsi e reazioni vocali di base li carica l'admin
    void add;
    this.kvSet('items1', now());
  }
  // accessori di partenza (disegni dell'app: l'admin può cambiarne l'immagine, toglierli, aggiungerne)
  seedAcc() {
    if (this.kvGet('items2')) return;
    const add = (id, name, cond, n, ord) => this.run('INSERT OR IGNORE INTO items (id, kind, name, cond, n, data, ord, created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', id, 'acc', name, cond, n, JSON.stringify({ src: `acc/${id}.svg` }), ord, now());
    add('sigaro', 'Sigaro', 'wins', 3, 1); add('berretto', 'Berretto', 'wins', 10, 2); add('occhiali', 'Occhiali da corsa', 'wins', 20, 3);
    add('telefono', 'Telefono in mano', 'wins', 35, 4); add('corona', 'Corona del Re della Bisca', 'king', 0, 9);
    this.kvSet('items2', now());
  }
  accOn() { return this.kvGet('accOn') === '1'; }
  places() {
    const out = {};
    for (const r of this.sql('SELECT * FROM places')) (out[r.av] ||= {})[r.acc] = r.off ? 0 : { x: r.x, y: r.y, s: r.s, r: r.r, ...(r.f ? { f: 1 } : {}) };
    return out;
  }
  itemList(all = false) {
    // finché l'admin non accende gli accessori, i giocatori non li vedono
    const where = all ? '' : `WHERE hidden = 0${this.accOn() ? '' : " AND kind != 'acc'"}`;
    return this.sql(`SELECT * FROM items ${where} ORDER BY kind, ord, created`).map((i) => ({ id: i.id, kind: i.kind, name: i.name, cond: i.cond, n: i.n, data: JSON.parse(i.data || '{}'), hidden: !!i.hidden, v: i.v }));
  }
  progress(u) { return { pts: this.careerPoints(u.id), wins: u.mp_wins || 0 }; }
  owns(u, item) {
    if (!item) return false;
    // oggetto nascosto (esclusivo): ce l'ha solo chi l'ha ricevuto in regalo
    if (item.hidden || item.excl) return item.cond !== 'king' && this.gifted(u, item.id);
    if (item.cond === 'free') return true;
    if (item.cond === 'king') return this.kings().has(u.id);
    if (this.one('SELECT 1 AS x FROM unlocks WHERE uid = ? AND item = ?', u.id, item.id)) return true;
    // traguardo già raggiunto ma sblocco non ancora registrato (es. l'admin ha appena abbassato la soglia)
    const pr = this.progress(u);
    return (item.cond === 'pts' ? pr.pts : pr.wins) >= (item.n || 0);
  }
  noteDev(uid, dev) {
    const d = String(dev || '').replace(/[^a-z0-9]/gi, '').slice(0, 32);
    if (d.length < 8) return;
    this.run('INSERT INTO devs (uid, dev, first, last) VALUES (?, ?, ?, ?) ON CONFLICT (uid, dev) DO UPDATE SET last = excluded.last', uid, d, now(), now());
  }
  // account che hanno usato lo stesso browser (indizio, non prova)
  linked(uid) {
    return this.sql('SELECT DISTINCT d2.uid FROM devs d1 JOIN devs d2 ON d1.dev = d2.dev AND d2.uid != d1.uid WHERE d1.uid = ?', uid).map((r) => r.uid).filter((x) => this.user(x));
  }
  // Testa a testa tra due account nelle partite online giocate insieme
  headToHead(a, b) {
    const rows = this.sql("SELECT g1.place AS pa, g2.place AS pb FROM gplayers g1 JOIN gplayers g2 ON g1.gkey = g2.gkey AND g2.uid = ? JOIN games g ON g.gkey = g1.gkey WHERE g1.uid = ? AND g.mode = 'mp'", b, a);
    return { games: rows.length, ahead: rows.filter((r) => r.pa < r.pb).length, behind: rows.filter((r) => r.pa > r.pb).length };
  }
  // Riepilogo di una stagione per un account (stile "Wrapped")
  wrapped(uid, season) {
    const u = this.user(uid);
    const st = this.standings(season);
    const mine = st.find((r) => r.uid === uid);
    const [y, m] = season.split('-').map(Number);
    const t0 = Date.UTC(y, m - 1, 1) - 2 * 3600e3, t1 = Date.UTC(y, m, 1) + 2 * 3600e3;
    const gp = this.sql("SELECT gp.*, g.mode FROM gplayers gp JOIN games g ON g.gkey = gp.gkey WHERE gp.uid = ? AND COALESCE(gp.ts, g.created) BETWEEN ? AND ?", uid, t0, t1)
      .filter((r) => SE.seasonOf(r.ts || 0) === season);
    const mp = gp.filter((r) => r.mode === 'mp'), sp = gp.filter((r) => r.mode === 'sp');
    // la vittoria più bella: la partita online vinta col tavolo più grande
    const best = mp.filter((r) => r.won).sort((a, b) => (b.n || 0) - (a.n || 0))[0];
    // chi ti ha battuto di più / chi hai battuto di più
    const vs = new Map();
    for (const r of mp) for (const o of this.sql('SELECT uid, place FROM gplayers WHERE gkey = ? AND uid IS NOT NULL AND uid != ?', r.gkey, uid)) {
      const x = vs.get(o.uid) || { beat: 0, lost: 0 };
      if (o.place < r.place) x.lost++; else if (o.place > r.place) x.beat++;
      vs.set(o.uid, x);
    }
    const top = (k) => { const e = [...vs.entries()].filter(([, x]) => x[k] > 0).sort((a, b) => b[1][k] - a[1][k])[0]; return e && this.user(e[0]) ? { user: this.pub(this.user(e[0])), n: e[1][k] } : null; };
    const daily = this.one('SELECT COUNT(*) AS n FROM daily WHERE uid = ? AND ok = 1 AND day LIKE ?', uid, season + '-%').n;
    return {
      season, name: SE.seasonName(season), user: this.pub(u), pts: mine?.pts || 0, pos: mine?.pos || null, of: st.length,
      king: st[0]?.uid === uid && SE.seasonOf() !== season,
      mp: { games: mp.length, wins: mp.filter((r) => r.won).length }, sp: { games: sp.length, wins: sp.filter((r) => r.won).length },
      best: best ? { n: best.n, ts: best.ts } : null, nemesis: top('lost'), victim: top('beat'), daily,
      exact: gp.reduce((t, r) => t + (r.exact || 0), 0), calls: gp.reduce((t, r) => t + (r.calls || 0), 0),
    };
  }
  // Unione di due account (admin): resta `keep`, sparisce `drop`. Le partite passano a `keep` e i punti
  // si rimettono a posto come se fosse sempre stato un solo account.
  async merge(keepId, dropId) {
    const k = this.user(keepId), d = this.user(dropId);
    if (!k || !d || k.id === d.id) fail('Account non validi');
    const K = k.id, D = d.id;
    // partite: se erano tutti e due nella stessa partita, conta una volta sola (resta quella di chi resta)
    const both = this.sql('SELECT gkey FROM gplayers WHERE uid = ? AND gkey IN (SELECT gkey FROM gplayers WHERE uid = ?)', D, K).map((r) => r.gkey);
    for (const g of both) { this.run('DELETE FROM gplayers WHERE gkey = ? AND uid = ?', g, D); this.run('DELETE FROM spoints WHERE gkey = ? AND uid = ?', g, D); }
    this.run('UPDATE gplayers SET uid = ? WHERE uid = ?', K, D);
    // punti: si spostano, poi si tolgono i doppioni (sfida del giorno una volta, single player max 3 al giorno)
    this.run('UPDATE spoints SET uid = ? WHERE uid = ?', K, D);
    for (const r of this.sql("SELECT day, COUNT(*) AS n FROM spoints WHERE uid = ? AND kind = 'daily' GROUP BY day HAVING n > 1", K)) {
      this.run("DELETE FROM spoints WHERE uid = ? AND kind = 'daily' AND day = ? AND id NOT IN (SELECT MIN(id) FROM spoints WHERE uid = ? AND kind = 'daily' AND day = ?)", K, r.day, K, r.day);
    }
    for (const r of this.sql("SELECT day, COUNT(*) AS n FROM spoints WHERE uid = ? AND kind = 'sp' GROUP BY day HAVING n > ?", K, SE.SP_PER_DAY)) {
      this.run(`DELETE FROM spoints WHERE uid = ? AND kind = 'sp' AND day = ? AND id NOT IN (SELECT id FROM spoints WHERE uid = ? AND kind = 'sp' AND day = ? ORDER BY ts, id LIMIT ${SE.SP_PER_DAY})`, K, r.day, K, r.day);
    }
    // sfida del giorno: un giorno solo, superata se superata con uno dei due
    for (const r of this.sql('SELECT * FROM daily WHERE uid = ?', D)) {
      const mine = this.one('SELECT * FROM daily WHERE uid = ? AND day = ?', K, r.day);
      if (!mine) this.run('UPDATE daily SET uid = ? WHERE uid = ? AND day = ?', K, D, r.day);
      else { this.run('UPDATE daily SET ok = MAX(ok, ?), done = MAX(done, ?), tries = MIN(?, COALESCE(tries, 1) + COALESCE(?, 1)) WHERE uid = ? AND day = ?', r.ok, r.done, SE.DAILY_TRIES, r.tries, K, r.day); this.run('DELETE FROM daily WHERE uid = ? AND day = ?', D, r.day); }
    }
    // contatori delle partite: si ricalcolano dalle partite
    const cnt = (mode) => this.one("SELECT COUNT(*) AS g, SUM(gp.won) AS w FROM gplayers gp JOIN games g ON g.gkey = gp.gkey WHERE gp.uid = ? AND g.mode = ?", K, mode);
    const mpc = cnt('mp'), spc = cnt('sp');
    this.run('UPDATE users SET mp_games = ?, mp_wins = ?, sp_games = ?, sp_wins = ? WHERE id = ?', mpc.g, mpc.w || 0, spc.g, spc.w || 0, K);
    // oggetti, amici, community, messaggi, notifiche, attività, codici del browser
    this.run('INSERT OR IGNORE INTO unlocks (uid, item, ts, seen, gift) SELECT ?, item, ts, 1, gift FROM unlocks WHERE uid = ?', K, D);
    this.run('DELETE FROM unlocks WHERE uid = ?', D);
    for (const f of this.sql('SELECT * FROM friends WHERE a = ? OR b = ?', D, D)) {
      const a = f.a === D ? K : f.a, b2 = f.b === D ? K : f.b;
      if (a !== b2) this.run('INSERT OR IGNORE INTO friends (a, b, status, created) VALUES (?, ?, ?, ?)', a, b2, f.status, f.created);
    }
    this.run('DELETE FROM friends WHERE a = ? OR b = ?', D, D);
    this.run('INSERT OR IGNORE INTO cmembers (cid, uid, role, joined) SELECT cid, ?, role, joined FROM cmembers WHERE uid = ?', K, D);
    this.run('DELETE FROM cmembers WHERE uid = ?', D);
    this.run('DELETE FROM creqs WHERE uid = ?', D);
    for (const m of this.sql('SELECT * FROM dms WHERE a = ? OR b = ?', D, D)) {
      const x = m.a === D ? K : m.a, y = m.b === D ? K : m.b;
      if (x === y) { this.run('DELETE FROM dms WHERE id = ?', m.id); continue; }
      const [a, b2] = [x, y].sort();
      this.run('UPDATE dms SET a = ?, b = ?, sender = ? WHERE id = ?', a, b2, m.sender === D ? K : m.sender, m.id);
    }
    this.run('UPDATE notifs SET uid = ? WHERE uid = ?', K, D);
    this.run('INSERT OR IGNORE INTO act (day, uid) SELECT day, ? FROM act WHERE uid = ?', K, D);
    this.run('DELETE FROM act WHERE uid = ?', D);
    this.run('INSERT OR IGNORE INTO devs (uid, dev, first, last) SELECT ?, dev, first, last FROM devs WHERE uid = ?', K, D);
    this.run('DELETE FROM devs WHERE uid = ?', D);
    this.run('UPDATE pwreq SET uid = ? WHERE uid = ?', K, D);
    this.run('DELETE FROM blocks WHERE uid = ? OR other = ?', D, D);
    this.run('DELETE FROM pushsubs WHERE uid = ?', D);
    this.run('DELETE FROM sessions WHERE uid = ?', D);
    this.run('DELETE FROM rhist WHERE uid = ?', D);
    for (const w of this.socks(D)) { try { w.close(4001, 'account unito'); } catch {} }
    this.run('DELETE FROM users WHERE id = ?', D);
    // il livello si ricalcola per tutti dalle partite (come al passaggio alla 4.0)
    this.recomputeRatings();
    await this.checkUnlocks(K);
    return { ok: true };
  }
  recomputeRatings() {
    this.run('DELETE FROM rhist');
    this.run(`UPDATE users SET rating = ${RT.START}, rated = 0`);
    for (const g of this.sql("SELECT gkey, created FROM games WHERE mode = 'mp' AND rated = 1 ORDER BY created")) this.mpScore(g.gkey, g.created, true);
  }
  markActive(uid) { try { this.run('INSERT OR IGNORE INTO act (day, uid) VALUES (?, ?)', SE.dayOf(), uid); } catch {} }
  // i giorni di attività passati si ricavano dalle partite giocate (una volta sola)
  backfillAct() {
    if (this.kvGet('act1')) return;
    for (const r of this.sql('SELECT uid, ts FROM gplayers WHERE uid IS NOT NULL AND ts IS NOT NULL')) this.run('INSERT OR IGNORE INTO act (day, uid) VALUES (?, ?)', SE.dayOf(r.ts), r.uid);
    for (const r of this.sql('SELECT uid, ts FROM spoints')) this.run('INSERT OR IGNORE INTO act (day, uid) VALUES (?, ?)', SE.dayOf(r.ts), r.uid);
    for (const u of this.sql('SELECT id, created FROM users')) this.run('INSERT OR IGNORE INTO act (day, uid) VALUES (?, ?)', SE.dayOf(u.created), u.id);
    this.kvSet('act1', now());
  }
  // numeri da "data room": attivi al giorno/mese, ritorno dopo 7 e 30 giorni, partite al giorno
  metrics() {
    const today = SE.dayOf();
    const dayMs = 864e5;
    const back = (n) => SE.dayOf(now() - n * dayMs);
    const days = [];
    const games = Object.fromEntries(this.sql('SELECT mode, created FROM games WHERE created > ?', now() - 31 * dayMs).reduce((m, g) => { const d = SE.dayOf(g.created); const k = d + '|' + g.mode; m.set(k, (m.get(k) || 0) + 1); return m; }, new Map()));
    const act = Object.fromEntries(this.sql('SELECT day, COUNT(*) AS n FROM act WHERE day >= ? GROUP BY day', back(30)).map((r) => [r.day, r.n]));
    for (let i = 29; i >= 0; i--) { const d = back(i); days.push({ day: d, active: act[d] || 0, mp: games[d + '|mp'] || 0, sp: games[d + '|sp'] || 0 }); }
    const uniq = (from) => this.one('SELECT COUNT(DISTINCT uid) AS n FROM act WHERE day >= ?', from).n;
    const users = this.sql('SELECT id, created FROM users WHERE banned = 0');
    const ret = (n) => {
      const cohort = users.filter((u) => u.created <= now() - n * dayMs);
      if (!cohort.length) return null;
      const back = cohort.filter((u) => this.one('SELECT 1 AS x FROM act WHERE uid = ? AND day >= ?', u.id, SE.dayOf(u.created + n * dayMs)));
      return { pct: Math.round((back.length / cohort.length) * 100), of: cohort.length };
    };
    return {
      today, users: users.length, newWeek: users.filter((u) => u.created > now() - 7 * dayMs).length,
      dau: act[today] || 0, wau: uniq(back(6)), mau: uniq(back(29)),
      ret7: ret(7), ret30: ret(30), days,
      gamesTotal: { mp: this.one("SELECT COUNT(*) AS n FROM games WHERE mode = 'mp'").n, sp: this.one("SELECT COUNT(*) AS n FROM games WHERE mode = 'sp'").n },
    };
  }
  gifted(u, id) { return !!this.one('SELECT 1 AS x FROM unlocks WHERE uid = ? AND item = ? AND gift = 1', u.id, id); }
  async checkUnlocks(uid) {
    const u = this.user(uid);
    if (!u) return [];
    const pr = this.progress(u);
    const got = [];
    for (const it of this.sql(`SELECT * FROM items WHERE cond IN ('pts', 'wins') AND hidden = 0${this.accOn() ? '' : " AND kind != 'acc'"}`)) {
      const val = it.cond === 'pts' ? pr.pts : pr.wins;
      if (val >= (it.n || 0) && !this.one('SELECT 1 AS x FROM unlocks WHERE uid = ? AND item = ?', uid, it.id)) {
        this.run('INSERT INTO unlocks (uid, item, ts, seen) VALUES (?, ?, ?, 0)', uid, it.id, now());
        got.push(it.id);
      }
    }
    if (got.length) this.sendTo(uid, { t: 'unlocked', items: got });
    return got;
  }
  careerPoints(uid) { return this.one('SELECT COALESCE(SUM(pts), 0) AS t FROM spoints WHERE uid = ?', uid).t; }

  stats(u) {
    const pos = u.rated > 0 ? this.one('SELECT COUNT(*) AS n FROM users WHERE rated > 0 AND rating > ? AND banned = 0', u.rating).n + 1 : null;
    const pct = (w, g) => (g ? Math.round((100 * w) / g) : 0);
    const lv = Object.fromEntries(['facile', 'medio', 'difficile'].map((k) => [k, { games: 0, wins: 0 }]));
    for (const r of this.sql("SELECT json_extract(g.data, '$.level') AS lvl, COUNT(*) AS n, SUM(gp.won) AS w FROM gplayers gp JOIN games g ON g.gkey = gp.gkey WHERE gp.uid = ? AND g.mode = 'sp' GROUP BY lvl", u.id)) {
      if (lv[r.lvl]) lv[r.lvl] = { games: r.n, wins: r.w || 0 };
    }
    // statistiche di gioco per modalità (solo le partite registrate con i dettagli)
    const ext = (mode) => {
      const a = this.one(`SELECT COUNT(*) AS g, SUM(gp.won) AS w,
          SUM(CASE WHEN gp.n >= 6 THEN 1 ELSE 0 END) AS g6, SUM(CASE WHEN gp.n >= 6 AND gp.place <= 3 THEN 1 ELSE 0 END) AS pod,
          AVG(CASE WHEN gp.n > 1 THEN (gp.place - 0.5) * 1.0 / gp.n END) AS pl,
          SUM(gp.calls) AS calls, SUM(gp.exact) AS exact, SUM(gp.bcall) AS bcall, SUM(gp.bzero) AS bzero, AVG(gp.surv) AS surv
        FROM gplayers gp JOIN games g ON g.gkey = gp.gkey WHERE gp.uid = ? AND g.mode = ?`, u.id, mode);
      const seq = this.sql('SELECT gp.won FROM gplayers gp JOIN games g ON g.gkey = gp.gkey WHERE gp.uid = ? AND g.mode = ? ORDER BY g.created', u.id, mode).map((r) => r.won);
      let cur = 0, best = 0;
      for (const w of seq) { cur = w ? cur + 1 : 0; best = Math.max(best, cur); }
      return {
        podiums: a.pod || 0, games6: a.g6 || 0,
        top: a.pl == null ? null : Math.max(1, Math.round(a.pl * 100)),
        precision: a.calls ? Math.round((100 * a.exact) / a.calls) : null, calls: a.calls || 0,
        bonusCall: a.bcall || 0, bonusZero: a.bzero || 0,
        surv: a.surv == null ? null : Math.round(a.surv * 10) / 10,
        streak: cur, bestStreak: best,
      };
    };
    const best = this.one('SELECT MAX(rating) AS m FROM rhist WHERE uid = ?', u.id).m;
    const cur = SE.seasonOf();
    const mine = this.standings(cur).find((r) => r.uid === u.id);
    const titles = this.sql('SELECT k FROM kv WHERE k LIKE ? ', 'kings:%').filter((r) => { try { return JSON.parse(this.kvGet(r.k)).includes(u.id); } catch { return false; } }).length;
    return {
      season: { name: SE.seasonName(cur), pts: mine?.pts || 0, pos: mine?.pos || null, games: mine?.games || 0 },
      career: this.careerPoints(u.id), kingTitles: titles, king: this.kings().has(u.id),
      position: pos, spLevels: lv, bestRating: Math.round(Math.max(RT.START, best || 0, u.rating)),
      mp: { games: u.mp_games, wins: u.mp_wins, losses: u.mp_games - u.mp_wins, pct: pct(u.mp_wins, u.mp_games), ...ext('mp') },
      sp: { games: u.sp_games, wins: u.sp_wins, losses: u.sp_games - u.sp_wins, pct: pct(u.sp_wins, u.sp_games), ...ext('sp') },
      history: this.sql('SELECT ts, rating, delta FROM rhist WHERE uid = ? ORDER BY ts DESC LIMIT 60', u.id).reverse().map((r) => ({ ts: r.ts, r: Math.round(r.rating), d: r.delta })),
    };
  }

  // ------------------------------------------------------------ presenza (WebSocket dell'app)
  // Un telefono conta come collegato se ha dato segni di vita (battito ogni 25 s) nell'ultimo minuto
  // e mezzo: su iPhone un'app in background resta "aperta" per il server anche quando non lo è più.
  socks(uid) {
    const t = now();
    return this.ctx.getWebSockets(uid).filter((w) => {
      if (w.readyState !== 1) return false;
      const a = w.deserializeAttachment() || {};
      if (t - (a.hb || a.at || 0) > HB_STALE) { try { w.close(4002, 'inattivo'); } catch {} return false; }
      return true;
    });
  }
  presence(uid) {
    const ws = this.socks(uid);
    if (!ws.length) return 'offline';
    return ws.some((w) => w.deserializeAttachment()?.game) ? 'game' : 'online';
  }
  sendTo(uid, msg) { const s = JSON.stringify(msg); for (const w of this.socks(uid)) { try { w.send(s); } catch {} } }
  friendIds(uid) { return this.sql("SELECT b FROM friends WHERE a = ? AND status = 'ok'", uid).map((r) => r.b); }
  announce(uid) {
    const p = this.presence(uid);
    for (const f of this.friendIds(uid)) this.sendTo(f, { t: 'presence', uid, state: p });
  }

  // ------------------------------------------------------------ notifiche
  // push: 'calls' | 'mentions' | null. Le chiamate rispettano gli orari di silenzio, le menzioni no.
  async notify(uid, type, data, { push = null, expires = null, title, body, url, tag } = {}) {
    this.run('INSERT INTO notifs (uid, type, data, created, expires) VALUES (?, ?, ?, ?, ?)', uid, type, JSON.stringify(data), now(), expires);
    const id = this.one('SELECT last_insert_rowid() AS id').id;
    const n = { id, type, data, created: now(), read: 0, expires };
    this.sendTo(uid, { t: 'notif', n });
    if (push) await this.pushTo(uid, push, { title, body, url, tag: tag || `${type}-${id}` });
    return id;
  }
  async vapid() {
    let v = await this.ctx.storage.get('vapid');
    if (!v) { v = await genVapid(); await this.ctx.storage.put('vapid', v); }
    return v;
  }
  async pushTo(uid, cat, payload) {
    const u = this.user(uid);
    if (!u || !this.notifCfg(u)[cat]) return;
    if ((cat === 'calls' || cat === 'invites') && isQuiet(u.quiet ? JSON.parse(u.quiet) : null, new Date(), u.tz || 'Europe/Rome')) return;
    const subs = this.sql('SELECT * FROM pushsubs WHERE uid = ?', uid);
    if (!subs.length) return;
    const v = await this.vapid();
    const subject = (await this.ctx.storage.get('origin')) || 'https://cartebisca.cartebisca.workers.dev';
    await Promise.allSettled(subs.map(async (s) => {
      const st = await sendPush({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, payload, v, { subject, topic: payload.tag, urgency: cat === 'mentions' ? 'high' : 'normal' });
      if (st === 404 || st === 410) this.run('DELETE FROM pushsubs WHERE endpoint = ?', s.endpoint);
    }));
  }

  // ------------------------------------------------------------ community
  comm(cid) { return this.one('SELECT * FROM comms WHERE id = ?', String(cid || '').toUpperCase()); }
  role(cid, uid) { return this.one('SELECT role FROM cmembers WHERE cid = ? AND uid = ?', cid, uid)?.role || null; }
  isAdmin(cid, uid) { const r = this.role(cid, uid); return r === 'owner' || r === 'admin'; }
  async syncMember(cid, uid, role) {
    try { await this.env.COMM.get(this.env.COMM.idFromName(cid)).fetch('https://c/member', { method: 'POST', body: JSON.stringify({ cid, uid, role }) }); } catch {}
  }
  async addMember(cid, uid, role = 'member') {
    this.run('INSERT OR REPLACE INTO cmembers (cid, uid, role, joined) VALUES (?, ?, ?, ?)', cid, uid, role, now());
    this.run('DELETE FROM creqs WHERE cid = ? AND uid = ?', cid, uid);
    await this.syncMember(cid, uid, role);
  }
  async roomInfo(code) {
    try {
      const r = await this.env.GAME.get(this.env.GAME.idFromName(code)).fetch('https://do/info');
      return r.ok ? await r.json() : null;
    } catch { return null; }
  }
  // stato di una chiamata: aperta finché la stanza è in sala d'attesa e non è piena
  async callState(cid) {
    const c = this.one('SELECT * FROM calls WHERE cid = ?', cid);
    if (!c) return null;
    const info = await this.roomInfo(c.code);
    if (!info || info.phase !== 'lobby' || !info.canJoinAsPlayer) { this.run('DELETE FROM calls WHERE cid = ?', cid); return null; }
    return { code: c.code, by: this.pub(this.user(c.by)), created: c.created, players: info.players.length, notified: !!c.notified };
  }

  // ------------------------------------------------------------ HTTP
  async fetch(request) {
    const url = new URL(request.url);
    const origin = request.headers.get('x-origin');
    if (origin && !(this._origin === origin)) { this._origin = origin; await this.ctx.storage.put('origin', origin); }
    try {
      if (url.pathname === '/ws') return this.openSocket(url);
      const body = request.method === 'POST' ? await request.json().catch(() => ({})) : {};
      if (url.pathname === '/rpc') return json(await this.rpc(body));
      if (url.pathname === '/internal/session') { const u = await this.sessionUser(body.token); return json(u ? this.pub(u) : null, u ? 200 : 401); }
      if (url.pathname === '/internal/member') { const u = await this.sessionUser(body.token); if (!u) return json(null, 401); return json({ ...this.pub(u), role: this.role(String(body.cid || '').toUpperCase(), u.id) }); }
      if (url.pathname === '/photo' || url.pathname === '/logo') {
        const row = url.pathname === '/photo' ? this.one('SELECT photo AS d FROM users WHERE id = ?', url.searchParams.get('id')) : this.one('SELECT logo AS d FROM comms WHERE id = ?', url.searchParams.get('id'));
        if (!row?.d) return new Response('', { status: 404 });
        const [head, b64] = row.d.split(',');
        return new Response(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)), { headers: { 'content-type': head.slice(5, head.indexOf(';')), 'cache-control': 'public, max-age=31536000, immutable' } });
      }
      if (url.pathname === '/asset') {
        const row = this.one('SELECT data AS d FROM assets WHERE id = ?', url.searchParams.get('id'));
        if (!row?.d) return new Response('', { status: 404 });
        const [head, b64] = String(row.d).split(',');
        return new Response(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)), { headers: { 'content-type': head.slice(5, head.indexOf(';')), 'cache-control': 'public, max-age=31536000, immutable' } });
      }
      if (url.pathname === '/internal/isadmin') { const u = await this.sessionUser(body.token); return json({ ok: !!u?.admin }, u?.admin ? 200 : 403); }
      // dalla stanza: "Tocca a te" e "La partita sta per riprendere" (niente ore di silenzio: sei in partita)
      if (url.pathname === '/internal/push') {
        for (const uid of [].concat(body.uids || []).slice(0, 20)) await this.pushTo(String(uid), 'turn', { title: String(body.title || 'Bisca').slice(0, 80), body: String(body.body || '').slice(0, 160), url: String(body.url || './').slice(0, 100), tag: String(body.tag || 'turn').slice(0, 60), vibrate: true });
        return json({ ok: true });
      }
      if (url.pathname === '/internal/mp-result') return json(await this.mpResult(body));
      if (url.pathname === '/internal/mention') return json(await this.mention(body));
      if (url.pathname === '/admin') return json(await this.admin(body));
      return json({ error: 'Non trovato' }, 404);
    } catch (e) {
      if (e instanceof Fail) return json({ error: e.message }, 400);
      return json({ error: 'Errore del server' }, 500);
    }
  }

  async openSocket(url) {
    if (url.searchParams.get('upgrade') !== '1') return json({ ok: true });
    const u = await this.sessionUser(url.searchParams.get('token'));
    if (!u) return json({ error: 'Sessione scaduta' }, 401);
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1], [u.id]);
    pair[1].serializeAttachment({ uid: u.id, game: null, at: now(), hb: now() });
    this.run('UPDATE users SET seen = ? WHERE id = ?', now(), u.id);
    this.markActive(u.id);
    this.noteDev(u.id, url.searchParams.get('dev'));
    queueMicrotask(() => { try { pair[1].send(JSON.stringify({ t: 'hello', me: this.me(u) })); } catch {} this.announce(u.id); });
    return new Response(null, { status: 101, webSocket: pair[0] });
  }
  async webSocketMessage(ws, raw) {
    let m; try { m = JSON.parse(raw); } catch { return; }
    const a = ws.deserializeAttachment() || {};
    if (m.t === 'status' || m.t === 'hb') {
      const game = m.game ? String(m.game).slice(0, 8) : null;
      const changed = game !== a.game;
      ws.serializeAttachment({ ...a, game, hb: now() });
      if (a.uid && SE.dayOf(a.hb || 0) !== SE.dayOf()) this.markActive(a.uid);
      if (changed) this.announce(a.uid);
    }
  }
  webSocketClose(ws) { const a = ws.deserializeAttachment(); if (a?.uid) { try { ws.serializeAttachment({ ...a, hb: 0 }); } catch {} this.run('UPDATE users SET seen = ? WHERE id = ?', now(), a.uid); this.announce(a.uid); } }
  webSocketError(ws) { this.webSocketClose(ws); }

  // ------------------------------------------------------------ operazioni dell'app
  async rpc(b) {
    const op = b.op;
    // senza account
    if (op === 'register') {
      const name = cleanUsername(b.username);
      const pw = String(b.password || '').trim();
      if (!USERNAME_RE.test(name)) fail(USERNAME_RULE);
      if (pw.length < PASSWORD_MIN) fail(`Password: almeno ${PASSWORD_MIN} caratteri`);
      if (this.userByName(name)) fail('Questo username è già preso: provane un altro (per esempio aggiungi un numero)');
      const salt = randHex(16);
      const id = 'u' + randHex(8);
      this.run('INSERT INTO users (id, uname, name, salt, hash, avatar, created, seen, tz) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        id, name.toLowerCase(), name, salt, await hashPassword(pw, salt), this.checkAvatar(b.avatar), now(), now(), String(b.tz || 'Europe/Rome').slice(0, 40));
      const u = this.user(id);
      this.noteDev(id, b.dev);
      return { token: await this.newSession(id), me: this.me(u) };
    }
    if (op === 'login') {
      const key = cleanUsername(b.username).toLowerCase();
      const f = (this.fails.get(key) || []).filter((t) => now() - t < 15 * 60_000);
      if (f.length >= 8) fail('Troppi tentativi: riprova tra qualche minuto');
      const u = this.userByName(key);
      const raw = String(b.password || '');
      // la tastiera del telefono a volte aggiunge uno spazio in fondo: si prova anche senza
      const ok = u && !u.banned && (safeEq(await hashPassword(raw, u.salt), u.hash) || (raw.trim() !== raw && safeEq(await hashPassword(raw.trim(), u.salt), u.hash)));
      if (!ok) { f.push(now()); this.fails.set(key, f); fail(u?.banned ? 'Account bloccato: chiedi all\'amministratore' : 'Username o password sbagliati'); }
      this.fails.delete(key);
      if (b.tz) this.run('UPDATE users SET tz = ? WHERE id = ?', String(b.tz).slice(0, 40), u.id);
      this.noteDev(u.id, b.dev);
      return { token: await this.newSession(u.id), me: this.me(this.user(u.id)) };
    }
    if (op === 'profile') {
      const viewer = await this.sessionUser(b.token);
      const u = b.uid ? this.user(b.uid) : this.userByName(b.username);
      if (!u || u.banned) fail('Utente non trovato');
      let friend = null;
      if (viewer && viewer.id !== u.id) {
        const out = this.one('SELECT status FROM friends WHERE a = ? AND b = ?', viewer.id, u.id);
        const inc = this.one('SELECT status FROM friends WHERE a = ? AND b = ?', u.id, viewer.id);
        friend = out?.status === 'ok' ? 'ok' : out ? 'sent' : inc ? 'received' : 'none';
      }
      return { user: this.pub(u, { since: u.created, presence: friend === 'ok' ? this.presence(u.id) : undefined }), stats: this.stats(u), friend, self: viewer?.id === u.id,
        h2h: viewer && viewer.id !== u.id ? this.headToHead(viewer.id, u.id) : null };
    }
    if (op === 'leaderboard') {
      const viewer = await this.sessionUser(b.token);
      const cur = SE.seasonOf();
      const season = /^\d{4}-\d{2}$/.test(String(b.season || '')) && String(b.season) <= cur ? String(b.season) : cur;
      const st = this.standings(season);
      const shape = (r) => { const u = this.user(r.uid); return this.pub(u, { pos: r.pos, pts: r.pts, games: r.games, wins: r.wins, daily: r.daily, mpPts: r.mpPts, spPts: r.spPts, dPts: r.dPts }); };
      const mine = viewer ? st.find((r) => r.uid === viewer.id) : null;
      const prev = SE.prevSeason(cur);
      const kings = [...this.kings()].map((id) => this.pub(this.user(id))).filter(Boolean);
      const seasons = this.sql('SELECT DISTINCT season FROM spoints ORDER BY season DESC LIMIT 24').map((r) => r.season);
      if (!seasons.includes(cur)) seasons.unshift(cur);
      return {
        season, current: season === cur, name: SE.seasonName(season), seasons: seasons.map((x) => ({ id: x, name: SE.seasonName(x) })),
        list: st.slice(0, 100).map(shape), me: viewer ? (mine ? shape(mine) : { ...this.pub(viewer), pos: null, pts: 0, games: 0 }) : null,
        kings, kingsSeason: SE.seasonName(prev),
      };
    }
    // albo d'oro: il podio di ogni stagione passata
    // errori dal telefono: tenuti 30 giorni, al massimo 2000
    if (op === 'clientError') {
      const viewer = await this.sessionUser(b.token).catch(() => null);
      const c = (x, n) => String(x || '').slice(0, n);
      this.run('INSERT INTO errs (ts, uid, kind, msg, stack, ua, url) VALUES (?, ?, ?, ?, ?, ?, ?)', now(), viewer?.id || null, c(b.kind, 30), c(b.msg, 400), c(b.stack, 1500), c(b.ua, 300), c(b.url, 200));
      this.run('DELETE FROM errs WHERE ts < ? OR id <= (SELECT MAX(id) - 2000 FROM errs)', now() - 30 * 864e5);
      return { ok: true };
    }
    if (op === 'palmares') {
      const cur = SE.seasonOf();
      const seasons = this.sql('SELECT DISTINCT season FROM spoints WHERE season < ? ORDER BY season DESC LIMIT 36', cur).map((r) => r.season);
      return {
        list: seasons.map((x) => ({
          id: x, name: SE.seasonName(x),
          top: this.standings(x).slice(0, 3).map((r) => this.pub(this.user(r.uid), { pos: r.pos, pts: r.pts })).filter(Boolean),
        })).filter((x) => x.top.length),
      };
    }
    if (op === 'pushKey') return { key: (await this.vapid()).pub };
    // oggetti (avatar bloccati, accessori, dorsi, emote) e posizioni degli accessori sugli avatar
    if (op === 'items') {
      const viewer = await this.sessionUser(b.token);
      const items = this.itemList();
      // oggetti esclusivi (nascosti ma regalati dall'admin a qualcuno): servono a tutti per vederli
      // addosso a chi li ha; nella scelta compaiono solo a chi li ha ricevuti
      for (const g of this.sql("SELECT DISTINCT i.* FROM unlocks u JOIN items i ON i.id = u.item WHERE u.gift = 1 AND i.hidden = 1")) {
        if (g.kind !== 'acc' || this.accOn()) items.push({ id: g.id, kind: g.kind, name: g.name, cond: g.cond, n: g.n, data: JSON.parse(g.data || '{}'), hidden: false, v: g.v, excl: true });
      }
      let mine = null;
      if (viewer) {
        const un = this.sql('SELECT item, seen FROM unlocks WHERE uid = ?', viewer.id);
        mine = { owned: items.filter((i) => this.owns(viewer, i)).map((i) => i.id), unseen: un.filter((r) => !r.seen).map((r) => r.item), progress: this.progress(viewer), ...this.look(viewer) };
      }
      return { items, mine, accOn: this.accOn(), places: this.accOn() ? this.places() : {} };
    }
    if (op === 'dailyBoard') {
      const day = SE.dayOf();
      const rows = this.sql('SELECT d.uid, d.ok, d.done FROM daily d JOIN users u ON u.id = d.uid WHERE d.day = ? AND u.banned = 0', day);
      return { day, list: rows.map((r) => this.pub(this.user(r.uid), { ok: !!r.ok, done: !!r.done })) };
    }

    // password dimenticata (senza accesso): la richiesta arriva all'amministratore, che la reimposta
    // e la manda alla persona sul contatto indicato. Massimo 3 al giorno per username.
    if (op === 'pwRequest') {
      const uname = String(b.username || '').trim().slice(0, 30), contact = String(b.contact || '').trim().slice(0, 200);
      if (!uname) fail('Scrivi il tuo username');
      if (contact.length < 3) fail('Scrivi come ti contattiamo (telefono, email o "scrivimi su WhatsApp")');
      const n = this.one('SELECT COUNT(*) AS n FROM pwreq WHERE lower(uname) = lower(?) AND ts > ?', uname, now() - 864e5).n;
      if (n >= 3) fail('Hai già mandato la richiesta: l\'amministratore ti risponderà');
      if (this.one('SELECT COUNT(*) AS n FROM pwreq WHERE ts > ?', now() - 864e5).n > 40) fail('Troppe richieste oggi, riprova domani');
      const u = this.one('SELECT id FROM users WHERE uname = ?', uname.toLowerCase()) || this.one('SELECT id FROM users WHERE lower(name) = lower(?)', uname);
      this.run('INSERT INTO pwreq (ts, uname, contact, uid) VALUES (?, ?, ?, ?)', now(), uname, contact, u?.id || null);
      for (const a of this.sql('SELECT id FROM users WHERE admin = 1')) {
        this.sendTo(a.id, { t: 'toast', msg: `🔑 Nuova richiesta di password da ${uname}` });
        await this.pushTo(a.id, 'mentions', { title: '🔑 Password dimenticata', body: `${uname}: ${contact}`.slice(0, 160), url: './admin.html#users', tag: 'pwreq' });
      }
      return { ok: true };
    }

    // con account
    const me = await this.sessionUser(b.token);
    if (!me) return { error: 'Sessione scaduta: accedi di nuovo', auth: false };
    switch (op) {
      case 'me': return { me: this.me(me), stats: this.stats(me) };
      // riepilogo di una stagione (di default quella appena finita)
      case 'wrapped': return this.wrapped(me.id, /^\d{4}-\d{2}$/.test(String(b.season || '')) ? String(b.season) : SE.prevSeason(SE.seasonOf()));
      // ---- chat privata
      case 'dmList': {
        const rows = this.sql('SELECT * FROM dms WHERE id IN (SELECT MAX(id) FROM dms WHERE a = ? OR b = ? GROUP BY a, b) ORDER BY id DESC LIMIT 100', me.id, me.id);
        const blocked = new Set(this.sql('SELECT other FROM blocks WHERE uid = ?', me.id).map((r) => r.other));
        return { list: rows.map((r) => { const other = r.a === me.id ? r.b : r.a; const u = this.user(other); if (!u) return null;
          return { user: this.pub(u, { presence: this.presence(u.id) }), last: { text: r.text, ts: r.ts, mine: r.sender === me.id }, blocked: blocked.has(other),
            unread: this.one('SELECT COUNT(*) AS n FROM dms WHERE a = ? AND b = ? AND sender = ? AND rd = 0', r.a, r.b, other).n }; }).filter(Boolean),
          admins: this.sql('SELECT id FROM users WHERE admin = 1 AND id != ?', me.id).map((r) => this.pub(this.user(r.id))) };
      }
      case 'dmGet': {
        const other = this.user(String(b.uid || ''));
        if (!other) fail('Utente non trovato');
        const [a, c] = [me.id, other.id].sort();
        const msgs = this.sql('SELECT id, sender, text, ts, rd FROM dms WHERE a = ? AND b = ? AND id < ? ORDER BY id DESC LIMIT 150', a, c, Number(b.before) || 9e15).reverse();
        this.run('UPDATE dms SET rd = 1 WHERE a = ? AND b = ? AND sender = ? AND rd = 0', a, c, other.id);
        return { user: this.pub(other, { presence: this.presence(other.id) }), msgs: msgs.map((m) => ({ id: m.id, mine: m.sender === me.id, text: m.text, ts: m.ts, rd: !!m.rd })),
          blocked: !!this.one('SELECT 1 AS x FROM blocks WHERE uid = ? AND other = ?', me.id, other.id), blockedMe: !!this.one('SELECT 1 AS x FROM blocks WHERE uid = ? AND other = ?', other.id, me.id) };
      }
      case 'dmSend': {
        const other = this.user(String(b.uid || ''));
        if (!other || other.id === me.id) fail('Utente non trovato');
        const text = String(b.text || '').replace(/\s+$/g, '').trim().slice(0, 1000);
        if (!text) fail('Messaggio vuoto');
        if (this.one('SELECT 1 AS x FROM blocks WHERE uid = ? AND other = ?', other.id, me.id)) fail('Non puoi scrivere a questa persona');
        if (this.one('SELECT 1 AS x FROM blocks WHERE uid = ? AND other = ?', me.id, other.id)) fail('Hai bloccato questa persona: sbloccala per scriverle');
        const recent = this.one('SELECT COUNT(*) AS n FROM dms WHERE sender = ? AND ts > ?', me.id, now() - 60_000).n;
        if (recent > 20) fail('Stai scrivendo troppo in fretta');
        const [a, c] = [me.id, other.id].sort();
        this.run('INSERT INTO dms (a, b, sender, text, ts) VALUES (?, ?, ?, ?, ?)', a, c, me.id, text, now());
        const id = this.one('SELECT last_insert_rowid() AS id').id;
        const msg = { id, from: this.pub(me), text, ts: now() };
        this.sendTo(other.id, { t: 'dm', msg });
        if (this.presence(other.id) === 'offline') await this.pushTo(other.id, 'mentions', { title: `💬 ${me.name}`, body: text.slice(0, 140), url: `./?dm=${me.id}`, tag: `dm-${me.id}` });
        return { msg: { id, mine: true, text, ts: msg.ts, rd: false } };
      }
      case 'dmRead': {
        const other = this.user(String(b.uid || ''));
        if (other) { const [a, c] = [me.id, other.id].sort(); this.run('UPDATE dms SET rd = 1 WHERE a = ? AND b = ? AND sender = ? AND rd = 0', a, c, other.id); }
        return { ok: true };
      }
      case 'dmBlock': {
        const other = this.user(String(b.uid || ''));
        if (!other) fail('Utente non trovato');
        if (other.admin && b.on) fail('L\'amministratore non si può bloccare');
        if (b.on) this.run('INSERT OR IGNORE INTO blocks (uid, other) VALUES (?, ?)', me.id, other.id);
        else this.run('DELETE FROM blocks WHERE uid = ? AND other = ?', me.id, other.id);
        return { ok: true };
      }
      case 'dmReport': {
        const other = this.user(String(b.uid || ''));
        if (!other) fail('Utente non trovato');
        for (const a of this.sql('SELECT id FROM users WHERE admin = 1')) this.sendTo(a.id, { t: 'toast', msg: `⚠️ ${me.name} ha segnalato ${other.name}` });
        this.run('INSERT INTO errs (ts, uid, kind, msg, stack, ua, url) VALUES (?, ?, ?, ?, ?, ?, ?)', now(), me.id, 'segnalazione', `${me.name} ha segnalato ${other.name}`, String(b.why || '').slice(0, 500), '', '');
        return { ok: true };
      }
      case 'logout': this.run('DELETE FROM sessions WHERE hash = ?', await sha(b.token)); if (b.endpoint) this.run('DELETE FROM pushsubs WHERE endpoint = ?', String(b.endpoint)); return { ok: true };
      case 'setAvatar': {
        const av = this.checkAvatar(b.avatar);
        const it = av && this.one("SELECT * FROM items WHERE id = ? AND kind = 'avatar'", av);
        if (it && !this.owns(me, it)) fail('Questo avatar è ancora bloccato');
        this.run('UPDATE users SET avatar = ? WHERE id = ?', av, me.id); return { me: this.me(this.user(me.id)) };
      }
      // accessori indossati e dorso delle carte
      case 'equip': {
        const items = Object.fromEntries(this.itemList(true).map((i) => [i.id, i]));
        if (b.acc !== undefined) {
          const acc = [...new Set([].concat(b.acc || []).map(String))].filter((id) => { const it = items[id]; return it && it.kind === 'acc' && (!it.hidden || this.gifted(me, id)) && it.cond !== 'king' && this.owns(me, it); }).slice(0, 6);
          this.run('UPDATE users SET acc = ? WHERE id = ?', JSON.stringify(acc), me.id);
        }
        if (b.back !== undefined) {
          const it = b.back ? items[String(b.back)] : null;
          if (b.back && (!it || it.kind !== 'back' || !this.owns(me, it))) fail('Questo dorso è ancora bloccato');
          this.run('UPDATE users SET back = ? WHERE id = ?', b.back ? String(b.back) : null, me.id);
        }
        return { me: this.me(this.user(me.id)) };
      }
      case 'unlockSeen': this.run('UPDATE unlocks SET seen = 1 WHERE uid = ?', me.id); return { ok: true };
      // una delle 4 reazioni vocali: { slot, id } = una di base, { slot, data, name } = registrata (max 5 s), { slot } = torna a quella di base
      case 'setRx': {
        const slot = Number(b.slot);
        if (!(slot >= 0 && slot < 4)) fail('Posto non valido');
        let mine = [];
        try { mine = JSON.parse(me.rx || '[]'); } catch {}
        while (mine.length < 4) mine.push(null);
        const old = mine[slot];
        let next = null;
        if (b.data) {
          const d = String(b.data);
          if (!/^data:audio\/(wav|x-wav|mp4|mpeg|webm|ogg|aac);base64,/.test(d) || d.length > 400_000) fail('Audio non valido o troppo lungo');
          const id = `rx-${me.id}-${randHex(4)}`;
          this.run('INSERT INTO assets (id, mime, data, v) VALUES (?, ?, ?, 1)', id, d.slice(5, d.indexOf(';')), d);
          next = { own: id, name: String(b.name || '').trim().slice(0, 24) || 'La mia' };
        } else if (b.id) {
          const it = this.one("SELECT * FROM items WHERE id = ? AND kind = 'emote' AND (hidden = 0 OR id IN (SELECT item FROM unlocks WHERE uid = ? AND gift = 1))", String(b.id), me.id);
          if (!it) fail('Reazione non trovata');
          if (!this.owns(me, it)) fail('Questa reazione è ancora bloccata');
          next = { id: it.id };
        }
        if (old?.own && old.own !== next?.own) this.run('DELETE FROM assets WHERE id = ?', old.own);
        mine[slot] = next;
        this.run('UPDATE users SET rx = ? WHERE id = ?', JSON.stringify(mine), me.id);
        return { me: this.me(this.user(me.id)) };
      }
      // sfida del giorno: un solo tentativo che conta, iniziato = usato
      case 'dailyStart': {
        const day = SE.dayOf();
        if (String(b.day) !== day) fail('Questa sfida non è più disponibile');
        // 3 tentativi al giorno, ognuno con carte diverse: il primo superato vale i punti
        const row = this.one('SELECT * FROM daily WHERE uid = ? AND day = ?', me.id, day);
        if (row && (row.ok || row.done || (row.tries || 1) >= SE.DAILY_TRIES)) {
          return { day, fresh: false, done: !!row.done, ok: !!row.ok, tries: row.tries || 1 };
        }
        if (row) this.run('UPDATE daily SET tries = tries + 1, started = ? WHERE uid = ? AND day = ?', now(), me.id, day);
        else this.run('INSERT INTO daily (uid, day, started, done, ok, tries) VALUES (?, ?, ?, 0, 0, 1)', me.id, day, now());
        const tries = row ? (row.tries || 1) + 1 : 1;
        return { day, fresh: true, attempt: tries, tries: SE.DAILY_TRIES };
      }
      case 'dailyEnd': {
        const day = String(b.day || '');
        const row = this.one('SELECT * FROM daily WHERE uid = ? AND day = ?', me.id, day);
        if (!row || row.done || row.ok) return { ok: true, counted: false };
        // vale solo se finita entro il giorno dopo (chi l'ha iniziata alle 23:55 non la perde)
        if (now() - row.started > 36 * 3600_000) return { ok: true, counted: false };
        // persa: finita solo se erano finiti i tentativi
        if (!b.ok) { if ((row.tries || 1) >= SE.DAILY_TRIES) this.run('UPDATE daily SET done = 1 WHERE uid = ? AND day = ?', me.id, day); return { ok: true, counted: true, pts: 0, left: SE.DAILY_TRIES - (row.tries || 1) }; }
        this.run('UPDATE daily SET done = 1, ok = 1 WHERE uid = ? AND day = ?', me.id, day);
        let pts = 0;
        if (b.ok) { pts = this.addPoints(me.id, `daily:${day}`, 'daily', SE.DAILY_PTS); await this.checkUnlocks(me.id); }
        return { ok: true, counted: true, pts };
      }
      case 'dailyMonth': {
        const season = SE.seasonOf();
        return { season, today: SE.dayOf(), days: SE.daysIn(season), maxTries: SE.DAILY_TRIES, list: this.sql('SELECT day, done, ok, tries FROM daily WHERE uid = ? AND day LIKE ?', me.id, season + '-%').map((r) => ({ day: r.day, done: !!r.done || (!r.ok && r.day < SE.dayOf()), ok: !!r.ok, tries: r.tries || 1 })) };
      }
      // foto dalla fotocamera o dalla galleria: arriva già ritagliata e rimpicciolita dall'app
      case 'setPhoto': {
        const d = String(b.data || '');
        if (!/^data:image\/(jpeg|webp|png);base64,/.test(d) || d.length > 200_000) fail('Foto non valida o troppo grande');
        const v = (me.photo_v || 0) + 1;
        this.run('UPDATE users SET photo = ?, photo_v = ?, avatar = ? WHERE id = ?', d, v, `ph-${me.id}-${v}`, me.id);
        return { me: this.me(this.user(me.id)) };
      }
      case 'rename': {
        if (me.name_changes >= 1) fail('Hai già cambiato username una volta: per cambiarlo ancora chiedi all\'amministratore');
        const name = cleanUsername(b.username);
        if (!USERNAME_RE.test(name)) fail(USERNAME_RULE);
        const other = this.userByName(name);
        if (other && other.id !== me.id) fail('Questo username è già preso');
        this.run('UPDATE users SET uname = ?, name = ?, name_changes = name_changes + 1 WHERE id = ?', name.toLowerCase(), name, me.id);
        return { me: this.me(this.user(me.id)) };
      }
      case 'password': {
        const old = String(b.old || '');
        if (!safeEq(await hashPassword(old, me.salt), me.hash) && !safeEq(await hashPassword(old.trim(), me.salt), me.hash)) fail('La password attuale non è giusta');
        if (String(b.password || '').trim().length < PASSWORD_MIN) fail(`La password deve avere almeno ${PASSWORD_MIN} caratteri`);
        const salt = randHex(16);
        this.run('UPDATE users SET salt = ?, hash = ? WHERE id = ?', salt, await hashPassword(String(b.password).trim(), salt), me.id);
        this.run('UPDATE users SET admin_pw = NULL WHERE id = ?', me.id); // da qui la password la sa solo l'utente
        const keep = await sha(b.token);
        this.run('DELETE FROM sessions WHERE uid = ? AND hash != ?', me.id, keep); // esce dagli altri telefoni
        return { ok: true };
      }
      case 'settings': {
        if (b.notif) this.run('UPDATE users SET notif = ? WHERE id = ?', JSON.stringify({ invites: b.notif.invites !== false, calls: !!b.notif.calls, mentions: !!b.notif.mentions }), me.id);
        if (b.quiet) this.run('UPDATE users SET quiet = ? WHERE id = ?', JSON.stringify(cleanQuiet(b.quiet)), me.id);
        if (b.tz) this.run('UPDATE users SET tz = ? WHERE id = ?', String(b.tz).slice(0, 40), me.id);
        return { me: this.me(this.user(me.id)) };
      }
      case 'pushSub': {
        const s = b.sub || {};
        if (!/^https:\/\//.test(s.endpoint || '') || !s.keys?.p256dh || !s.keys?.auth) fail('Abbonamento non valido');
        this.run('INSERT OR REPLACE INTO pushsubs (endpoint, uid, p256dh, auth, created) VALUES (?, ?, ?, ?, ?)', String(s.endpoint).slice(0, 600), me.id, String(s.keys.p256dh).slice(0, 200), String(s.keys.auth).slice(0, 60), now());
        return { me: this.me(this.user(me.id)) };
      }
      case 'pushUnsub': this.run('DELETE FROM pushsubs WHERE endpoint = ? AND uid = ?', String(b.endpoint || ''), me.id); return { me: this.me(this.user(me.id)) };
      case 'pushTest': await this.pushTo(me.id, 'mentions', { title: 'Bisca', body: 'Le notifiche funzionano.', url: './', tag: 'test' }); return { ok: true };
      case 'spResult': {
        const gkey = `sp:${me.id}:${String(b.id || '').slice(0, 40)}`;
        if (!b.id || this.one('SELECT gkey FROM games WHERE gkey = ?', gkey)) return { ok: true, dup: true };
        this.run('INSERT INTO games (gkey, mode, created, rated, rounds, data) VALUES (?, ?, ?, 0, ?, ?)', gkey, 'sp', now(), Number(b.rounds) || 0, JSON.stringify({ players: Number(b.players) || 0, level: String(b.level || '').slice(0, 10) }));
        const num = (v) => (Number.isFinite(Number(v)) ? Math.max(0, Math.min(500, Math.round(Number(v)))) : null);
        const n = num(b.players) || 0;
        this.run('INSERT INTO gplayers (gkey, uid, place, won, delta, n, calls, exact, bcall, bzero, surv, ts) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)', gkey, me.id, num(b.place) || (b.won ? 1 : 2), b.won ? 1 : 0,
          n, num(b.calls), Math.min(num(b.exact) ?? 0, num(b.calls) ?? 0), num(b.bcall), Math.min(num(b.bzero) ?? 0, 1), num(b.surv), now());
        this.run('UPDATE users SET sp_games = sp_games + 1, sp_wins = sp_wins + ? WHERE id = ?', b.won ? 1 : 0, me.id);
        // in classifica: facile no, medio ×0,25, difficile ×0,5, al massimo 3 partite al giorno
        const lvl = String(b.level || ''), mult = SE.SP_MULT[lvl] || 0;
        let pts = null;
        const today = SE.dayOf();
        const counted = this.one("SELECT COUNT(*) AS n FROM spoints WHERE uid = ? AND kind = 'sp' AND day = ?", me.id, today).n;
        if (mult > 0 && n >= 2 && counted < SE.SP_PER_DAY) {
          const place = Math.max(1, Math.min(n, num(b.place) || (b.won ? 1 : n)));
          const places = Array.from({ length: n }, (_, i) => i + 1); places[place - 1] = place;
          pts = this.addPoints(me.id, gkey, 'sp', Math.round(SE.gamePoints(place, places) * mult * 4) / 4);
        }
        await this.checkUnlocks(me.id);
        return { ok: true, pts, counted: pts != null, left: Math.max(0, SE.SP_PER_DAY - counted - (pts != null ? 1 : 0)) };
      }

      // ---- amici
      case 'search': {
        const q = cleanUsername(b.q).toLowerCase().replace(/[%\\]/g, '').slice(0, 20);
        if (q.length < 2) return { list: [] };
        return { list: this.sql("SELECT * FROM users WHERE uname LIKE ? AND banned = 0 AND id != ? ORDER BY uname = ? DESC, length(uname) LIMIT 20", `%${q}%`, me.id, q).map((u) => this.pub(u)) };
      }
      case 'friends': {
        const ok = this.sql("SELECT u.* FROM friends f JOIN users u ON u.id = f.b WHERE f.a = ? AND f.status = 'ok'", me.id).map((u) => this.pub(u, {
          presence: this.presence(u.id),
          push: this.notifCfg(u).invites && !!this.one('SELECT 1 AS x FROM pushsubs WHERE uid = ? LIMIT 1', u.id),
        }));
        const rank = { game: 0, online: 1, offline: 2 };
        ok.sort((a, b2) => rank[a.presence] - rank[b2.presence] || a.username.localeCompare(b2.username));
        return {
          friends: ok,
          incoming: this.sql("SELECT u.* FROM friends f JOIN users u ON u.id = f.a WHERE f.b = ? AND f.status = 'pending'", me.id).map((u) => this.pub(u)),
          outgoing: this.sql("SELECT u.* FROM friends f JOIN users u ON u.id = f.b WHERE f.a = ? AND f.status = 'pending'", me.id).map((u) => this.pub(u)),
        };
      }
      case 'friendAdd': {
        const t = this.user(b.uid);
        if (!t || t.id === me.id || t.banned) fail('Utente non trovato');
        const inc = this.one('SELECT status FROM friends WHERE a = ? AND b = ?', t.id, me.id);
        if (inc) return this.rpc({ ...b, op: 'friendAnswer', ok: true });
        if (this.one('SELECT status FROM friends WHERE a = ? AND b = ?', me.id, t.id)) return { ok: true };
        this.run("INSERT INTO friends (a, b, status, created) VALUES (?, ?, 'pending', ?)", me.id, t.id, now());
        await this.notify(t.id, 'friend_req', { from: this.pub(me) }); // niente push per le amicizie
        return { ok: true };
      }
      case 'friendAnswer': {
        const t = this.user(b.uid);
        const req = t && this.one("SELECT * FROM friends WHERE a = ? AND b = ? AND status = 'pending'", t.id, me.id);
        if (!req) fail('Richiesta non trovata');
        if (b.ok) {
          this.run("UPDATE friends SET status = 'ok' WHERE a = ? AND b = ?", t.id, me.id);
          this.run("INSERT OR REPLACE INTO friends (a, b, status, created) VALUES (?, ?, 'ok', ?)", me.id, t.id, now());
          await this.notify(t.id, 'friend_ok', { from: this.pub(me) });
          this.sendTo(t.id, { t: 'presence', uid: me.id, state: this.presence(me.id) });
          this.sendTo(me.id, { t: 'presence', uid: t.id, state: this.presence(t.id) });
        } else this.run('DELETE FROM friends WHERE a = ? AND b = ?', t.id, me.id);
        this.run("UPDATE notifs SET read = 1 WHERE uid = ? AND type = 'friend_req' AND json_extract(data, '$.from.id') = ?", me.id, t.id);
        return { ok: true };
      }
      case 'friendRemove':
        this.run('DELETE FROM friends WHERE (a = ? AND b = ?) OR (a = ? AND b = ?)', me.id, String(b.uid), String(b.uid), me.id);
        return { ok: true };

      // ---- notifiche in app
      case 'notifs': {
        const list = this.sql('SELECT * FROM notifs WHERE uid = ? AND read = 0 AND (expires IS NULL OR expires > ?) ORDER BY id DESC LIMIT 200', me.id, now()).map((n) => ({ ...n, data: JSON.parse(n.data) }));
        return { list, unread: list.length };
      }
      case 'notifReadWhere': {
        const types = [].concat(b.types || []).map(String).slice(0, 8);
        for (const ty of types) {
          if (b.cid) this.run("UPDATE notifs SET read = 1 WHERE uid = ? AND type = ? AND json_extract(data, '$.cid') = ?", me.id, ty, String(b.cid).toUpperCase());
          else this.run('UPDATE notifs SET read = 1 WHERE uid = ? AND type = ?', me.id, ty);
        }
        return { ok: true };
      }
      case 'notifRead':
        if (b.all) this.run('UPDATE notifs SET read = 1 WHERE uid = ?', me.id);
        else for (const id of [].concat(b.ids || [])) this.run('UPDATE notifs SET read = 1 WHERE uid = ? AND id = ?', me.id, Number(id));
        this.run('DELETE FROM notifs WHERE uid = ? AND id NOT IN (SELECT id FROM notifs WHERE uid = ? ORDER BY id DESC LIMIT 200)', me.id, me.id);
        return { ok: true };

      // ---- inviti in partita (solo in app, niente push)
      case 'invite': {
        const code = String(b.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        const info = await this.roomInfo(code);
        if (!info) fail('La stanza non esiste più');
        if (info.phase !== 'lobby') fail('La partita è già iniziata');
        if (!info.canJoinAsPlayer) fail('La stanza è piena');
        const sent = [], skipped = [];
        for (const uid of [].concat(b.uids || []).slice(0, 12)) {
          const t = this.user(uid);
          if (!t || !this.one("SELECT 1 AS x FROM friends WHERE a = ? AND b = ? AND status = 'ok'", me.id, uid)) continue;
          this.run("UPDATE notifs SET read = 1 WHERE uid = ? AND type = 'invite' AND json_extract(data, '$.code') = ?", uid, code);
          // in app arriva sempre (anche se sta giocando un'altra partita); sul telefono se ha attivato le notifiche
          await this.notify(uid, 'invite', { code, from: this.pub(me) }, {
            expires: now() + INVITE_TTL, push: 'invites', title: `${me.name} ti invita a giocare`, body: 'Tocca per entrare nella sua stanza di Bisca.', url: `./?join=${code}`, tag: `invite-${code}`,
          });
          sent.push(t.name);
        }
        return { sent, skipped };
      }
      case 'inviteAnswer': {
        const n = this.one("SELECT * FROM notifs WHERE id = ? AND uid = ? AND type = 'invite'", Number(b.id), me.id);
        if (!n) fail('Invito non trovato');
        this.run('UPDATE notifs SET read = 1 WHERE id = ?', n.id);
        const d = JSON.parse(n.data);
        if (n.expires && n.expires < now()) fail('L\'invito è scaduto');
        if (!b.ok) { this.sendTo(d.from.id, { t: 'toast', msg: `${me.name} ha rifiutato l'invito` }); return { ok: true }; }
        const info = await this.roomInfo(d.code);
        if (!info) fail('La stanza non esiste più');
        if (info.phase !== 'lobby') fail('La partita è già iniziata');
        if (!info.canJoinAsPlayer) fail('La stanza è piena');
        return { code: d.code };
      }

      // ---- community
      case 'cMine': return { list: this.sql('SELECT c.*, m.role FROM cmembers m JOIN comms c ON c.id = m.cid WHERE m.uid = ? ORDER BY c.name', me.id).map((c) => this.commPub(c, { role: c.role })) };
      case 'cSearch': {
        const q = String(b.q || '').trim().toLowerCase().slice(0, 30);
        const rows = q ? this.sql('SELECT * FROM comms WHERE lname LIKE ? OR id = ? ORDER BY public DESC, lname LIMIT 30', `%${q}%`, q.toUpperCase()) : this.sql('SELECT * FROM comms WHERE public = 1 ORDER BY created DESC LIMIT 30');
        return { list: rows.map((c) => this.commPub(c, { role: this.role(c.id, me.id), requested: !!this.one("SELECT 1 AS x FROM creqs WHERE cid = ? AND uid = ? AND kind = 'req'", c.id, me.id) })) };
      }
      case 'cCreate': {
        const name = String(b.name || '').replace(/\s+/g, ' ').trim();
        if (name.length < 3 || name.length > 30) fail('Il nome deve avere da 3 a 30 caratteri');
        if (this.one('SELECT id FROM comms WHERE lname = ?', name.toLowerCase())) fail('Esiste già una community con questo nome');
        let id; do { id = randCode(6); } while (this.comm(id));
        this.run('INSERT INTO comms (id, name, lname, descr, public, owner, created) VALUES (?, ?, ?, ?, ?, ?, ?)', id, name, name.toLowerCase(), String(b.descr || '').slice(0, 300), b.public ? 1 : 0, me.id, now());
        try { await this.env.COMM.get(this.env.COMM.idFromName(id)).fetch('https://c/init', { method: 'POST', body: JSON.stringify({ cid: id, name }) }); } catch {}
        await this.addMember(id, me.id, 'owner');
        return { id };
      }
      case 'cGet': {
        const c = this.comm(b.cid);
        if (!c) fail('Community non trovata');
        const role = this.role(c.id, me.id);
        const out = { c: this.commPub(c, { role }), requested: !!this.one("SELECT 1 AS x FROM creqs WHERE cid = ? AND uid = ? AND kind = 'req'", c.id, me.id), invited: !!this.one("SELECT 1 AS x FROM creqs WHERE cid = ? AND uid = ? AND kind = 'inv'", c.id, me.id) };
        if (!role) return out;
        out.members = this.sql('SELECT u.*, m.role AS crole FROM cmembers m JOIN users u ON u.id = m.uid WHERE m.cid = ? ORDER BY CASE m.role WHEN \'owner\' THEN 0 WHEN \'admin\' THEN 1 ELSE 2 END, u.uname', c.id)
          .map((u) => this.pub(u, { role: u.crole, presence: this.presence(u.id) }));
        out.call = await this.callState(c.id);
        const cool = this.one('SELECT ts FROM callcool WHERE cid = ? AND uid = ?', c.id, me.id)?.ts || 0;
        out.callWait = Math.max(0, cool + CALL_COOLDOWN - now());
        if (role === 'owner' || role === 'admin') out.requests = this.sql("SELECT u.* FROM creqs r JOIN users u ON u.id = r.uid WHERE r.cid = ? AND r.kind = 'req'", c.id).map((u) => this.pub(u));
        return out;
      }
      case 'cJoin': {
        const c = this.comm(b.cid);
        if (!c) fail('Community non trovata');
        if (this.role(c.id, me.id)) return { joined: true };
        const inv = this.one("SELECT 1 AS x FROM creqs WHERE cid = ? AND uid = ? AND kind = 'inv'", c.id, me.id);
        if (c.public || inv) {
          await this.addMember(c.id, me.id);
          this.run("UPDATE notifs SET read = 1 WHERE uid = ? AND type = 'cinvite' AND json_extract(data, '$.cid') = ?", me.id, c.id);
          return { joined: true };
        }
        if (!this.one("SELECT 1 AS x FROM creqs WHERE cid = ? AND uid = ? AND kind = 'req'", c.id, me.id)) {
          this.run("INSERT INTO creqs (cid, uid, kind, by, created) VALUES (?, ?, 'req', ?, ?)", c.id, me.id, me.id, now());
          for (const a of this.sql("SELECT uid FROM cmembers WHERE cid = ? AND role IN ('owner', 'admin')", c.id)) await this.notify(a.uid, 'creq', { cid: c.id, cname: c.name, from: this.pub(me) });
        }
        return { requested: true };
      }
      case 'cAnswer': {
        const c = this.comm(b.cid);
        if (!c || !this.isAdmin(c.id, me.id)) fail('Non puoi farlo');
        const req = this.one("SELECT * FROM creqs WHERE cid = ? AND uid = ? AND kind = 'req'", c.id, String(b.uid));
        if (!req) fail('Richiesta non trovata');
        if (b.ok) { await this.addMember(c.id, req.uid); await this.notify(req.uid, 'cjoin', { cid: c.id, cname: c.name }); }
        else this.run("DELETE FROM creqs WHERE cid = ? AND uid = ? AND kind = 'req'", c.id, req.uid);
        this.run("UPDATE notifs SET read = 1 WHERE type = 'creq' AND json_extract(data, '$.cid') = ? AND json_extract(data, '$.from.id') = ?", c.id, req.uid);
        return { ok: true };
      }
      case 'cInvite': {
        const c = this.comm(b.cid);
        if (!c || !this.isAdmin(c.id, me.id)) fail('Solo proprietario e amministratori invitano');
        const t = this.user(b.uid);
        if (!t || this.role(c.id, t.id)) fail('Utente non trovato o già dentro');
        this.run("INSERT OR REPLACE INTO creqs (cid, uid, kind, by, created) VALUES (?, ?, 'inv', ?, ?)", c.id, t.id, me.id, now());
        await this.notify(t.id, 'cinvite', { cid: c.id, cname: c.name, from: this.pub(me) });
        return { ok: true };
      }
      case 'cDecline':
        this.run("DELETE FROM creqs WHERE cid = ? AND uid = ? AND kind = 'inv'", String(b.cid), me.id);
        this.run("UPDATE notifs SET read = 1 WHERE uid = ? AND type = 'cinvite' AND json_extract(data, '$.cid') = ?", me.id, String(b.cid));
        return { ok: true };
      case 'cLeave': {
        const c = this.comm(b.cid);
        const r = c && this.role(c.id, me.id);
        if (!r) return { ok: true };
        if (r === 'owner') {
          const next = this.one("SELECT uid FROM cmembers WHERE cid = ? AND uid != ? ORDER BY CASE role WHEN 'admin' THEN 0 ELSE 1 END, joined LIMIT 1", c.id, me.id);
          if (!next) fail('Sei l\'unico membro: se vuoi chiuderla usa "Elimina community"');
          this.run("UPDATE cmembers SET role = 'owner' WHERE cid = ? AND uid = ?", c.id, next.uid);
          this.run('UPDATE comms SET owner = ? WHERE id = ?', next.uid, c.id);
          await this.syncMember(c.id, next.uid, 'owner');
          await this.notify(next.uid, 'cowner', { cid: c.id, cname: c.name });
        }
        this.run('DELETE FROM cmembers WHERE cid = ? AND uid = ?', c.id, me.id);
        await this.syncMember(c.id, me.id, null);
        return { ok: true };
      }
      case 'cRole': {
        const c = this.comm(b.cid);
        if (!c || this.role(c.id, me.id) !== 'owner') fail('Solo il proprietario cambia i ruoli');
        const t = String(b.uid);
        if (!this.role(c.id, t) || t === me.id) fail('Membro non trovato');
        if (b.role === 'owner') {
          this.run("UPDATE cmembers SET role = 'admin' WHERE cid = ? AND uid = ?", c.id, me.id);
          this.run("UPDATE cmembers SET role = 'owner' WHERE cid = ? AND uid = ?", c.id, t);
          this.run('UPDATE comms SET owner = ? WHERE id = ?', t, c.id);
          await this.syncMember(c.id, me.id, 'admin'); await this.syncMember(c.id, t, 'owner');
          await this.notify(t, 'cowner', { cid: c.id, cname: c.name });
        } else {
          const role = b.role === 'admin' ? 'admin' : 'member';
          this.run('UPDATE cmembers SET role = ? WHERE cid = ? AND uid = ?', role, c.id, t);
          await this.syncMember(c.id, t, role);
        }
        return { ok: true };
      }
      case 'cKick': {
        const c = this.comm(b.cid);
        const mine = c && this.role(c.id, me.id);
        const t = String(b.uid);
        const theirs = c && this.role(c.id, t);
        if (!theirs || t === me.id) fail('Membro non trovato');
        if (!(mine === 'owner' || (mine === 'admin' && theirs === 'member'))) fail('Non puoi togliere questo membro');
        this.run('DELETE FROM cmembers WHERE cid = ? AND uid = ?', c.id, t);
        await this.syncMember(c.id, t, null);
        return { ok: true };
      }
      case 'cEdit': {
        const c = this.comm(b.cid);
        const r = c && this.role(c.id, me.id);
        if (r !== 'owner' && r !== 'admin') fail('Non puoi modificarla');
        if (b.name != null && b.name !== c.name) {
          if (r !== 'owner') fail('Solo il proprietario cambia il nome');
          const name = String(b.name).replace(/\s+/g, ' ').trim();
          if (name.length < 3 || name.length > 30) fail('Il nome deve avere da 3 a 30 caratteri');
          const o = this.one('SELECT id FROM comms WHERE lname = ?', name.toLowerCase());
          if (o && o.id !== c.id) fail('Esiste già una community con questo nome');
          this.run('UPDATE comms SET name = ?, lname = ? WHERE id = ?', name, name.toLowerCase(), c.id);
        }
        if (b.descr != null) this.run('UPDATE comms SET descr = ? WHERE id = ?', String(b.descr).slice(0, 300), c.id);
        if (b.public != null) this.run('UPDATE comms SET public = ? WHERE id = ?', b.public ? 1 : 0, c.id);
        return { ok: true };
      }
      case 'cLogo': {
        const c = this.comm(b.cid);
        if (!c || !this.isAdmin(c.id, me.id)) fail('Il logo lo cambiano proprietario e amministratori');
        if (!b.data) { this.run('UPDATE comms SET logo = NULL, logo_v = NULL WHERE id = ?', c.id); return { ok: true }; }
        const d = String(b.data);
        if (!/^data:image\/(jpeg|webp|png);base64,/.test(d) || d.length > 200_000) fail('Immagine non valida o troppo grande');
        this.run('UPDATE comms SET logo = ?, logo_v = ? WHERE id = ?', d, (c.logo_v || 0) + 1, c.id);
        return { ok: true };
      }
      case 'cDelete': {
        const c = this.comm(b.cid);
        if (!c || this.role(c.id, me.id) !== 'owner') fail('Solo il proprietario può eliminarla');
        for (const t of ['cmembers', 'creqs', 'calls', 'callcool']) this.run(`DELETE FROM ${t} WHERE cid = ?`, c.id);
        this.run('DELETE FROM comms WHERE id = ?', c.id);
        try { await this.env.COMM.get(this.env.COMM.idFromName(c.id)).fetch('https://c/wipe', { method: 'POST', body: '{}' }); } catch {}
        return { ok: true };
      }
      // partita avviata dalla community: diventa un messaggio in chat con "Partecipa"
      case 'cLobby': {
        const c = this.comm(b.cid);
        if (!c || !this.role(c.id, me.id)) fail('Non sei in questa community');
        const open = await this.callState(c.id);
        if (open && open.by?.id !== me.id) fail('C\'è già una partita aperta: entra in quella dalla chat');
        const code = String(b.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        const info = await this.roomInfo(code);
        if (!info || info.phase !== 'lobby' || !info.players.includes(me.name)) fail('Prima crea la stanza');
        this.run('INSERT OR REPLACE INTO calls (cid, code, by, created, notified) VALUES (?, ?, ?, ?, 0)', c.id, code, me.id, now());
        try { await this.env.COMM.get(this.env.COMM.idFromName(c.id)).fetch('https://c/post', { method: 'POST', body: JSON.stringify({ uid: me.id, uname: me.name, avatar: me.avatar, kind: 'lobby', code, text: `${me.name} ha avviato una partita` }) }); } catch {}
        return { ok: true };
      }
      // chi ha avviato la partita può avvisare tutta la community (una volta per partita, ogni 30 minuti al massimo)
      case 'cNotify': {
        const c = this.comm(b.cid);
        if (!c || !this.role(c.id, me.id)) fail('Non sei in questa community');
        const row = this.one('SELECT * FROM calls WHERE cid = ?', c.id);
        const open = await this.callState(c.id);
        if (!open || !row || row.by !== me.id) fail('La partita non è più in attesa di giocatori');
        if (row.notified) fail('Hai già avvisato la community per questa partita');
        const cool = this.one('SELECT ts FROM callcool WHERE cid = ? AND uid = ?', c.id, me.id)?.ts || 0;
        if (now() - cool < CALL_COOLDOWN) fail(`Puoi avvisare di nuovo tra ${Math.ceil((cool + CALL_COOLDOWN - now()) / 60000)} minuti`);
        this.run('UPDATE calls SET notified = 1 WHERE cid = ?', c.id);
        this.run('INSERT OR REPLACE INTO callcool (cid, uid, ts) VALUES (?, ?, ?)', c.id, me.id, now());
        const others = this.sql('SELECT uid FROM cmembers WHERE cid = ? AND uid != ?', c.id, me.id);
        await Promise.allSettled(others.map((m) => this.notify(m.uid, 'call', { cid: c.id, cname: c.name, code: row.code, from: this.pub(me) }, {
          push: 'calls', title: `${c.name}: si gioca!`, body: `${me.name} ha avviato una partita nella tua community: entra a giocare anche tu.`, url: `./?join=${row.code}`, tag: `call-${c.id}-${row.code}`,
        })));
        return { ok: true, sent: others.length };
      }
    }
    fail('Operazione sconosciuta');
  }

  commPub(c, extra = {}) {
    return { id: c.id, name: c.name, descr: c.descr || '', public: !!c.public, logo: c.logo_v || null, owner: c.owner, members: this.one('SELECT COUNT(*) AS n FROM cmembers WHERE cid = ?', c.id).n, ...extra };
  }

  // ------------------------------------------------------------ menzioni (dalla chat della community)
  async mention(b) {
    const c = this.comm(b.cid);
    if (!c) return { ok: false };
    const from = this.user(b.from);
    let sent = 0;
    for (const uid of [...new Set([].concat(b.to || []))].slice(0, 5)) {
      if (uid === b.from || !this.role(c.id, uid)) continue;
      const key = `${b.from}>${uid}`;
      const last = this.mentionGap.get(key) || 0;
      const push = now() - last >= MENTION_GAP;
      if (push) this.mentionGap.set(key, now());
      await this.notify(uid, 'mention', { cid: c.id, cname: c.name, mid: b.mid, from: this.pub(from), text: String(b.text || '').slice(0, 140) }, push ? {
        push: 'mentions', title: `${from?.name || 'Qualcuno'} ti ha menzionato in ${c.name}`, body: String(b.text || '').slice(0, 140), url: `./?c=${c.id}&m=${b.mid}`, tag: `mention-${c.id}-${b.mid}`,
      } : {});
      sent++;
    }
    return { ok: true, sent };
  }

  // ------------------------------------------------------------ risultati multiplayer (dalla stanza)
  async mpResult(b) {
    const gkey = String(b.gkey || '');
    if (!gkey || this.one('SELECT gkey FROM games WHERE gkey = ?', gkey)) return { ok: true, dup: true };
    const rows = (b.players || []).filter((p) => p.uid && this.user(p.uid));
    const uniq = [...new Map(rows.map((p) => [p.uid, p])).values()];
    const grp = uniq.map((p) => p.uid).sort().join(',');
    const rated = uniq.length >= SE.MIN_HUMANS && (b.rounds || 0) >= SE.MIN_ROUNDS;
    this.run('INSERT INTO games (gkey, mode, created, rated, grp, rounds, data) VALUES (?, ?, ?, ?, ?, ?, ?)', gkey, 'mp', now(), rated ? 1 : 0, grp, b.rounds || 0,
      JSON.stringify({ code: b.code, players: (b.players || []).map((p) => ({ name: p.name, uid: p.uid || null, cpu: !!p.cpu, place: p.place, won: !!p.won, away: !!p.away })) }));
    for (const p of uniq) {
      this.run('INSERT INTO gplayers (gkey, uid, place, won, delta, n, calls, exact, bcall, bzero, surv, ts) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)', gkey, p.uid, p.place, p.won ? 1 : 0,
        (b.players || []).length, p.calls ?? null, p.exact ?? null, p.bcall ?? null, p.bzero ?? null, p.rounds ?? null, now());
      this.run('UPDATE users SET mp_games = mp_games + 1, mp_wins = mp_wins + ? WHERE id = ?', p.won ? 1 : 0, p.uid);
    }
    let pts = {}, deltas = {};
    if (rated) ({ pts, deltas } = this.mpScore(gkey, now()));
    for (const p of uniq) await this.checkUnlocks(p.uid);
    return { ok: true, rated, deltas, pts };
  }

  // ------------------------------------------------------------ amministratore
  async admin(b) {
    switch (b.op) {
      case 'claimAdmin': { const u = await this.sessionUser(b.token); if (!u) fail('Accedi prima con il tuo account'); this.run('UPDATE users SET admin = 1 WHERE id = ?', u.id); return { ok: true, username: u.name }; }
      case 'setAdmin': this.run('UPDATE users SET admin = ? WHERE id = ?', b.on ? 1 : 0, String(b.uid)); return { ok: true };
      case 'users': return { list: this.sql('SELECT * FROM users ORDER BY uname').map((u) => ({ ...this.pub(u), created: u.created, seen: u.seen, banned: !!u.banned, nameChanges: u.name_changes, admin: !!u.admin, adminPw: u.admin_pw || null, mp: [u.mp_games, u.mp_wins], sp: [u.sp_games, u.sp_wins], online: this.presence(u.id) !== 'offline', linked: this.linked(u.id).map((x) => ({ id: x, username: this.user(x).name })) })), pwOpen: this.one('SELECT COUNT(*) AS n FROM pwreq WHERE done = 0').n };
      case 'games': return { list: this.sql('SELECT * FROM games WHERE mode = ? ORDER BY created DESC LIMIT 200', b.mode === 'sp' ? 'sp' : 'mp').map((g) => ({ gkey: g.gkey, created: g.created, rated: !!g.rated, rounds: g.rounds, data: JSON.parse(g.data || '{}'), players: this.sql('SELECT g.*, u.name FROM gplayers g LEFT JOIN users u ON u.id = g.uid WHERE g.gkey = ? ORDER BY place', g.gkey) })) };
      case 'setPassword': {
        const u = this.user(b.uid);
        if (!u) fail('Utente non trovato');
        if (String(b.password || '').trim().length < PASSWORD_MIN) fail(`Almeno ${PASSWORD_MIN} caratteri`);
        const salt = randHex(16);
        this.run('UPDATE users SET salt = ?, hash = ?, admin_pw = ? WHERE id = ?', salt, await hashPassword(String(b.password).trim(), salt), String(b.password).trim(), u.id);
        this.run('DELETE FROM sessions WHERE uid = ?', u.id);
        return { ok: true };
      }
      case 'rename': {
        const u = this.user(b.uid);
        const name = cleanUsername(b.username);
        if (!u) fail('Utente non trovato');
        if (!USERNAME_RE.test(name)) fail('Username non valido');
        const o = this.userByName(name);
        if (o && o.id !== u.id) fail('Username già preso');
        this.run('UPDATE users SET uname = ?, name = ? WHERE id = ?', name.toLowerCase(), name, u.id);
        return { ok: true };
      }
      case 'ban': {
        this.run('UPDATE users SET banned = ? WHERE id = ?', b.on ? 1 : 0, String(b.uid));
        if (b.on) { this.run('DELETE FROM sessions WHERE uid = ?', String(b.uid)); for (const w of this.socks(String(b.uid))) { try { w.close(4001, 'Bloccato'); } catch {} } }
        return { ok: true };
      }
      // ---- oggetti da sbloccare
      case 'items': {
        const counts = Object.fromEntries(this.sql('SELECT item, COUNT(*) AS n, SUM(gift) AS g FROM unlocks GROUP BY item').map((r) => [r.item, { n: r.n, g: r.g || 0 }]));
        return { items: this.itemList(true), places: this.places(), accOn: this.accOn(), counts, users: this.one('SELECT COUNT(*) AS n FROM users WHERE banned = 0').n };
      }
      // Cancella le partite di un account in un giorno (ora italiana): spariscono dalle sue statistiche,
      // dai suoi punti della stagione e dal suo livello. Gli altri giocatori non cambiano.
      case 'delGames': {
        const u = this.user(String(b.uid || ''));
        if (!u) fail('Account non trovato');
        const day = String(b.day || '');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) fail('Data non valida');
        const modes = b.mode === 'mp' ? ['mp'] : b.mode === 'sp' ? ['sp'] : ['mp', 'sp'];
        const rows = this.sql('SELECT gp.*, g.mode, g.created, g.rated FROM gplayers gp JOIN games g ON g.gkey = gp.gkey WHERE gp.uid = ?', u.id)
          .filter((r) => modes.includes(r.mode) && SE.dayOf(r.ts || r.created) === day);
        if (b.dry) return { count: rows.length, mp: rows.filter((r) => r.mode === 'mp').length, sp: rows.filter((r) => r.mode === 'sp').length };
        for (const r of rows) {
          this.run('DELETE FROM gplayers WHERE gkey = ? AND uid = ?', r.gkey, u.id);
          this.run('DELETE FROM spoints WHERE gkey = ? AND uid = ?', r.gkey, u.id);
          if (r.mode === 'mp') this.run('UPDATE users SET mp_games = MAX(0, mp_games - 1), mp_wins = MAX(0, mp_wins - ?) WHERE id = ?', r.won ? 1 : 0, u.id);
          else this.run('UPDATE users SET sp_games = MAX(0, sp_games - 1), sp_wins = MAX(0, sp_wins - ?) WHERE id = ?', r.won ? 1 : 0, u.id);
          if (r.rated && r.delta) {
            this.run('UPDATE users SET rating = rating - ?, rated = MAX(0, rated - 1) WHERE id = ?', r.delta, u.id);
            this.run('DELETE FROM rhist WHERE uid = ? AND gkey = ?', u.id, r.gkey);
          }
          if (!this.one('SELECT 1 AS x FROM gplayers WHERE gkey = ?', r.gkey)) this.run('DELETE FROM games WHERE gkey = ?', r.gkey);
        }
        return { ok: true, removed: rows.length };
      }
      // errori dai telefoni, raggruppati per messaggio
      case 'errors': {
        const rows = this.sql('SELECT e.*, u.name AS uname FROM errs e LEFT JOIN users u ON u.id = e.uid ORDER BY e.id DESC LIMIT 600');
        const groups = new Map();
        for (const r of rows) {
          const k = r.kind + '|' + r.msg;
          const g = groups.get(k) || { kind: r.kind, msg: r.msg, n: 0, last: r.ts, users: new Set(), devices: new Set(), stack: r.stack, url: r.url };
          g.n++; if (r.uname) g.users.add(r.uname); g.devices.add(deviceOf(r.ua)); groups.set(k, g);
        }
        return { list: [...groups.values()].map((g) => ({ ...g, users: [...g.users], devices: [...g.devices] })) };
      }
      case 'errorsClear': this.run('DELETE FROM errs'); return { ok: true };
      case 'metrics': return this.metrics();
      case 'merge': return await this.merge(String(b.keep || ''), String(b.drop || ''));
      case 'linked': return { list: this.linked(String(b.uid || '')).map((x) => this.pub(this.user(x))) };
      case 'deleteUser': {
        const u = this.user(String(b.uid || ''));
        if (!u) fail('Account non trovato');
        if (u.admin) fail('Non si può eliminare un amministratore');
        for (const t of ['sessions', 'pushsubs', 'notifs', 'unlocks', 'daily', 'act', 'devs', 'spoints', 'rhist']) this.run(`DELETE FROM ${t} WHERE uid = ?`, u.id);
        this.run('DELETE FROM friends WHERE a = ? OR b = ?', u.id, u.id);
        this.run('DELETE FROM cmembers WHERE uid = ?', u.id);
        this.run('DELETE FROM dms WHERE a = ? OR b = ?', u.id, u.id);
        this.run('DELETE FROM blocks WHERE uid = ? OR other = ?', u.id, u.id);
        this.run('UPDATE gplayers SET uid = NULL WHERE uid = ?', u.id);
        for (const w of this.socks(u.id)) { try { w.close(4001, 'account eliminato'); } catch {} }
        this.run('DELETE FROM users WHERE id = ?', u.id);
        this.recomputeRatings();
        return { ok: true };
      }
      case 'pwRequests': return { list: this.sql('SELECT * FROM pwreq ORDER BY done, id DESC LIMIT 100').map((r) => ({ ...r, user: r.uid ? this.pub(this.user(r.uid)) : null })) };
      case 'pwDone': this.run('UPDATE pwreq SET done = 1 WHERE id = ?', Number(b.id)); return { ok: true };
      // regali: oggetti di un account (sbloccati, regalati, mancanti) e regalo/ritiro
      case 'userItems': {
        const u = this.user(String(b.uid || ''));
        if (!u) fail('Account non trovato');
        const un = Object.fromEntries(this.sql('SELECT item, gift FROM unlocks WHERE uid = ?', u.id).map((r) => [r.item, r.gift]));
        return { list: this.itemList(true).filter((i) => i.cond !== 'king').map((i) => ({ ...i, owned: this.owns(u, i), gift: un[i.id] === 1 })), progress: this.progress(u) };
      }
      case 'gift': {
        const u = this.user(String(b.uid || ''));
        const it = this.one('SELECT * FROM items WHERE id = ?', String(b.item || ''));
        if (!u || !it) fail('Account o oggetto non trovato');
        if (it.cond === 'king') fail('La corona va solo al Re della Bisca');
        if (b.on) {
          this.run('INSERT INTO unlocks (uid, item, ts, seen, gift) VALUES (?, ?, ?, 0, 1) ON CONFLICT (uid, item) DO UPDATE SET gift = 1, seen = 0', u.id, it.id, now());
          this.sendTo(u.id, { t: 'unlocked', items: [it.id] });
        } else {
          this.run('DELETE FROM unlocks WHERE uid = ? AND item = ? AND gift = 1', u.id, it.id);
          // se lo stava usando, lo toglie
          if (u.back === it.id) this.run('UPDATE users SET back = NULL WHERE id = ?', u.id);
          if (it.kind === 'acc') { let acc = []; try { acc = JSON.parse(u.acc || '[]'); } catch {} this.run('UPDATE users SET acc = ? WHERE id = ?', JSON.stringify(acc.filter((x) => x !== it.id)), u.id); }
          await this.checkUnlocks(u.id);
        }
        return { ok: true };
      }
      // tavola degli accessori: posizione di un accessorio su un avatar (value null = cancella, off = non va)
      case 'place': {
        const av = String(b.av || '').slice(0, 80), acc = String(b.acc || '').slice(0, 60);
        if (!av || !acc) fail('Manca avatar o accessorio');
        if (b.off) this.run('INSERT OR REPLACE INTO places (av, acc, x, y, s, r, off) VALUES (?, ?, 0, 0, 0, 0, 1)', av, acc);
        else if (b.value) {
          const v = b.value, n = (x, lo, hi) => Math.min(hi, Math.max(lo, Number(x) || 0));
          this.run('INSERT OR REPLACE INTO places (av, acc, x, y, s, r, off, f) VALUES (?, ?, ?, ?, ?, ?, 0, ?)', av, acc, n(v.x, -1, 2), n(v.y, -1, 2), n(v.s, 0.01, 3), n(v.r, -180, 180), v.f ? 1 : 0);
        } else this.run('DELETE FROM places WHERE av = ? AND acc = ?', av, acc);
        return { ok: true };
      }
      case 'accOn': this.kvSet('accOn', b.on ? '1' : '0'); for (const u of this.sql('SELECT id FROM users WHERE banned = 0')) await this.checkUnlocks(u.id); return { accOn: this.accOn() };
      case 'itemSave': {
        const it = b.item || {};
        const kinds = ['avatar', 'back', 'emote', 'acc'];
        if (!kinds.includes(it.kind)) fail('Tipo sconosciuto');
        const cond = ['free', 'pts', 'wins', 'king'].includes(it.cond) ? it.cond : 'free';
        const id = String(it.id || `${it.kind[0]}-${randHex(4)}`).slice(0, 60);
        const old = this.one('SELECT * FROM items WHERE id = ?', id);
        if (b.asset) {
          const d = String(b.asset);
          if (!/^data:(image|audio)\/[a-z0-9.+-]+;base64,/.test(d) || d.length > 1_500_000) fail('File non valido o troppo grande');
          this.run('INSERT OR REPLACE INTO assets (id, mime, data, v) VALUES (?, ?, ?, ?)', id, d.slice(5, d.indexOf(';')), d, (old?.v || 0) + 1);
        }
        const data = { ...(old ? JSON.parse(old.data || '{}') : {}), ...(it.data || {}) };
        if (b.asset) data.asset = true;
        if (old) this.run('UPDATE items SET name = ?, cond = ?, n = ?, data = ?, ord = ?, hidden = ?, v = v + ? WHERE id = ?', String(it.name || old.name).slice(0, 40), cond, Math.max(0, Number(it.n) || 0), JSON.stringify(data), Number(it.ord ?? old.ord) || 0, it.hidden ? 1 : 0, b.asset ? 1 : 0, id);
        else this.run('INSERT INTO items (id, kind, name, cond, n, data, ord, created, hidden) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', id, it.kind, String(it.name || '').slice(0, 40), cond, Math.max(0, Number(it.n) || 0), JSON.stringify(data), Number(it.ord) || 0, now(), it.hidden ? 1 : 0);
        // chi ha già i punti o le vittorie lo sblocca subito
        if (cond === 'pts' || cond === 'wins') for (const u of this.sql('SELECT id FROM users WHERE banned = 0')) await this.checkUnlocks(u.id);
        return { ok: true, id };
      }
      case 'itemDelete': {
        const id = String(b.id || '');
        this.run('DELETE FROM items WHERE id = ?', id); this.run('DELETE FROM assets WHERE id = ?', id); this.run('DELETE FROM unlocks WHERE item = ?', id); this.run('DELETE FROM places WHERE acc = ?', id);
        this.run("UPDATE users SET back = NULL WHERE back = ?", id);
        return { ok: true };
      }
      case 'backup': {
        const tables = ['users', 'friends', 'games', 'gplayers', 'rhist', 'comms', 'cmembers', 'creqs', 'calls', 'notifs', 'spoints', 'daily', 'items', 'unlocks', 'kv', 'assets', 'places', 'dms', 'blocks', 'pwreq', 'act', 'devs'];
        const out = {};
        for (const t of tables) out[t] = this.sql(`SELECT * FROM ${t}`); // le password sono solo in forma cifrata
        return out;
      }
    }
    fail('Operazione sconosciuta');
  }
}
