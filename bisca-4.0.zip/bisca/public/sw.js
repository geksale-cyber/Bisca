// Service worker: rende l'app installabile. La partita passa sempre dalla rete.
// Le carte (e il dorso, il logo) non cambiano mai: si scaricano una volta, restano sul telefono e da lì
// si prendono subito, senza passare dalla rete (niente carte bianche col segnale debole).
// Se un giorno si cambiano le immagini delle carte, si cambia il nome di CARDS.
const CACHE = 'bisca-v30';
const IMGS = 'bisca-img-v1'; // avatar, dorsi, accessori e audio delle emote: indirizzi con ?v=, non cambiano mai
const CARDS = 'bisca-carte-v1';
const SUITS = ['bastoni', 'spade', 'coppe', 'denari'];
const CARD_FILES = [...SUITS.flatMap((s) => Array.from({ length: 10 }, (_, i) => `carte/${s}-${i + 1}.webp`)), 'icons/back.webp'];
const isCardImg = (p) => /\/carte\/[a-z]+-\d+\.webp$/.test(p) || p.endsWith('/icons/back.webp');
const SHELL = ['./', 'index.html', 'style.css', 'app.js', 'lib/engine.js', 'lib/ai.js', 'lib/quick.js', 'lib/tutorial.js', 'vite.html', 'vite.js', 'lib/lives.js', 'lib/quiet.js', 'lib/rating.js', 'lib/season.js', 'lib/daily.js', 'lib/audio.js', 'lib/look.js', 'social.js', 'manifest.webmanifest', 'icons/icon-192.png'];
self.addEventListener('install', (e) => {
  e.waitUntil(Promise.all([
    caches.open(CACHE).then((c) => c.addAll(SHELL)),
    caches.open(CARDS).then(async (c) => { for (const f of CARD_FILES) { if (!(await c.match(f))) { try { await c.add(f); } catch {} } } }),
  ]).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== CACHE && x !== CARDS && x !== IMGS).map((x) => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  // avatar e oggetti: si scaricano una volta e restano sul telefono (una nuova versione ha un altro ?v=)
  if (/\/api\/(avatars\/img|asset)\//.test(url.pathname) && url.searchParams.has('v')) {
    e.respondWith(caches.open(IMGS).then(async (c) => {
      const hit = await c.match(e.request);
      if (hit) return hit;
      const res = await fetch(e.request);
      if (res.ok) c.put(e.request, res.clone());
      return res;
    }));
    return;
  }
  if (url.pathname.includes('/api/')) return;
  if (isCardImg(url.pathname)) {
    e.respondWith(caches.open(CARDS).then(async (c) => {
      const hit = await c.match(e.request, { ignoreSearch: true });
      if (hit) return hit;
      const res = await fetch(e.request);
      if (res.ok) c.put(e.request, res.clone());
      return res;
    }));
    return;
  }
  e.respondWith(fetch(e.request).then((res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); return res; }).catch(() => caches.match(e.request).then((r) => r || caches.match('./'))));
});

// Notifiche push: solo "Chi gioca a Bisca?" e menzioni. Toccandole si apre l'app nel punto giusto.
self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch { d = { title: 'Bisca', body: e.data && e.data.text() }; }
  e.waitUntil(self.registration.showNotification(d.title || 'Bisca', {
    body: d.body || '', tag: d.tag || undefined, renotify: false,
    icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', data: { url: d.url || './' },
    vibrate: d.vibrate ? [300, 120, 300, 120, 300] : undefined, requireInteraction: !!d.vibrate,
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = new URL(e.notification.data?.url || './', self.registration.scope).href;
  e.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const c = all.find((w) => w.url.startsWith(self.registration.scope));
    if (c) { await c.focus(); c.postMessage({ t: 'open', url }); return; }
    await self.clients.openWindow(url);
  })());
});
