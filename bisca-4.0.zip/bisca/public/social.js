// Account e parte social di Bisca: accesso, profilo, amici, notifiche, community con chat, classifica,
// notifiche push e orari di silenzio. Disegna in un suo livello sopra l'app (#social), così il gioco resta com'è.
import * as AU from './lib/audio.js';
import { isQuiet, defaultQuiet, DAY_NAMES, italianHolidays } from './lib/quiet.js';

let X = null; // contesto passato dall'app: esc, toast, avImg, avById, avatars, joinCode, createRoom, openRoom, lobbyCode, onAccount
const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(k); } catch {} },
};
const TZ = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Rome'; } catch { return 'Europe/Rome'; } })();
const A = { token: store.get('bisca:session'), me: store.get('bisca:me'), ws: null, retry: 0, unread: 0, notifs: [], presence: {} };
const V = { stack: [], data: {} };
let $root, $sheet;
const esc = (s) => X.esc(s);
const ICON = {
  people: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9" r="2.6"/><path d="M15.5 14.2c2.3.2 4.1 1.8 4.6 4.8"/></svg>',
  back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
  send: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12l16-8-6 16-2.5-6.5z"/></svg>',
};

// ------------------------------------------------------------ API
async function rpc(op, body = {}) {
  const res = await fetch('api/u', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ op, token: A.token, ...body }) });
  const data = await res.json().catch(() => ({ error: 'Errore di rete' }));
  if (data.auth === false && A.token) { logoutLocal(); }
  if (data.error) throw new Error(data.error);
  return data;
}
export const api = (op, body) => rpc(op, body);
// errori: arrivano all'admin da soli (al massimo 8 per sessione, senza doppioni)
const ERR_SENT = new Set();
export function reportError(kind, msg, stack = '') {
  const k = kind + '|' + msg;
  if (ERR_SENT.has(k) || ERR_SENT.size >= 8) return;
  ERR_SENT.add(k);
  const standalone = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone;
  fetch('api/u', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ op: 'clientError', token: A.token, kind, msg: String(msg).slice(0, 400), stack: String(stack || '').slice(0, 1500), ua: navigator.userAgent + (standalone ? ' standalone' : ''), url: location.pathname + location.search }) }).catch(() => {});
}
window.addEventListener('error', (e) => { if (e.message && !/ResizeObserver|Script error/.test(e.message)) reportError('js', e.message, `${e.filename || ''}:${e.lineno || ''}\n${e.error?.stack || ''}`); });
window.addEventListener('unhandledrejection', (e) => { const r = e.reason; const m = r?.message || String(r); if (!/AbortError|NotAllowedError|Failed to fetch|Load failed|NetworkError/.test(m)) reportError('promise', m, r?.stack || ''); });
export function redraw() { if (isOpen()) draw(); }
export const loggedIn = () => !!A.token;
export const me = () => A.me;
export const session = () => A.token;

function setMe(m) { A.me = m; store.set('bisca:me', m); X?.onAccount?.(m); badge(); }
function logoutLocal() { A.token = null; store.del('bisca:session'); setMe(null); if (A.ws) { A.ws.onclose = null; try { A.ws.close(); } catch {} A.ws = null; } }

// ------------------------------------------------------------ presenza e notifiche in tempo reale
function connect() {
  if (!A.token || A.ws) return;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const base = location.pathname.replace(/[^/]*$/, '');
  const ws = new WebSocket(`${proto}://${location.host}${base}api/u/ws?token=${encodeURIComponent(A.token)}&dev=${devCode()}`);
  A.ws = ws;
  ws.onopen = () => { A.retry = 0; if (A.game !== undefined) ws.send(JSON.stringify({ t: 'status', game: A.game })); };
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.t === 'hello') { setMe(m.me); loadNotifs(); }
    else if (m.t === 'unlocked') loadItems(true);
    else if (m.t === 'notif') {
      const n = m.n;
      if (INFO.includes(n.type)) { X.toast(infoText(n)); rpc('notifRead', { ids: [n.id] }).catch(() => {}); if (isOpen()) load(top()); return; }
      A.notifs.unshift(n); badge();
      if (n.type === 'invite') inviteBanner(n);
      if (n.type === 'mention') X.toast(`${n.data.from?.username} ti ha menzionato in ${n.data.cname}`);
      if (n.type === 'friend_req') banner(`${avatar(n.data.from, 'soav')}<span><b>${esc(n.data.from?.username)}</b> vuole essere tuo amico</span><button class="btn small" data-s="fr-ok" data-uid="${n.data.from?.id}">Accetta</button>`);
      if (isOpen()) { const v = top(); if (v.k === 'comm' && v.cid === n.data?.cid && v.sub === 'chat' && n.type === 'mention') markComm(v.cid); else draw(); }
    } else if (m.t === 'presence') { A.presence[m.uid] = m.state; if (isOpen()) draw(); }
    else if (m.t === 'toast') X.toast(m.msg);
    else if (m.t === 'dm') {
      const v = isOpen() ? top() : null;
      if (v?.k === 'dm' && v.uid === m.msg.from.id && V.data.dm?.uid === v.uid) {
        V.data.dm.msgs.push({ id: m.msg.id, mine: false, text: m.msg.text, ts: m.msg.ts });
        rpc('dmRead', { uid: v.uid }).catch(() => {}); draw();
      } else {
        if (A.me) A.me.dmUnread = (A.me.dmUnread || 0) + 1;
        badge();
        X.toast(`💬 ${m.msg.from.username}: ${m.msg.text.slice(0, 60)}`);
        if (v?.k === 'tab' && v.tab === 'dms') load(v); else if (isOpen()) draw();
      }
    }
  };
  ws.onclose = (e) => {
    if (A.ws !== ws) return;
    A.ws = null;
    if (e.code === 4001 || !A.token) return;
    A.retry++;
    setTimeout(connect, Math.min(1000 * 2 ** A.retry, 15000));
  };
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && A.token && !A.ws) { A.retry = 0; connect(); } });
// battito: ogni 25 s l'app dice al server che c'è ancora (e se è in partita)
setInterval(() => { if (A.ws?.readyState === 1 && !document.hidden) A.ws.send(JSON.stringify({ t: 'hb', game: A.game ?? null })); }, 25000);
// "in partita": l'app avvisa quando entra o esce da una stanza
export function setGame(code) {
  if (A.game === (code || null)) return;
  A.game = code || null;
  if (A.ws?.readyState === 1) A.ws.send(JSON.stringify({ t: 'status', game: A.game }));
}

// Contatori: amici (richieste e inviti a giocare) e community (menzioni, chiamate, richieste, inviti).
const INFO = ['friend_ok', 'cjoin', 'cowner'];
const live = (n) => !n.read && (!n.expires || n.expires > Date.now()) && !(n.type === 'call' && Date.now() - n.created > 3 * 3600e3);
function counts() {
  const L = A.notifs.filter(live);
  const byC = {};
  for (const n of L) {
    const c = n.data?.cid; if (!c) continue;
    const x = (byC[c] ||= { men: 0, call: 0, req: 0 });
    if (n.type === 'mention') x.men++; else if (n.type === 'call') x.call++; else if (n.type === 'creq') x.req++;
  }
  const fr = L.filter((n) => n.type === 'friend_req' || n.type === 'invite').length;
  const cm = L.filter((n) => ['mention', 'call', 'creq', 'cinvite'].includes(n.type)).length;
  return { fr, cm, total: fr + cm, byC, list: L };
}
function infoText(n) {
  const d = n.data || {};
  if (n.type === 'friend_ok') return `${d.from?.username} ha accettato la tua amicizia`;
  if (n.type === 'cjoin') return `Sei entrato nella community ${d.cname}`;
  if (n.type === 'cowner') return `Ora sei il proprietario di ${d.cname}`;
  return '';
}
async function loadNotifs() {
  if (!A.token) return;
  try {
    const d = await rpc('notifs');
    const info = d.list.filter((n) => INFO.includes(n.type));
    if (info.length) rpc('notifRead', { ids: info.map((n) => n.id) }).catch(() => {});
    A.notifs = d.list.filter((n) => !INFO.includes(n.type));
    badge();
    if (isOpen()) draw();
  } catch {}
}
// segna come lette le notifiche di una community (aprendo la chat o le richieste)
function markComm(cid, types = ['mention', 'call']) {
  const had = A.notifs.some((n) => n.data?.cid === cid && types.includes(n.type) && !n.read);
  A.notifs = A.notifs.filter((n) => !(n.data?.cid === cid && types.includes(n.type)));
  badge();
  if (had) rpc('notifReadWhere', { cid, types }).catch(() => {});
}
function badge() {
  const c = counts();
  const t = c.total + (A.me?.dmUnread || 0);
  A.unread = t;
  for (const el of document.querySelectorAll('[data-sbadge]')) { el.textContent = t > 9 ? '9+' : String(t); el.hidden = !t; }
}

// ------------------------------------------------------------ avvio
export function init(ctx) {
  X = ctx;
  $root = document.createElement('div'); $root.id = 'social'; $root.hidden = true; $root.setAttribute('role', 'dialog'); $root.setAttribute('aria-modal', 'true');
  $sheet = document.createElement('div'); $sheet.className = 'sheet socsheet'; $sheet.hidden = true;
  document.body.append($root, $sheet);
  document.addEventListener('click', onClick);
  document.addEventListener('input', onInput);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.id === 'chatin' && !e.shiftKey) { e.preventDefault(); if (top()?.k === 'dm') $root.querySelector('[data-s="dm-send"]')?.click(); else sendChat(); }
    if (e.key === 'Enter' && $sheet.contains(e.target) && e.target.tagName === 'INPUT') $sheet.querySelector('[data-s-enter]')?.click();
    if (e.key === 'Escape' && !$sheet.hidden) closeSheet();
  });
  const ready = A.token ? (connect(), rpc('me').then((d) => setMe(d.me)).catch(() => {})) : Promise.resolve();
  ready.then(() => loadItems(true));
  if (A.token) ready.then(() => setTimeout(wrapNudge, 2500));
  // link dalle notifiche: ?c=COMMUNITY&m=MESSAGGIO oppure ?join=STANZA
  const q = new URLSearchParams(location.search);
  if (q.get('c')) { const c = q.get('c'), m = q.get('m'); cleanUrl(['c', 'm']); ready.then(() => openComm(c, m)); }
  if (q.get('dm')) { const u = q.get('dm'); cleanUrl(['dm']); ready.then(() => openDm(u)); }
  if (navigator.serviceWorker) navigator.serviceWorker.addEventListener('message', (e) => { if (e.data?.t === 'open') handleUrl(e.data.url); });
}
function cleanUrl(keys) { try { const u = new URL(location.href); keys.forEach((k) => u.searchParams.delete(k)); history.replaceState(null, '', u); } catch {} }
export function handleUrl(url) {
  try {
    const u = new URL(url, location.href);
    if (u.searchParams.get('c')) openComm(u.searchParams.get('c'), u.searchParams.get('m'));
    else if (u.searchParams.get('dm')) openDm(u.searchParams.get('dm'));
    else if (u.searchParams.get('join')) X.joinCode(u.searchParams.get('join'));
  } catch {}
}

// barra in alto nella home: profilo a sinistra, notifiche e social a destra
export function homeBar(off = false) {
  if (off) {
    return `<div class="homebar off" aria-disabled="true">
    <button class="hbme" data-s="off" aria-disabled="true"><span>?</span><b>Accedi</b></button>
    <button class="hbsoc" data-s="off" aria-disabled="true" aria-label="Amici e community: solo nella versione online">${ICON.people}</button>
  </div>`;
  }
  const m = A.me;
  const src = m && X.lookSrc(m.avatar, m.acc);
  const av = src ? `<img src="${src}" alt="">` : `<span>${m ? esc(m.username[0].toUpperCase()) : '?'}</span>`;
  return `<div class="homebar">
    <button class="hbme" data-s="me" aria-label="${m ? 'Il tuo profilo' : 'Accedi'}">${av}<b>${m ? esc(m.username) : 'Accedi'}</b></button>
    <button class="hbsoc" data-s="panel" aria-label="Amici, community e notifiche">${ICON.people}<em data-sbadge ${A.unread ? '' : 'hidden'}>${A.unread > 9 ? '9+' : A.unread}</em></button>
  </div>`;
}

// ------------------------------------------------------------ navigazione
const isOpen = () => !$root.hidden;
function show(view) { V.stack.push(view); $root.hidden = false; document.body.classList.add('soc-open'); draw(); load(view); }
function back() {
  const v = V.stack.pop();
  if (v?.k === 'comm') closeChatWs();
  if (!V.stack.length) { $root.hidden = true; document.body.classList.remove('soc-open'); return; }
  draw(); load(top());
}
export function close() { closeChatWs(); V.stack = []; $root.hidden = true; document.body.classList.remove('soc-open'); closeSheet(); }
const top = () => V.stack[V.stack.length - 1];
export function openPanel(tab) {
  if (!tab) { const c = counts(); tab = c.cm && !c.fr ? 'comms' : 'friends'; }
  setTimeout(pushPopup, 400); if (!requireLogin(() => openPanel(tab))) return; V.stack = []; show({ k: 'tab', tab }); }
export function openProfile(uid) { show({ k: 'profile', uid }); }
export function openComm(cid, mid) { if (!requireLogin(() => openComm(cid, mid))) return; show({ k: 'comm', cid: String(cid).toUpperCase(), sub: 'chat', mid: mid ? Number(mid) : null }); }

// carica i dati della vista
async function load(v) {
  try {
    if (v.k === 'tab') loadNotifs();
    if (v.k === 'tab' && v.tab === 'friends') { V.data.friends = await rpc('friends'); for (const f of V.data.friends.friends) A.presence[f.id] = f.presence; }
    if (v.k === 'tab' && v.tab === 'comms') { V.data.mine = (await rpc('cMine')).list; V.data.found = (await rpc('cSearch', { q: V.data.cq || '' })).list; }
    if (v.k === 'tab' && v.tab === 'rank') V.data.lb = await rpc('leaderboard');
    if (v.k === 'tab' && v.tab === 'dms') V.data.dms = await rpc('dmList');
    if (v.k === 'dm') {
      const d = await rpc('dmGet', { uid: v.uid });
      V.data.dm = { ...d, uid: v.uid };
      if (A.me) { A.me.dmUnread = Math.max(0, (A.me.dmUnread || 0) - d.msgs.filter((m) => !m.mine).length); badge(); }
    }
    if (v.k === 'profile') V.data.profile = await rpc('profile', { uid: v.uid });
    if (v.k === 'palmares') V.data.palm = await rpc('palmares');
    if (v.k === 'wrapped') V.data.wrap = await rpc('wrapped', v.season ? { season: v.season } : {});
    if (v.k === 'season') V.data.slb = await rpc('leaderboard', { season: v.season });
    if (v.k === 'me') { const d = await rpc('me'); setMe(d.me); V.data.profile = await rpc('profile', { uid: d.me.id }); }
    if (v.k === 'comm') {
      V.data.comm = await rpc('cGet', { cid: v.cid });
      if (V.data.comm.c.role && v.sub === 'chat') { openChatWs(v.cid, v.mid); markComm(v.cid); }
      if (V.data.comm.c.role && v.sub === 'members') markComm(v.cid, ['creq']);
    }
  } catch (e) { X.toast(e.message); }
  if (top() === v) draw();
}

// ------------------------------------------------------------ disegno
function avatar(u, cls = 'soav') {
  const src = u && X.lookSrc(u.avatar, u.acc);
  return src ? `<img class="${cls}" src="${src}" alt="">` : `<span class="${cls} ini">${esc((u?.username || u?.uname || '?')[0].toUpperCase())}</span>`;
}
const hue = (s) => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };
function logo(c, cls = 'clogo') {
  if (c.logo) return `<img class="${cls}" src="api/clogo/${c.id}?v=${c.logo}" alt="">`;
  return `<span class="${cls} ini" style="--h:${hue(c.id)}">${esc(c.name[0].toUpperCase())}</span>`;
}
const presLabel = { online: 'Online', game: 'In partita', offline: 'Offline' };
const dot = (p) => `<i class="pdot ${p || 'offline'}" aria-hidden="true"></i>`;
const when = (ts) => { const d = new Date(ts); const today = new Date().toDateString() === d.toDateString(); return today ? d.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('it-IT', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }); };
const bar = (title, sub = '') => `<div class="socbar"><button class="iconbtn" data-s="back" aria-label="Indietro">${ICON.back}</button><div class="t"><b>${title}</b>${sub ? `<span>${sub}</span>` : ''}</div></div>`;

function draw() {
  const v = top();
  if (!v) return;
  let html = '';
  if (v.k === 'tab') html = tabsHTML(v);
  else if (v.k === 'profile' || v.k === 'me') html = profileHTML(v);
  else if (v.k === 'comm') html = commHTML(v);
  else if (v.k === 'quiet') html = quietHTML();
  else if (v.k === 'notifset') html = notifSetHTML();
  else if (v.k === 'look') html = lookHTML();
  else if (v.k === 'palmares') html = palmaresHTML();
  else if (v.k === 'dm') html = dmHTML(v);
  else if (v.k === 'wrapped') html = wrappedHTML(v);
  else if (v.k === 'season') html = `${bar(V.data.slb?.season === v.season ? `Stagione di ${esc(V.data.slb.name)}` : 'Stagione')}${V.data.slb?.season === v.season ? rankHTML(V.data.slb) : '<p class="empty">…</p>'}`;
  const keep = (v.k === 'comm' && v.sub === 'chat') || v.k === 'dm' ? $root.querySelector('#chatin')?.value : null;
  $root.innerHTML = `<div class="socwrap">${html}</div>`;
  if (keep != null) { const i = $root.querySelector('#chatin'); if (i) i.value = keep; }
  if (v.k === 'dm' && v.prefill && !keep) { const i = $root.querySelector('#chatin'); if (i) { i.value = v.prefill; v.prefill = ''; } }
  if ((v.k === 'comm' && v.sub === 'chat') || v.k === 'dm') scrollChat();
}

function tabsHTML(v) {
  const c = counts();
  const tabs = [['friends', 'Amici', c.fr], ['dms', 'Messaggi', A.me?.dmUnread || 0], ['comms', 'Community', c.cm], ['rank', 'Classifica', 0]];
  let body = '';
  if (v.tab === 'dms') body = dmsHTML();
  if (v.tab === 'friends') body = friendsHTML(c);
  if (v.tab === 'comms') body = commsHTML(c);
  if (v.tab === 'rank') body = rankHTML();
  const m = A.me;
  return `<div class="sochero">
      <button class="iconbtn" data-s="back" aria-label="Chiudi">${ICON.back}</button>
      <button class="sochme" data-s="me">${avatar(m, 'soav')}<span><b>${esc(m?.username || '')}</b><small>${m ? `il tuo profilo ›` : ''}</small></span></button>
    </div>
    <div class="soctabs2">${tabs.map(([k, l, n]) => `<button class="${v.tab === k ? 'on' : ''}" data-s="tab" data-v="${k}">${l}${n ? `<em>${n > 9 ? '9+' : n}</em>` : ''}</button>`).join('')}</div>
    ${body}`;
}

const bellBtn = () => `<button class="bellbtn ${pushState() === 'on' ? 'on' : ''}" data-s="notifset" aria-label="Notifiche e orari di silenzio">🔔</button>`;

// Prima volta che si apre il pannello: invito ad attivare le notifiche
function pushPopup() {
  const st = pushState();
  if (!A.token || st === 'on' || st === 'no' || st === 'denied' || store.get('bisca:pushAsked')) return;
  store.set('bisca:pushAsked', Date.now());
  const list = '<ul class="plist2"><li>👋 un amico ti <b>invita a giocare</b></li><li>🎴 nelle tue community qualcuno <b>avvia una partita</b> e cerca giocatori</li><li>💬 qualcuno ti <b>tagga</b> con @ in chat</li></ul>';
  if (st === 'ios-install') {
    openSheet(`<h2>🔔 Le notifiche di Bisca</h2><p class="muted">Così sai subito quando:</p>${list}<p class="warnbox">Su iPhone arrivano solo con Bisca <b>installata nella schermata Home</b>: tocca Condividi <b>⬆︎</b>, poi "Aggiungi alla schermata Home", apri Bisca da lì e attivale dalla campanella 🔔.</p>`);
    return;
  }
  openSheet(`<h2>🔔 Attiva le notifiche</h2><p class="muted">Così sai subito quando:</p>${list}
    <p class="hint" style="text-align:left">Gli orari in cui non vuoi essere disturbato li scegli quando vuoi dalla campanella 🔔 in Amici e Community.</p>
    <button class="btn" data-s="push-on-pop">Attiva le notifiche</button>`);
}

// Notifiche push: sempre in vista finché non sono attive su questo telefono
const pushLocal = () => store.get('bisca:pushOn') === A.me?.id;
function pushState() {
  const sup = pushSupport();
  if (sup !== 'ok') return sup;
  if (Notification.permission === 'denied') return 'denied';
  return Notification.permission === 'granted' && pushLocal() ? 'on' : 'off';
}
function pushStrip(where) {
  const st = pushState();
  const q = A.me?.quiet;
  const what = where === 'comm' ? 'quando qualcuno ti tagga qui o la community cerca giocatori' : 'quando ti taggano o una tua community cerca giocatori';
  if (st === 'on') {
    const n = A.me?.notif || {};
    return `<button class="pstrip on" data-s="notifset"><span class="pi">🔔</span><span><b>Notifiche attive</b><small>Chiamate ${n.calls ? '✓' : '✗'} · Menzioni ${n.mentions ? '✓' : '✗'} · Silenzio ${q?.on ? 'programmato' : 'spento'}</small></span><span class="pgo">Gestisci ›</span></button>`;
  }
  if (st === 'ios-install') return `<div class="pstrip warn"><span class="pi">📲</span><span><b>Notifiche: prima installa Bisca</b><small>Su iPhone arrivano solo dall'app nella schermata Home: tocca Condividi <b>⬆︎</b>, poi "Aggiungi alla schermata Home", e apri Bisca da lì.</small></span></div>`;
  if (st === 'no') return '';
  if (st === 'denied') return `<button class="pstrip warn" data-s="notifset"><span class="pi">🔕</span><span><b>Notifiche bloccate</b><small>Le hai negate nelle impostazioni del telefono: riattivale da lì per Bisca.</small></span></button>`;
  return `<div class="pstrip off"><span class="pi">🔔</span><span><b>Attiva le notifiche</b><small>Ti avvisiamo ${what}. Puoi scegliere gli orari di silenzio.</small></span>
    <span class="pbtns"><button class="btn small" data-s="push-on">Attiva</button><button class="btn small ghost" data-s="quiet">Orari</button></span></div>`;
}

function friendsHTML(c) {
  const f = V.data.friends;
  const res = V.data.found_u;
  const inv = c.list.filter((n) => n.type === 'invite');
  const row = (u, right) => `<div class="urow" data-s="profile" data-uid="${u.id}">${avatar(u)}<span class="un"><b>${esc(u.username)}</b><small>${u.presence ? `${dot(A.presence[u.id] || u.presence)} ${presLabel[A.presence[u.id] || u.presence]}` : `${u.rating} punti`}</small></span>${right || ''}</div>`;
  const pres = (u) => A.presence[u.id] || u.presence;
  return `${inv.length ? `<div class="sect hot"><h3>Inviti a giocare</h3>${inv.map((n) => `<div class="urow invrow">${avatar(n.data.from)}<span class="un"><b>${esc(n.data.from.username)}</b><small>ti ha invitato a una partita</small></span><button class="btn small" data-s="inv-ok" data-id="${n.id}">Partecipa</button><button class="btn small ghost" data-s="inv-no" data-id="${n.id}">No</button></div>`).join('')}</div>` : ''}
    ${f?.incoming.length ? `<div class="sect hot"><h3>Richieste di amicizia</h3>${f.incoming.map((u) => row(u, `<button class="btn small" data-s="fr-ok" data-uid="${u.id}">Accetta</button><button class="btn small ghost" data-s="fr-no" data-uid="${u.id}">No</button>`)).join('')}</div>` : ''}
    <div class="searchrow"><input id="usearch" class="field" placeholder="🔍  Cerca amici per username" value="${esc(V.data.uq || '')}" autocomplete="off" autocapitalize="none">${bellBtn()}</div>
    ${res ? `<div class="ulist">${res.length ? res.map((u) => row(u, '<span class="muted">›</span>')).join('') : '<p class="empty">Nessuno trovato.</p>'}</div>` : ''}
    <div class="sect"><h3>I tuoi amici ${f ? `<span class="muted">· ${f.friends.filter((u) => pres(u) !== 'offline').length} online</span>` : ''}</h3>
    <div class="fgrid">${!f ? '<p class="empty">…</p>' : f.friends.length ? f.friends.map((u) => `<button class="fcard ${pres(u)}" data-s="profile" data-uid="${u.id}">${avatar(u, 'fav')}<b>${esc(u.username)}</b><small>${presLabel[pres(u)]}</small></button>`).join('') : '<p class="empty">Non hai ancora amici: cercali per username qui sopra, oppure tocca il nome di un giocatore durante una partita.</p>'}</div></div>
    ${f?.outgoing.length ? `<div class="sect"><h3>In attesa di risposta</h3>${f.outgoing.map((u) => row(u, '<span class="muted">inviata</span>')).join('')}</div>` : ''}`;
}

function commsHTML(c) {
  const mine = V.data.mine;
  const found = V.data.found || [];
  const cinv = c.list.filter((n) => n.type === 'cinvite');
  const card = (x) => {
    const b = c.byC[x.id] || {};
    const badges = [b.men ? `<em class="bm">@ ${b.men}</em>` : '', b.call ? '<em class="bc">partita aperta</em>' : '', b.req ? `<em class="br">${b.req} ${b.req === 1 ? 'richiesta' : 'richieste'}</em>` : ''].join('');
    return `<button class="ccard" data-s="comm" data-cid="${x.id}">${logo(x)}<span class="un"><b>${esc(x.name)}</b><small>${x.public ? 'Pubblica' : 'Privata'} · ${x.members} ${x.members === 1 ? 'membro' : 'membri'}${x.role && x.role !== 'member' ? ` · ${roleName[x.role]}` : x.requested ? ' · richiesta inviata' : ''}</small>${badges ? `<span class="cbadges">${badges}</span>` : ''}</span><span class="muted">›</span></button>`;
  };
  return `${cinv.length ? `<div class="sect hot"><h3>Ti hanno invitato</h3>${cinv.map((n) => `<div class="urow">${avatar(n.data.from)}<span class="un"><b>${esc(n.data.cname)}</b><small>invito di ${esc(n.data.from.username)}</small></span><button class="btn small" data-s="cinv-ok" data-cid="${n.data.cid}">Entra</button><button class="btn small ghost" data-s="cinv-no" data-cid="${n.data.cid}">No</button></div>`).join('')}</div>` : ''}
    <div class="sect"><h3 class="h3row">Le tue community ${bellBtn()}</h3>
    <div class="ulist">${!mine ? '<p class="empty">…</p>' : mine.length ? mine.map(card).join('') : '<p class="empty">Non sei ancora in nessuna community: creane una per il tuo gruppo o cercane una qui sotto.</p>'}</div>
    <button class="btn ghost newc" data-s="c-new">＋ Crea una community</button></div>
    <div class="sect"><h3>Scopri</h3>
    <div class="searchrow"><input id="csearch" class="field" placeholder="🔍  Nome o codice" value="${esc(V.data.cq || '')}" autocomplete="off"></div>
    <div class="ulist">${found.filter((x) => !x.role).map(card).join('') || '<p class="empty">Nessuna community trovata.</p>'}</div></div>`;
}
const roleName = { owner: 'Proprietario', admin: 'Amministratore', member: 'Membro' };

const fmtPts = (x) => String(Math.round((x || 0) * 100) / 100).replace('.', ',');
function rankHTML(lb = V.data.lb) {
  if (!lb) return '<p class="empty">…</p>';
  const open = !!V.data.rulesOpen;
  const top3 = lb.list.slice(0, 3);
  const podium = top3.length ? `<div class="podium">${[1, 0, 2].filter((i) => top3[i]).map((i) => { const u = top3[i]; return `<button class="pod p${i + 1}" data-s="profile" data-uid="${u.id}">${avatar(u, 'podav')}<b>${esc(u.username)}</b><span>${fmtPts(u.pts)} pt</span><i>${u.pos}</i></button>`; }).join('')}</div>` : '';
  const others = lb.current && lb.seasons.length > 1 ? '<button class="linkbtn" data-s="palmares">Vedi le altre stagioni</button>' : '';
  const seasons = '';
  const kings = lb.kings?.length ? `<div class="kingbar">👑 <span>Re della Bisca di ${esc(lb.kingsSeason)}: ${lb.kings.map((k) => `<b data-s="profile" data-uid="${k.id}">${esc(k.username)}</b>`).join(', ')}</span></div>` : '';
  const me = lb.me;
  return `${kings}${seasons}
    ${me ? `<div class="mypos">${avatar(me)}<span class="un"><b>${me.pos ? `Sei ${me.pos}° nella stagione di ${esc(lb.name)}` : `Non sei ancora in classifica a ${esc(lb.name)}`}</b><small>${me.pos ? `${me.games} partite${me.daily ? ` · ${me.daily} sfide` : ''}` : 'Gioca una partita online, in singolo a medio o difficile, o la sfida del giorno'}</small></span><b class="rt">${fmtPts(me.pts)}</b></div>` : ''}
    ${others}
    ${lb.current ? '' : '<!--'}<details class="rules" ${open ? 'open' : ''} data-s="rules"><summary>📜 Come funziona la classifica</summary>
      <ol>
        <li><b>Una stagione al mese:</b> dal primo all'ultimo giorno si parte tutti da 0. Chi è primo a fine mese è il <b>Re della Bisca</b> per tutto il mese dopo, con il cerchio d'oro attorno all'avatar.</li>
        <li><b>Ogni partita:</b> <b>+1</b> per ogni giocatore che batti, <b>−0,5</b> per ognuno che ti batte, ma al massimo <b>−3</b> a partita. Chi esce nello stesso turno è pari.</li>
        <li>Esempio in 6: il primo +5, il secondo +3,5, il terzo +2, il quarto +0,5, il quinto −1, l'ultimo −2,5. Vincere in 13 vale +12.</li>
        <li><b>Online</b> contano le partite finite con almeno <b>3 giocatori con l'account</b> e almeno 3 turni. Le CPU possono esserci, ma non si contano.</li>
        <li><b>In singolo</b> contano le prime 3 partite del giorno: a <b>medio</b> valgono un quarto, a <b>difficile</b> la metà. A facile non contano.</li>
        <li><b>Sfida del giorno:</b> <b>+2</b> se la superi, niente se fallisci.</li>
        <li><b>Non si va sotto zero:</b> se perdi più punti di quelli che hai, il totale si ferma a 0.</li>
        <li><b>Chi abbandona</b> conta come eliminato nel turno in cui se n'è andato.</li>
      </ol>
      <p class="muted">Nel profilo c'è anche il <b>livello</b>: un punteggio che non si azzera e tiene conto di quanto sono forti quelli che batti.</p>
    </details>${lb.current ? '' : '-->'}
    ${podium}
    <div class="ulist">${lb.list.slice(3).map((u) => `<div class="urow" data-s="profile" data-uid="${u.id}"><span class="pos">${u.pos}</span>${avatar(u)}<span class="un"><b>${esc(u.username)}</b><small>${u.games} partite · ${u.wins} vinte${u.daily ? ` · ${u.daily} sfide` : ''}</small></span><b class="rt">${fmtPts(u.pts)}</b></div>`).join('') || (lb.list.length ? '' : `<p class="empty">${lb.current ? 'Stagione appena iniziata: la prima partita la giocate voi!' : 'Nessuna partita in questa stagione.'}</p>`)}</div>`;
}

// albo d'oro: le stagioni passate col loro podio; toccandone una si apre la classifica completa
function palmaresHTML() {
  const p = V.data.palm;
  if (!p) return `${bar('Le altre stagioni')}<p class="empty">…</p>`;
  return `${bar('Le altre stagioni', 'Albo d\'oro della Bisca')}
    ${p.list.length ? p.list.map((x) => `<button class="palm" data-s="season" data-v="${x.id}"><div class="ph"><b>${esc(x.name)}</b><span>Classifica completa ›</span></div>
      <div class="podium small">${[1, 0, 2].filter((i) => x.top[i]).map((i) => { const u = x.top[i]; return `<div class="pod p${i + 1}">${avatar(u, 'podav')}<b>${i === 0 ? '👑 ' : ''}${esc(u.username)}</b><span>${fmtPts(u.pts)} pt</span><i>${u.pos}</i></div>`; }).join('')}</div></button>`).join('')
      : '<p class="empty">Ancora nessuna stagione conclusa.</p>'}`;
}

function chart(hist) {
  if (!hist || hist.length < 2) return '';
  const vals = hist.map((h) => h.r);
  const lo = Math.min(...vals), hi = Math.max(...vals), span = Math.max(1, hi - lo);
  const W = 300, H = 80;
  const pts = vals.map((v, i) => `${((i / (vals.length - 1)) * W).toFixed(1)},${(H - 6 - ((v - lo) / span) * (H - 12)).toFixed(1)}`).join(' ');
  return `<div class="chart"><div class="chh"><b>Andamento del livello</b><span>${vals[0]} → ${vals[vals.length - 1]}</span></div><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-label="Andamento del punteggio"><polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="2.5" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg><div class="chl"><span>min ${lo}</span><span>max ${hi}</span></div></div>`;
}

// Profilo (4.0): testata con avatar, livello, posizione e punti del mese; Online e Single player uno
// sotto l'altro (non sommati); impostazioni compatte in fondo, in gruppi che si chiudono.
const ICO = {
  cal: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
  bars: '<svg viewBox="0 0 24 24" aria-hidden="true" class="fill"><rect x="4" y="13" width="4" height="7" rx="1.5"/><rect x="10" y="9" width="4" height="11" rx="1.5"/><rect x="16" y="4" width="4" height="16" rx="1.5"/></svg>',
  pen: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4z"/></svg>',
  gear: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/></svg>',
  chev: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  ext: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
};
function profileHTML(v) {
  const p = V.data.profile;
  const self = v.k === 'me' || p?.self;
  if (!p) return `${bar(self ? 'Il tuo profilo' : 'Profilo')}<p class="empty">…</p>`;
  const u = p.user, st = p.stats;
  const pres = A.presence[u.id] || u.presence;
  const m = A.me || {};
  const month = (st.season?.name || '').split(' ')[0];
  const since = new Date(u.since).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' });
  const head = `<div class="socbar pfbar"><button class="iconbtn" data-s="back" aria-label="Indietro">${ICON.back}</button><div class="t"><b>${self ? 'Il tuo profilo' : 'Profilo'}</b></div>${self ? `<button class="iconbtn pfgear" data-s="pf-settings" aria-label="Impostazioni">⚙️</button>` : ''}</div>`;
  const card = `<div class="pfcard">
      <div class="pfav">${avatar(u, 'pfimg')}${self ? `<button class="pfpen" data-s="pick-av" aria-label="Cambia avatar o foto">${ICO.pen}</button>` : ''}</div>
      <div class="pfinfo">
        <div class="pftop"><h2>${esc(u.username)}</h2><button class="pflvl" data-s="lvl-info">${ICO.bars}<span>Livello <b>${Number(u.rating).toLocaleString('it-IT')}</b></span><i>i</i></button></div>
        <p class="pfsince">${ICO.cal} su Bisca dal ${since}${!self && pres ? ` · ${dot(pres)} ${presLabel[pres]}` : ''}${!self && p.friend === 'ok' ? ' · <b>amici</b>' : ''}</p>
        <div class="pfrank"><div class="pfpos"><span class="laur">🏅</span><b>${st.season?.pos ? st.season.pos + '°' : '—'}</b><small>in classifica</small></div><div class="pfpts">${ICO.bars}<b>${fmtPts(st.season?.pts)}</b><small>punti a ${esc(month)}</small></div></div>
      </div></div>
    ${st.king || st.kingTitles ? `<p class="kingnote">👑 ${st.king ? '<b>Re della Bisca</b> in carica' : ''}${st.king && st.kingTitles > 1 ? ' · ' : ''}${st.kingTitles > (st.king ? 1 : 0) ? `${st.kingTitles} ${st.kingTitles === 1 ? 'stagione vinta' : 'stagioni vinte'}` : ''}</p>` : ''}`;
  const tiles = (x) => `<div class="pftiles">
      <div class="pft win"><span class="pi">🏆</span><b>${x.wins}<i>/${x.games}</i></b><small>Vittorie</small></div>
      <div class="pft pod"><span class="pi">🥇</span><b>${x.games6 ? `${x.podiums}<i>/${x.games6}</i>` : '—'}</b><small>Podi</small></div>
      <div class="pft top"><span class="pi">${ICO.bars}</span><b>${x.top != null ? `Top ${x.top}%` : '—'}</b><small>Piazzamento medio</small></div></div>`;
  const L = st.spLevels || {};
  const lvl = (k, label) => { const x = L[k] || { games: 0, wins: 0 }; return `<div class="pfl ${k}"><span>${label}</span><b>${x.wins}/${x.games}</b>${k === 'difficile' && x.wins ? '<i>🏆</i>' : ''}</div>`; };
  const online = `<section class="pfsec"><div class="pfh"><b>👥 Online</b><small>Partite con giocatori reali</small></div>${tiles(st.mp)}</section>`;
  const single = `<section class="pfsec"><div class="pfh"><b>🤖 Single player</b><small>Partite contro la CPU</small></div>${tiles(st.sp)}
      <div class="pfdiff"><span>🎯 Vittorie per difficoltà</span><div>${lvl('facile', 'Facile')}${lvl('medio', 'Medio')}${lvl('difficile', 'Difficile')}</div></div></section>`;
  // testa a testa con chi guardi
  const h = p.h2h;
  const h2h = !self && h ? `<section class="pfsec"><div class="pfh"><b>⚔️ Testa a testa</b><small>Partite online insieme</small></div>
      ${h.games ? `<div class="h2h"><div class="me"><b>${h.ahead}</b><small>volte davanti tu</small></div><div class="vs"><b>${h.games}</b><small>${h.games === 1 ? 'partita' : 'partite'}</small></div><div class="them"><b>${h.behind}</b><small>volte davanti ${esc(u.username)}</small></div></div>
        <p class="hint">${h.ahead > h.behind ? `Per ora comandi tu 😎` : h.ahead < h.behind ? `Per ora ${esc(u.username)} ti domina 😬` : 'Perfetta parità'}</p>` : `<p class="hint">Non avete ancora giocato insieme online.</p>`}</section>` : '';
  let actions = '';
  if (self) {
    const row = (act, icon, label, end = ICO.chev, extra = '') => `<button class="pfrow" data-s="${act}" ${extra}><span class="ri">${icon}</span><span class="rl">${label}</span><span class="re">${end}</span></button>`;
    const open = V.data.pfOpen || {};
    actions = `<div id="pfset"></div>
      <details class="pfgroup" ${open.pers !== false ? 'open' : ''} data-s="pf-group" data-g="pers"><summary><span>🎨</span><b>Personalizzazione</b></summary><div class="pfrows">
        ${row('look', '🃏', IT.accOn ? 'Accessori, reazioni vocali e dorso delle carte' : 'Reazioni vocali e dorso delle carte')}
        ${row('notifset', '🔔', 'Notifiche e orari di silenzio')}
        ${row('wrapped', '📊', 'Il riepilogo della stagione')}
      </div></details>
      <details class="pfgroup" ${open.acc !== false ? 'open' : ''} data-s="pf-group" data-g="acc"><summary><span>👤</span><b>Account</b></summary><div class="pfrows">
        ${m.canRename ? row('rename', '✏️', 'Cambia username <small>(una volta sola)</small>') : ''}
        ${m.admin ? row('pw', '🔒', 'Cambia password') : row('pw-admin', '🔒', 'Richiedi cambio password', ICO.ext)}
        ${m.admin ? `<a class="pfrow" href="admin.html"><span class="ri">🛡️</span><span class="rl">Pannello admin</span><span class="re">${ICO.chev}</span></a>` : ''}
        ${row('logout', '🚪', 'Esci dall\'account')}
      </div></details>
      ${m.canRename ? '' : '<p class="hint">Lo username l\'hai già cambiato una volta: per cambiarlo ancora scrivi all\'amministratore.</p>'}`;
  } else if (A.me) {
    const f = p.friend;
    actions = `<div class="pacts">
      <button class="btn" data-s="dm-open" data-uid="${u.id}">💬 Scrivi</button>
      ${f === 'ok' ? `${X.lobbyCode() ? `<button class="btn ghost" data-s="invite-one" data-uid="${u.id}">Invita nella tua stanza</button>` : ''}<button class="btn ghost" data-s="fr-del" data-uid="${u.id}">Togli dagli amici</button>`
      : f === 'sent' ? '<p class="hint">Richiesta di amicizia inviata</p>'
      : f === 'received' ? `<button class="btn ghost" data-s="fr-ok" data-uid="${u.id}">Accetta l'amicizia</button>`
      : `<button class="btn ghost" data-s="fr-add" data-uid="${u.id}">Aggiungi agli amici</button>`}</div>`;
  }
  return `${head}${card}${online}${single}${h2h}${actions}`;
}

// Statistiche di gioco: un riquadro per ogni numero, con una riga che spiega cosa vuol dire
function statsGrid(s, mode, L) {
  const tile = (cls, big, label, note = '') => `<div class="stile ${cls}"><b>${big}</b><span>${label}</span>${note ? `<small>${note}</small>` : ''}</div>`;
  const dash = '—';
  const tiles = [
    tile('t-win', `${s.wins}<i>/${s.games}</i>`, 'vittorie', s.games ? `${s.pct}% delle partite` : 'ancora nessuna partita'),
    tile('t-pod', s.games6 ? `${s.podiums}<i>/${s.games6}</i>` : dash, 'podi', 'nei tavoli da 6 o più'),
    tile('t-top', s.top != null ? `top ${s.top}%` : dash, 'piazzamento medio', s.top != null ? 'in media finisci in questa parte del tavolo' : ''),
    tile('t-prec', s.precision != null ? `${s.precision}%` : dash, 'chiamate esatte', s.calls ? `su ${s.calls} chiamate` : ''),
    tile('t-bc', s.bonusCall, 'vite bonus da chiamata', 'chiamando 3, 4 o 5 e facendole tutte'),
    tile('t-bz', s.bonusZero, 'vite bonus a zero', 'il primo che arriva a zero vite'),
    tile('t-surv', s.surv != null ? String(s.surv).replace('.', ',') : dash, 'turni a partita', 'quanto resti in gioco, in media'),
    tile('t-str', `${s.streak}<i> · ${s.bestStreak}</i>`, 'vittorie di fila', 'adesso · record'),
  ];
  const lvl = (k, label) => { const x = L[k] || { games: 0, wins: 0 }; return `<div class="lv ${k}"><span>${label}</span><b>${x.wins}<small>/${x.games}</small></b>${k === 'difficile' && x.wins ? '<i title="Vittorie a difficile">🏆</i>' : ''}</div>`; };
  return `<div class="sgrid">${tiles.join('')}</div>
    ${mode === 'sp' ? `<div class="sbox sp"><span>Vittorie per difficoltà</span><div class="lvs">${lvl('facile', 'Facile')}${lvl('medio', 'Medio')}${lvl('difficile', 'Difficile')}</div></div>` : ''}
    <p class="hint">Precisione, vite bonus, podi, piazzamento e turni contano dalle partite giocate con questa versione in poi.</p>`;
}

// ------------------------------------------------------------ riepilogo della stagione (stile "Wrapped")
function wrappedHTML(v) {
  const w = V.data.wrap;
  if (!w || (v.season && w.season !== v.season)) return `${bar('Il riepilogo')}<p class="empty">…</p>`;
  const cur = w.season === seasonNow();
  const pct = w.calls ? Math.round((w.exact / w.calls) * 100) : null;
  const other = cur ? prevSeasonOf(w.season) : seasonNow();
  return `${bar(`La tua stagione di ${esc(w.name.split(' ')[0])}`, cur ? 'in corso' : esc(w.name))}
    <div class="wrap">
      <div class="wbig">${w.king ? '👑' : w.pos && w.pos <= 3 ? ['🥇', '🥈', '🥉'][w.pos - 1] : '🎴'}<b>${w.pos ? `${w.pos}°` : '—'}</b><span>${w.pos ? `in classifica su ${w.of}` : 'non in classifica'}${w.king ? ' · <b>Re della Bisca</b>' : ''}</span></div>
      <div class="wgrid">
        <div><b>${fmtPts(w.pts)}</b><span>punti</span></div>
        <div><b>${w.mp.games}</b><span>partite online · ${w.mp.wins} vinte</span></div>
        <div><b>${w.sp.games}</b><span>single player · ${w.sp.wins} vinte</span></div>
        <div><b>${w.daily}</b><span>sfide del giorno superate</span></div>
        ${pct != null ? `<div><b>${pct}%</b><span>chiamate esatte</span></div>` : ''}
        ${w.best ? `<div><b>${w.best.n}</b><span>giocatori nella tua vittoria più grande</span></div>` : ''}
      </div>
      ${w.nemesis ? `<div class="wduo">😈 <span>La tua bestia nera: <b>${esc(w.nemesis.user.username)}</b> ti è arrivato davanti ${w.nemesis.n} ${w.nemesis.n === 1 ? 'volta' : 'volte'}</span></div>` : ''}
      ${w.victim ? `<div class="wduo">😎 <span>La tua vittima preferita: <b>${esc(w.victim.user.username)}</b>, battuto ${w.victim.n} ${w.victim.n === 1 ? 'volta' : 'volte'}</span></div>` : ''}
    </div>
    <button class="btn" data-s="wrap-share">📤 Condividi il riepilogo</button>
    <button class="btn ghost" data-s="wrap-other" data-v="${other}">${cur ? 'Guarda la stagione passata' : 'Guarda la stagione in corso'}</button>`;
}
const seasonNow = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome', year: 'numeric', month: '2-digit' }).format(new Date()).slice(0, 7);
const prevSeasonOf = (x) => { let [y, m] = x.split('-').map(Number); m--; if (!m) { m = 12; y--; } return `${y}-${String(m).padStart(2, '0')}`; };
// immagine da condividere (WhatsApp & co.)
async function wrapImage(w) {
  const c = document.createElement('canvas'); c.width = 1080; c.height = 1350;
  const g = c.getContext('2d');
  const bg = g.createLinearGradient(0, 0, 1080, 1350); bg.addColorStop(0, '#1b1440'); bg.addColorStop(.55, '#3b2390'); bg.addColorStop(1, '#5b2bc4');
  g.fillStyle = bg; g.fillRect(0, 0, 1080, 1350);
  g.textAlign = 'center'; g.fillStyle = '#c4b5fd'; g.font = '700 44px system-ui, sans-serif';
  g.fillText(`BISCA · stagione di ${w.name}`, 540, 120);
  g.fillStyle = '#fff'; g.font = '800 72px system-ui, sans-serif'; g.fillText(w.user.username, 540, 220);
  g.font = '160px system-ui'; g.fillText(w.king ? '👑' : w.pos && w.pos <= 3 ? ['🥇', '🥈', '🥉'][w.pos - 1] : '🎴', 540, 420);
  g.fillStyle = '#FFD54A'; g.font = '900 150px system-ui, sans-serif'; g.fillText(w.pos ? `${w.pos}°` : '—', 540, 590);
  g.fillStyle = '#e9e3ff'; g.font = '600 40px system-ui, sans-serif'; g.fillText(w.pos ? `in classifica su ${w.of} · ${fmtPts(w.pts)} punti` : 'non in classifica', 540, 660);
  const rows = [[`${w.mp.games}`, `partite online, ${w.mp.wins} vinte`], [`${w.sp.games}`, `single player, ${w.sp.wins} vinte`], [`${w.daily}`, 'sfide del giorno superate']];
  if (w.calls) rows.push([`${Math.round((w.exact / w.calls) * 100)}%`, 'chiamate esatte']);
  rows.forEach(([a, b], i) => { const y = 780 + i * 110; g.fillStyle = 'rgba(255,255,255,.08)'; g.beginPath(); g.roundRect(120, y - 70, 840, 92, 24); g.fill(); g.textAlign = 'left'; g.fillStyle = '#7ef0b5'; g.font = '800 54px system-ui, sans-serif'; g.fillText(a, 160, y); g.fillStyle = '#fff'; g.font = '500 38px system-ui, sans-serif'; g.fillText(b, 160 + Math.max(110, g.measureText(a).width + 40), y - 4); });
  g.textAlign = 'center'; g.fillStyle = '#c4b5fd'; g.font = '600 34px system-ui, sans-serif';
  if (w.nemesis) g.fillText(`Bestia nera: ${w.nemesis.user.username}`, 540, 1250 - (w.victim ? 50 : 0));
  if (w.victim) g.fillText(`Vittima preferita: ${w.victim.user.username}`, 540, 1250);
  g.fillStyle = 'rgba(255,255,255,.6)'; g.font = '500 28px system-ui, sans-serif'; g.fillText(location.host, 540, 1320);
  return new Promise((ok) => c.toBlob(ok, 'image/png'));
}
async function shareWrap() {
  const w = V.data.wrap; if (!w) return;
  const blob = await wrapImage(w);
  const file = new File([blob], `bisca-${w.season}.png`, { type: 'image/png' });
  const text = `La mia stagione di ${w.name} su Bisca: ${w.pos ? `${w.pos}° su ${w.of}` : 'in gioco'}! ${location.origin}${location.pathname}`;
  try {
    if (navigator.canShare?.({ files: [file] })) return await navigator.share({ files: [file], text });
  } catch (e) { if (e.name === 'AbortError') return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = file.name; a.click();
  X.toast('Immagine salvata: mandala su WhatsApp');
}
// a inizio mese, la prima volta che si apre l'app: "Ecco com'è andata la tua stagione"
async function wrapNudge() {
  try {
    const prev = prevSeasonOf(seasonNow());
    if (store.get('bisca:wrapSeen') === prev || Number(new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome', day: '2-digit' }).format(new Date())) > 10) return;
    const w = await rpc('wrapped', { season: prev });
    store.set('bisca:wrapSeen', prev);
    if (!w.mp.games && !w.sp.games && !w.daily) return;
    openSheet(`<h2>📊 La tua stagione di ${esc(w.name)}</h2><p>${w.pos ? `Hai chiuso <b>${w.pos}°</b> su ${w.of} con ${fmtPts(w.pts)} punti.` : 'Ecco com\'è andata.'} Guarda il riepilogo e condividilo.</p><button class="btn" data-s="wrap-open" data-v="${prev}">Guarda il riepilogo</button>`);
  } catch {}
}

// ------------------------------------------------------------ chat privata 1:1
// Solo i due possono leggerla. Resta salvata. Si apre dal profilo di un giocatore (💬 Scrivi) o da qui.
function dmsHTML() {
  const d = V.data.dms;
  if (!d) return '<p class="empty">…</p>';
  const adm = (d.admins || [])[0];
  return `${adm && !A.me?.admin ? `<button class="dmhelp" data-s="dm-open" data-uid="${adm.id}">🛟 <span><b>Scrivi all'amministratore</b><small>problemi, cambio password, segnalazioni</small></span>›</button>` : ''}
    ${d.list.length ? `<div class="dmlist">${d.list.map((c) => `<button class="dmrow ${c.unread ? 'new' : ''}" data-s="dm-open" data-uid="${c.user.id}">${avatar(c.user, 'soav')}<span class="dmt"><b>${esc(c.user.username)}${c.user.presence ? ` ${dot(c.user.presence)}` : ''}</b><small>${c.blocked ? '🚫 bloccato · ' : ''}${c.last.mine ? 'Tu: ' : ''}${esc(c.last.text)}</small></span><span class="dmr"><small>${when(c.last.ts)}</small>${c.unread ? `<em>${c.unread > 9 ? '9+' : c.unread}</em>` : ''}</span></button>`).join('')}</div>`
      : '<p class="empty">Nessun messaggio. Per scrivere a qualcuno apri il suo profilo e tocca 💬 Scrivi.</p>'}`;
}
function dmHTML(v) {
  const d = V.data.dm;
  if (!d || d.uid !== v.uid) return `${bar('Messaggi')}<p class="empty">…</p>`;
  const u = d.user;
  const pres = A.presence[u.id] || u.presence;
  const body = d.msgs.map((m) => `<div class="cmsg ${m.mine ? 'mine' : ''}"><div class="cb"><span class="cn"><small>${when(m.ts)}${m.mine && m.rd ? ' · letto' : ''}</small></span><p>${linkify(esc(m.text))}</p></div></div>`).join('');
  return `<div class="dmhead"><button class="iconbtn" data-s="back" aria-label="Indietro">${ICON.back}</button><button class="dmwho" data-s="profile" data-uid="${u.id}">${avatar(u, 'soav')}<span><b>${esc(u.username)}</b><small>${pres ? `${dot(pres)} ${presLabel[pres]}` : ''}</small></span></button>
      ${u.admin || A.me?.admin ? '' : `<button class="btn small ghost" data-s="dm-block" data-on="${d.blocked ? 0 : 1}">${d.blocked ? 'Sblocca' : 'Blocca'}</button><button class="btn small ghost" data-s="dm-report">Segnala</button>`}</div>
    <div class="chatlist" id="chatlist">${body || '<p class="empty">Scrivi il primo messaggio. Lo leggete solo voi due.</p>'}</div>
    ${d.blockedMe ? '<p class="hint">Questa persona non riceve i tuoi messaggi.</p>' : d.blocked ? '<p class="hint">Hai bloccato questa persona: sbloccala per scriverle.</p>'
      : `<div class="chatin"><textarea id="chatin" rows="1" maxlength="1000" placeholder="Scrivi un messaggio…"></textarea><button class="iconbtn send" data-s="dm-send" aria-label="Invia">${ICON.send}</button></div>`}`;
}
const linkify = (t) => t.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
export function openDm(uid, prefill = '') { if (!A.token) return; openPanel('dms'); show({ k: 'dm', uid, prefill }); }
// apre la chat con l'amministratore (per esempio per cambiare la password)
async function dmAdmin(prefill) {
  try { const d = await rpc('dmList'); const a = (d.admins || [])[0]; if (!a) return X.toast('Nessun amministratore disponibile'); show({ k: 'dm', uid: a.id, prefill }); } catch (e) { X.toast(e.message); }
}

// ------------------------------------------------------------ community
function commHTML(v) {
  const d = V.data.comm;
  if (!d || d.c.id !== v.cid) return `${bar('Community')}<p class="empty">…</p>`;
  const c = d.c;
  const admin = c.role === 'owner' || c.role === 'admin';
  const hero = `<div class="chero" style="--h:${hue(c.id)}">
      <button class="iconbtn" data-s="back" aria-label="Indietro">${ICON.back}</button>
      ${admin ? `<label class="clogo-edit" title="Cambia logo">${logo(c, 'clogo big')}<input type="file" accept="image/*" data-file="logo" hidden><i>✎</i></label>` : logo(c, 'clogo big')}
      <div class="cht"><h2>${esc(c.name)}</h2><small>${c.public ? 'Pubblica' : 'Privata'} · ${c.members} ${c.members === 1 ? 'membro' : 'membri'} · codice ${c.id}</small></div>
      ${c.role ? `<button class="cbell ${pushState() === 'on' ? 'on' : ''}" data-s="notifset" aria-label="Notifiche e orari di silenzio">🔔</button>` : ''}</div>`;
  if (!c.role) {
    return `${hero}
      <p class="cdesc">${esc(c.descr) || '<span class="muted">Nessuna descrizione</span>'}</p>
      ${d.invited ? `<button class="btn" data-s="cinv-ok" data-cid="${c.id}">Accetta l'invito ed entra</button>` : c.public ? `<button class="btn" data-s="c-join" data-cid="${c.id}">Entra nella community</button>` : d.requested ? '<p class="hint">Hai chiesto di entrare: aspetta che un amministratore ti accetti.</p>' : `<button class="btn" data-s="c-join" data-cid="${c.id}">Chiedi di entrare</button>`}`;
  }
  const subs = [['chat', 'Chat'], ['members', `Membri${d.requests?.length ? ` (${d.requests.length})` : ''}`], ['info', 'Info']];
  let body = '';
  if (v.sub === 'chat') body = chatHTML(d);
  if (v.sub === 'members') body = membersHTML(d);
  if (v.sub === 'info') body = infoHTML(d);
  return `${hero}
    ${v.sub === 'chat' && ['off', 'ios-install'].includes(pushState()) ? pushStrip('comm') : ''}
    <div class="soctabs2 small">${subs.map(([k, l]) => `<button class="${v.sub === k ? 'on' : ''}" data-s="csub" data-v="${k}">${l}</button>`).join('')}</div>
    ${body}`;
}

function callBox(d) {
  if (d.call && d.call.by?.id !== A.me?.id) return `<p class="hint callhint">🎴 <b>${esc(d.call.by?.username)}</b> ha avviato una partita: la trovi qui sotto in chat.</p>`;
  if (d.call) return '';
  return `<button class="btn startbtn" data-s="c-call">🎴 Avvia una partita</button>`;
}

// stato delle stanze annunciate in chat (chiesto al server ogni tanto)
const LOBBY = {};
function lobbyState(code) {
  const x = LOBBY[code];
  if (!x || (Date.now() - x.t > 15000 && !x.loading)) {
    LOBBY[code] = { ...(x || {}), loading: true, t: Date.now() };
    fetch(`api/games/${code}/info`, { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)).then((info) => {
      LOBBY[code] = { t: Date.now(), info };
      const v = top(); if (v?.k === 'comm' && v.sub === 'chat') draw();
    }).catch(() => { LOBBY[code] = { t: Date.now(), info: null }; });
  }
  return LOBBY[code];
}
function lobbyCard(m, d, mm) {
  const st = lobbyState(m.code);
  const info = st.info;
  const mine = m.uid === A.me?.id;
  const open = info && info.phase === 'lobby' && info.canJoinAsPlayer;
  const status = st.loading && !info ? '…' : !info ? 'Stanza chiusa' : info.phase === 'lobby' ? (info.canJoinAsPlayer ? `In sala d'attesa · ${info.players.length} ${info.players.length === 1 ? 'giocatore' : 'giocatori'}` : 'Stanza piena') : 'Partita iniziata';
  const canNotify = mine && open && d.call?.code === m.code && !d.call.notified;
  const u = mm[m.uid] || { username: m.uname, avatar: m.avatar };
  return `<div class="lobbymsg ${open ? 'open' : 'closed'}" id="m${m.id}">
    <div class="lmh">${avatar(u, 'cav')}<span><b>${esc(u.username)}</b> ha avviato una partita<small>${when(m.ts)} · ${status}</small></span></div>
    ${open ? `<div class="lma"><button class="btn small" data-s="join" data-code="${m.code}">Partecipa</button>${canNotify ? `<button class="btn small ghost" data-s="c-notify">🔔 Avvisa la community</button>` : mine && d.call?.notified && d.call.code === m.code ? '<small class="muted">Community avvisata</small>' : ''}</div>` : ''}
  </div>`;
}

const CH = { ws: null, cid: null, msgs: [], highlight: null, more: true, retry: 0 };
function membersById() { return Object.fromEntries((V.data.comm?.members || []).map((m) => [m.id, m])); }
function chatHTML(d) {
  const mm = membersById();
  const meId = A.me?.id;
  const msgs = CH.cid === d.c.id ? CH.msgs : [];
  const body = msgs.map((m) => {
    if (m.kind === 'lobby' && !m.del) return lobbyCard(m, d, mm);
    const u = mm[m.uid] || { username: m.uname, avatar: m.avatar };
    const mine = m.uid === meId;
    let text = esc(m.text);
    for (const id of m.men || []) { const t = mm[id]; if (t) text = text.replace(menRe(esc(t.username), 'giu'), `<span class="men ${id === meId ? 'me' : ''}">@${esc(t.username)}</span>`); }
    const canDel = mine || d.c.role === 'owner' || (d.c.role === 'admin' && (mm[m.uid]?.role || 'member') === 'member');
    return `<div class="cmsg ${mine ? 'mine' : ''} ${CH.highlight === m.id ? 'hl' : ''}" id="m${m.id}">${mine ? '' : avatar(u, 'cav')}<div class="cb"><span class="cn">${mine ? '' : `<b data-s="profile" data-uid="${m.uid}">${esc(u.username)}</b>`}<small>${when(m.ts)}</small></span>${m.del ? '<i class="muted">messaggio cancellato</i>' : m.kind === 'audio' ? `<button class="vmsg" data-s="c-play" data-id="${m.id}">▶️ <span>Messaggio vocale · ${Math.round(m.secs || 0)} s</span></button>` : `<p>${text}</p>`}${canDel && !m.del ? `<button class="cdel" data-s="c-del" data-id="${m.id}" aria-label="Cancella messaggio">×</button>` : ''}</div></div>`;
  }).join('');
  return `${callBox(d)}
    <div class="chatlist" id="chatlist">${CH.more && msgs.length >= 50 ? '<button class="btn small ghost" data-s="c-more">Messaggi precedenti</button>' : ''}${body || '<p class="empty">Nessun messaggio: scrivi il primo. Con @ menzioni un membro.</p>'}</div>
    <div class="mentlist" id="mentlist" hidden></div>
    <div class="chatin ${VREC.r ? 'recording' : ''}">${VREC.r ? '<span class="recdot"></span><b class="rect">Sto registrando… (massimo 20 secondi)</b><button class="btn small ghost" data-s="c-vcancel">Annulla</button><button class="btn small" data-s="c-vsend">Manda</button>'
      : `<textarea id="chatin" rows="1" maxlength="1000" placeholder="Scrivi… (@ per menzionare)"></textarea><button class="iconbtn mic" data-s="c-vrec" aria-label="Messaggio vocale">🎙️</button><button class="iconbtn send" data-s="c-send" aria-label="Invia">${ICON.send}</button>`}</div>`;
}
// messaggi vocali in chat: si registra (massimo 20 secondi) e si manda
const VREC = { r: null, t: null };
async function vRec() {
  try { VREC.r = await AU.startRecording({ max: 20, rate: 8000 }); } catch (e) { X.toast(e.name === 'NotAllowedError' ? 'Serve il permesso del microfono' : e.message || 'Microfono non disponibile'); return; }
  draw();
  VREC.t = setTimeout(() => vStop(true), 20100);
}
async function vStop(sendIt) {
  clearTimeout(VREC.t);
  const r = VREC.r; VREC.r = null;
  draw();
  if (!r) return;
  const out = await r.stop();
  if (!sendIt) return;
  if (!out || !out.dataUrl || out.seconds < 0.5) return X.toast('Messaggio troppo corto');
  if (CH.ws?.readyState === 1) CH.ws.send(JSON.stringify({ t: 'msg', audio: out.dataUrl, secs: out.seconds }));
  else X.toast('Non sei collegato alla chat');
}

function scrollChat() {
  const l = $root.querySelector('#chatlist');
  if (!l) return;
  if (CH.highlight) { const el = $root.querySelector('#m' + CH.highlight); if (el) { el.scrollIntoView({ block: 'center' }); return; } }
  if (!CH.keepScroll) l.scrollTop = l.scrollHeight;
  CH.keepScroll = false;
}
function openChatWs(cid, around) {
  if (CH.ws && CH.cid === cid) return;
  closeChatWs();
  Object.assign(CH, { cid, msgs: [], highlight: around || null, more: true });
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const base = location.pathname.replace(/[^/]*$/, '');
  const ws = new WebSocket(`${proto}://${location.host}${base}api/c/${cid}/ws?token=${encodeURIComponent(A.token)}${around ? `&around=${around}` : ''}`);
  CH.ws = ws;
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.t === 'history') { CH.msgs = m.msgs; CH.more = m.msgs.length >= (m.around ? 1 : 50); }
    else if (m.t === 'older') { CH.msgs = [...m.msgs, ...CH.msgs]; CH.more = m.msgs.length >= 50; CH.keepScroll = true; CH.highlight = null; }
    else if (m.t === 'msg') { CH.msgs.push(m.m); CH.highlight = null; }
    else if (m.t === 'del') { const x = CH.msgs.find((y) => y.id === m.id); if (x) x.del = true; }
    else if (m.t === 'error') X.toast(m.msg);
    const v = top();
    if (v?.k === 'comm' && v.sub === 'chat' && v.cid === cid) draw();
  };
  ws.onclose = (e) => {
    if (CH.ws !== ws) return;
    CH.ws = null;
    if (e.code >= 4003) { X.toast(e.code === 4004 ? 'La community è stata eliminata' : 'Non sei più in questa community'); return; }
    const v = top();
    if (v?.k === 'comm' && v.cid === cid) setTimeout(() => { const w = top(); if (w?.k === 'comm' && w.cid === cid && !CH.ws) openChatWs(cid); }, 2000);
  };
}
function closeChatWs() { if (CH.ws) { CH.ws.onclose = null; try { CH.ws.close(); } catch {} } CH.ws = null; CH.cid = null; }
function sendChat() {
  const i = $root.querySelector('#chatin');
  const text = (i?.value || '').trim();
  if (!text) return;
  if (CH.ws?.readyState !== 1) return X.toast('Riconnessione…');
  const mm = V.data.comm?.members || [];
  const mentions = mm.filter((m) => menRe(m.username, 'iu').test(text)).map((m) => m.id);
  CH.ws.send(JSON.stringify({ t: 'msg', text, mentions }));
  i.value = '';
  $root.querySelector('#mentlist').hidden = true;
}
// @nome dentro un messaggio (gli username possono avere spazi, accenti e apostrofi)
function menRe(name, flags) { return new RegExp(`@${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![\\p{L}\\p{N}._])`, flags); }
// elenco a tendina quando si scrive @
function mentionSuggest(el) {
  const list = $root.querySelector('#mentlist');
  const before = el.value.slice(0, el.selectionStart);
  const m = before.match(/@([^@\n]{0,20})$/);
  if (!m) { list.hidden = true; return; }
  const q = m[1].toLowerCase();
  const opts = (V.data.comm?.members || []).filter((u) => u.id !== A.me?.id && u.username.toLowerCase().startsWith(q)).slice(0, 6);
  if (!opts.length) { list.hidden = true; return; }
  list.innerHTML = opts.map((u) => `<button data-s="ment-pick" data-name="${esc(u.username)}">${avatar(u, 'cav')}<b>${esc(u.username)}</b></button>`).join('');
  list.hidden = false;
}

function membersHTML(d) {
  const role = d.c.role;
  const admin = role === 'owner' || role === 'admin';
  const reqs = d.requests || [];
  return `${admin ? `<button class="btn ghost" data-s="c-invite">Invita qualcuno</button>` : ''}
    ${reqs.length ? `<div class="label">Chiedono di entrare</div><div class="ulist">${reqs.map((u) => `<div class="urow">${avatar(u)}<span class="un"><b>${esc(u.username)}</b><small>${u.rating} punti</small></span><button class="btn small" data-s="c-acc" data-uid="${u.id}">Accetta</button><button class="btn small ghost" data-s="c-rej" data-uid="${u.id}">No</button></div>`).join('')}</div>` : ''}
    <div class="label">${d.members.length} membri</div>
    <div class="ulist">${d.members.map((u) => `<div class="urow" data-s="c-member" data-uid="${u.id}">${avatar(u)}<span class="un"><b>${esc(u.username)}</b><small>${dot(A.presence[u.id] || u.presence)} ${presLabel[A.presence[u.id] || u.presence]}</small></span>${u.role !== 'member' ? `<span class="vtag ${u.role}">${roleName[u.role]}</span>` : ''}</div>`).join('')}</div>`;
}

function infoHTML(d) {
  const c = d.c, owner = c.role === 'owner', admin = owner || c.role === 'admin';
  return `${admin ? `<div class="label">Logo</div><div class="logorow">${logo(c, 'clogo big')}<label class="btn small">Scegli un'immagine<input type="file" accept="image/*" data-file="logo" hidden></label>${c.logo ? '<button class="btn small ghost" data-s="c-logo-del">Togli</button>' : ''}</div>
    <div class="label">Nome</div><input id="cname" class="field" maxlength="30" value="${esc(c.name)}" ${owner ? '' : 'disabled'}>
    <div class="label">Descrizione</div><textarea id="cdescr" class="field" rows="3" maxlength="300">${esc(c.descr)}</textarea>
    <label class="swrow"><input type="checkbox" id="cpublic" ${c.public ? 'checked' : ''}> <span>Pubblica: chiunque la trova e può entrare</span></label>
    <button class="btn" data-s="c-save">Salva</button>` : `<p class="cdesc">${esc(c.descr) || '<span class="muted">Nessuna descrizione</span>'}</p>`}
    <p class="hint">Codice della community: <b>${c.id}</b></p>
    <button class="btn ghost" data-s="c-leave">Esci dalla community</button>
    ${owner ? '<button class="btn ghost danger" data-s="c-delete">Elimina la community</button>' : ''}`;
}

// ------------------------------------------------------------ notifiche push e orari
const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent);
const standalone = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
function pushSupport() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
    return isIOS && !standalone ? 'ios-install' : 'no';
  }
  return 'ok';
}
function notifSetHTML() {
  const m = A.me || {};
  const sup = pushSupport();
  const perm = 'Notification' in window ? Notification.permission : 'default';
  return `${bar('Notifiche')}
    <p class="muted">Sul telefono arrivano solo tre cose: gli inviti a giocare dei tuoi amici, le partite avviate nelle tue community e le menzioni @${esc(m.username || '')}. Tutto il resto lo trovi dentro l'app.</p>
    ${sup === 'ios-install' ? '<p class="warnbox">Su iPhone le notifiche arrivano solo con Bisca <b>installata nella schermata Home</b> (iOS 16.4 o successivo). Aggiungila dalla home dell\'app e aprila da lì.</p>'
      : sup === 'no' ? '<p class="warnbox">Questo browser non supporta le notifiche push.</p>'
      : perm === 'denied' ? '<p class="warnbox">Le notifiche sono bloccate nelle impostazioni del telefono per Bisca: riattivale da lì.</p>'
      : pushState() === 'on' ? `<div class="pstrip on"><span class="pi">🔔</span><span><b>Attive su questo telefono</b><small>${m.pushDevices > 1 ? `In tutto su ${m.pushDevices} dispositivi.` : ''} <button class="linkbtn" data-s="push-test">Manda una prova</button> · <button class="linkbtn" data-s="push-off">Disattiva qui</button></small></span></div>`
      : `<button class="btn" data-s="push-on">🔔 Attiva le notifiche su questo telefono</button><p class="hint">Il telefono ti chiederà il permesso: rispondi Consenti.</p>`}
    <label class="swrow"><input type="checkbox" id="n-invites" ${m.notif?.invites !== false ? 'checked' : ''}> <span><b>Inviti a giocare degli amici</b><small>Rispettano gli orari di silenzio</small></span></label>
    <label class="swrow"><input type="checkbox" id="n-calls" ${m.notif?.calls ? 'checked' : ''}> <span><b>Partite avviate nelle community</b><small>Rispettano gli orari di silenzio</small></span></label>
    <label class="swrow"><input type="checkbox" id="n-mentions" ${m.notif?.mentions ? 'checked' : ''}> <span><b>Menzioni @${esc(m.username || '')}</b><small>Arrivano anche durante gli orari di silenzio</small></span></label>
    <button class="btn ghost" data-s="quiet">Orari di silenzio${m.quiet?.on ? ' · attivi' : ''}</button>`;
}

const sameRanges = (a, b) => JSON.stringify(a || []) === JSON.stringify(b || []);
function quietHTML() {
  const q = V.data.quiet;
  const rangesHTML = (key, list) => `${list.map((r, i) => `<div class="qrange"><input type="time" data-q="${key}" data-i="${i}" data-e="0" value="${r[0]}"><span>–</span><input type="time" data-q="${key}" data-i="${i}" data-e="1" value="${r[1]}"><button class="iconbtn" data-s="q-del" data-k="${key}" data-i="${i}" aria-label="Togli fascia">×</button></div>`).join('')}<button class="btn small ghost" data-s="q-add" data-k="${key}">+ Aggiungi fascia</button>`;
  const block = (title, key, list) => `<div class="qblock"><b>${title}</b>${list.length ? '' : '<small class="muted">Notifiche sempre consentite</small>'}${rangesHTML(key, list)}</div>`;
  let days;
  if (V.data.qCustom) days = [1, 2, 3, 4, 5, 6, 0].map((d) => block(DAY_NAMES[d], String(d), q.days[d])).join('');
  else days = block('Dal lunedì al venerdì', 'wk', q.days[1]) + block('Sabato', '6', q.days[6]) + block('Domenica', '0', q.days[0]);
  const y = new Date().getFullYear();
  const hol = [...italianHolidays(y)].sort().map((md) => new Date(`${y}-${md}T12:00:00`).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' })).join(', ');
  const now = isQuiet(q, new Date(), TZ);
  return `${bar('Orari di silenzio')}
    <p class="muted">Durante queste fasce non ricevi le chiamate "Chi gioca a Bisca?". Le menzioni arrivano comunque. Le chiamate perse non arrivano dopo: le trovi tra le notifiche.</p>
    <label class="swrow"><input type="checkbox" id="q-on" ${q.on ? 'checked' : ''}> <span><b>Usa gli orari di silenzio</b><small>${q.on ? (now ? 'Adesso sei in silenzio' : 'Adesso le chiamate arrivano') : 'Spento: le chiamate arrivano sempre'}</small></span></label>
    <div class="seg"><button aria-pressed="${!V.data.qCustom}" data-s="q-mode" data-v="0">Feriali e weekend</button><button aria-pressed="${!!V.data.qCustom}" data-s="q-mode" data-v="1">Giorno per giorno</button></div>
    ${days}
    <div class="qblock"><b>Festività</b><small class="muted">${hol}</small>
      <select id="q-hol" class="field">${[['sunday', 'Come la domenica'], ['normal', 'Come un giorno normale'], ['silent', 'Silenzio tutto il giorno'], ['free', 'Notifiche sempre consentite']].map(([k, l]) => `<option value="${k}" ${q.holiday === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="qblock"><b>Eccezioni</b><small class="muted">Per un giorno preciso: un santo patrono, una vacanza, una serata libera.</small>
      ${q.ex.map((x, i) => `<div class="qrange"><span>${new Date(x.d + 'T12:00:00').toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</span><span class="muted">${{ silent: 'silenzio', free: 'sempre', holiday: 'festivo' }[x.m]}</span><button class="iconbtn" data-s="q-exdel" data-i="${i}" aria-label="Togli eccezione">×</button></div>`).join('')}
      <div class="qrange"><input type="date" id="q-exd"><select id="q-exm" class="field"><option value="silent">Silenzio tutto il giorno</option><option value="free">Notifiche sempre consentite</option><option value="holiday">Come un festivo</option></select><button class="btn small" data-s="q-exadd">Aggiungi</button></div></div>
    <button class="btn" data-s="q-save">Salva gli orari</button>
    <p class="hint">Fuso orario: ${esc(TZ)}</p>`;
}
function readQuietInputs() {
  const q = V.data.quiet;
  for (const el of $root.querySelectorAll('[data-q]')) {
    const k = el.dataset.q, i = Number(el.dataset.i), e = Number(el.dataset.e);
    const targets = k === 'wk' ? [1, 2, 3, 4, 5] : [Number(k)];
    for (const d of targets) if (q.days[d][i]) q.days[d][i][e] = el.value || '00:00';
  }
  const on = $root.querySelector('#q-on'); if (on) q.on = on.checked;
  const h = $root.querySelector('#q-hol'); if (h) q.holiday = h.value;
}

// ------------------------------------------------------------ finestre (accesso, avatar, conferme)
function openSheet(html) { $sheet.innerHTML = `<div class="box" role="dialog" aria-modal="true">${html}<button class="btn ghost" data-s="sheet-close">Chiudi</button></div>`; $sheet.hidden = false; setTimeout(() => $sheet.querySelector('input')?.focus(), 60); }
function closeSheet() { $sheet.hidden = true; $sheet.innerHTML = ''; }
let afterLogin = null;
export function requireLogin(then) {
  if (loggedIn()) return true;
  afterLogin = then || null;
  loginSheet(defaultMode());
  return false;
}
// Chi apre per la prima volta quasi sempre deve registrarsi: si parte da "Sono nuovo".
// Se su questo telefono c'è già stato un account, si parte da "Accedi".
function defaultMode() { return store.get('bisca:hadAccount') || store.get('bisca:lastUser') ? 'login' : 'register'; }
// codice casuale di questo browser (non è un ID del telefono): aiuta l'admin a vedere account doppi
export function devCode() {
  let d = store.get('bisca:dev');
  if (!d || String(d).length < 8) { d = Array.from(crypto.getRandomValues(new Uint8Array(12)), (x) => x.toString(16).padStart(2, '0')).join(''); store.set('bisca:dev', d); }
  return d;
}
// Stesse regole dell'Hub (src/hub.js): qui servono per dire subito cosa non va, mentre si scrive.
const USER_RE = /^(?=.{3,20}$)[\p{L}\p{N}](?:[\p{L}\p{N}._'-]| (?! ))*$/u;
const PW_MIN = 4;
const cleanUser = (v) => String(v || '').normalize('NFC').replace(/\s+/g, ' ').trim();
function userProblem(v) {
  const n = cleanUser(v);
  if (!n) return '';
  if (n.length < 3) return 'Troppo corto: almeno 3 caratteri';
  if (n.length > 20) return 'Troppo lungo: al massimo 20 caratteri';
  if (!/^[\p{L}\p{N}]/u.test(n)) return 'Deve iniziare con una lettera o un numero';
  const bad = [...n].find((ch) => !/[\p{L}\p{N}._' -]/u.test(ch));
  if (bad) return `Il carattere "${bad}" non si può usare. Vanno bene lettere, numeri, spazi, punto, trattino e apostrofo`;
  return USER_RE.test(n) ? '' : 'Username non valido';
}
let regAvatar = null, regPhoto = null;
function loginSheet(mode, err = '') {
  const avs = X.avatars();
  const reg = mode === 'register';
  if (reg && !regAvatar && X.settingsPick?.() && X.avById(X.settingsPick())) regAvatar = X.settingsPick();
  const avStrip = reg && avs.length ? `<div class="label">Il tuo avatar <small class="muted">· facoltativo, lo cambi quando vuoi</small></div><div class="avgrid avstrip"><label class="phototile ${regAvatar === '__photo' ? 'on' : ''}">${regPhoto ? `<img src="${regPhoto}" alt="">` : '<span>📷</span>'}<span>La tua foto</span><input type="file" accept="image/*" data-file="reg" hidden></label>${avs.map((a) => `<button class="${regAvatar === a.id ? 'on' : ''}" data-s="reg-av" data-id="${esc(a.id)}" aria-label="${esc(a.name)}"><img src="${X.avImg(a.id)}" alt="" loading="lazy"><span>${esc(a.name)}</span></button>`).join('')}</div>` : '';
  openSheet(`<h2>${reg ? 'Crea il tuo account' : 'Accedi'}</h2>
    <div class="seg"><button aria-pressed="${reg}" data-s="lmode" data-v="register">Sono nuovo</button><button aria-pressed="${!reg}" data-s="lmode" data-v="login">Ho già un account</button></div>
    ${reg && store.get('bisca:lastUser') ? `<div class="warnbox">Su questo telefono hai già usato l'account <b>${esc(store.get('bisca:lastUser'))}</b>. Se sei tu, <a href="#" data-s="lmode" data-v="login">accedi con quello</a>: così non perdi punti e statistiche.</div>` : ''}
    <p class="muted">${reg ? 'Bastano un nome e una password. Niente email, niente numero di telefono.' : 'Entra con il nome e la password che hai scelto quando ti sei registrato.'}</p>
    <label class="label" for="l-user">${reg ? 'Scegli un nome' : 'Il tuo nome (username)'}</label><input id="l-user" class="field" maxlength="24" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="es. Thomas">
    <p class="ferr" id="e-user" role="alert"></p>
    ${reg ? '<p class="fhint">Da 3 a 20 caratteri: lettere (anche accentate), numeri, spazi, punto, trattino. Maiuscole e minuscole sono uguali.</p>' : ''}
    <label class="label" for="l-pass">Password</label><div class="pwrow"><input id="l-pass" class="field" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="${reg ? `almeno ${PW_MIN} caratteri` : ''}"><button type="button" class="pweye" data-s="pw-eye" aria-label="Mostra la password">👁</button></div>
    <p class="ferr" id="e-pass" role="alert"></p>
    ${reg ? '<p class="fhint">Scrivila da qualche parte: se la dimentichi, te la reimposta l\'amministratore.</p>' : '<p class="fhint"><a href="#" data-s="pw-forgot">Password dimenticata?</a></p>'}
    ${avStrip}
    <p class="perr" id="e-gen" role="alert">${esc(err)}</p>
    <button class="btn" data-s="${reg ? 'do-register' : 'do-login'}" data-s-enter>${reg ? 'Crea l\'account' : 'Entra'}</button>
    <p class="hint">${reg ? 'Hai già un account? <a href="#" data-s="lmode" data-v="login">Accedi</a>' : 'Non hai ancora un account? <a href="#" data-s="lmode" data-v="register">Registrati</a>'}</p>`);
  V.loginMode = mode;
  // l'ultimo username usato su questo telefono è già scritto (la password mai)
  if (!reg && store.get('bisca:lastUser')) { const iu = $sheet.querySelector('#l-user'); if (iu && !iu.value) { iu.value = store.get('bisca:lastUser'); setTimeout(() => $sheet.querySelector('#l-pass')?.focus(), 50); } }
}
// Password dimenticata (senza accesso): la richiesta arriva all'amministratore
function forgotSheet(done = false) {
  if (done) return openSheet('<h2>🔑 Richiesta inviata</h2><p>L\'amministratore ti reimposta la password e te la manda sul contatto che hai indicato.</p><button class="btn" data-s="close-sheet">Ok</button>');
  openSheet(`<h2>🔑 Password dimenticata</h2><p class="muted">Scrivi il tuo username e come ti contattiamo: l'amministratore ti reimposta la password e te la manda.</p>
    <label class="label" for="f-user">Il tuo username</label><input id="f-user" class="field" maxlength="24" autocapitalize="none" autocorrect="off" spellcheck="false" value="${esc(store.get('bisca:lastUser') || '')}">
    <label class="label" for="f-contact">Come ti contattiamo</label><textarea id="f-contact" class="field" rows="2" maxlength="200" placeholder="Telefono, email, oppure es. &quot;sono Baie, scrivimela su WhatsApp&quot;"></textarea>
    <p class="perr" id="e-gen" role="alert"></p>
    <button class="btn" data-s="pw-forgot-send">Manda la richiesta</button>`);
}
// errore sotto il campo giusto, senza ridisegnare la finestra (così non si perde quello che si è scritto)
function authErr(field, msg) {
  for (const id of ['e-user', 'e-pass', 'e-gen']) { const el = $sheet.querySelector('#' + id); if (el) el.textContent = ''; }
  $sheet.querySelectorAll('.field.bad').forEach((el) => el.classList.remove('bad'));
  if (!msg) return;
  const el = $sheet.querySelector('#e-' + field) || $sheet.querySelector('#e-gen');
  if (el) { el.textContent = msg; el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  const inp = field === 'user' ? '#l-user' : field === 'pass' ? '#l-pass' : null;
  if (inp) $sheet.querySelector(inp)?.classList.add('bad');
}
// rimette nella finestra quello che c'era scritto (dopo aver scelto un avatar la finestra si ridisegna)
function keepAuthFields(fn) {
  const u = $sheet.querySelector('#l-user')?.value, p = $sheet.querySelector('#l-pass')?.value;
  fn();
  const iu = $sheet.querySelector('#l-user'), ip = $sheet.querySelector('#l-pass');
  if (iu) iu.value = u || ''; if (ip) ip.value = p || '';
}
async function doAuth(op) {
  const username = cleanUser($sheet.querySelector('#l-user')?.value);
  const raw = $sheet.querySelector('#l-pass')?.value || '';
  const password = op === 'register' ? raw.trim() : raw;
  if (!username) return authErr('user', op === 'register' ? 'Scegli un nome' : 'Scrivi il tuo nome');
  if (op === 'register') {
    const pb = userProblem(username); if (pb) return authErr('user', pb);
    if (password.length < PW_MIN) return authErr('pass', `La password deve avere almeno ${PW_MIN} caratteri`);
  } else if (!raw) return authErr('pass', 'Scrivi la password');
  authErr(null);
  const btn = $sheet.querySelector('[data-s-enter]'); if (btn) { btn.disabled = true; btn.textContent = op === 'register' ? 'Creo l\'account…' : 'Entro…'; }
  // senza un avatar scelto se ne assegna uno a caso (si cambia quando si vuole)
  const avs = X.avatars();
  const avatar = regAvatar === '__photo' ? null : (regAvatar || (op === 'register' && avs.length ? avs[Math.floor(Math.random() * avs.length)].id : null));
  try {
    let d;
    try {
      const res = await fetch('api/u', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ op, username, password, avatar, tz: TZ, dev: devCode() }) });
      d = await res.json();
    } catch { throw Object.assign(new Error('Connessione assente o lenta: controlla internet e riprova'), { field: 'gen' }); }
    if (d.error) throw Object.assign(new Error(d.error), { field: /^Username|username|nome/i.test(d.error) && !/password/i.test(d.error) ? 'user' : /password/i.test(d.error) ? (op === 'login' ? 'gen' : 'pass') : 'gen' });
    A.token = d.token; store.set('bisca:session', d.token); store.set('bisca:hadAccount', '1'); store.set('bisca:lastUser', d.me.username); setMe(d.me);
    if (op === 'register' && regAvatar === '__photo' && regPhoto) { try { setMe((await rpc('setPhoto', { data: regPhoto })).me); } catch {} }
    connect();
    closeSheet();
    loadItems(true);
    X.toast(op === 'login' ? `Ciao ${d.me.username}!` : `Benvenuto su Bisca, ${d.me.username}!`);
    const f = afterLogin; afterLogin = null; if (f) f();
  } catch (e) {
    if (btn) { btn.disabled = false; btn.textContent = op === 'register' ? 'Crea l\'account' : 'Entra'; }
    authErr(e.field || 'gen', e.message);
  }
}
function avatarSheet() {
  const cur = A.me?.avatar;
  openSheet(`<h2>Il tuo avatar</h2><p class="muted">Puoi cambiarlo quando vuoi: statistiche e amici restano tuoi.</p><label class="btn">📷 Scatta o scegli una foto<input type="file" accept="image/*" data-file="me" hidden></label><div class="label">Oppure un personaggio</div><div class="avgrid">${X.avatars().map((a) => { const lk = avLocked(a.id); return `<button class="${cur === a.id ? 'on' : ''} ${lk ? 'locked' : ''}" ${lk ? `data-s="locked" data-msg="${esc(lk)}"` : `data-s="set-av" data-id="${esc(a.id)}"`}><img src="${X.avImg(a.id)}" alt="" loading="lazy"><span>${lk ? '🔒 ' : ''}${esc(a.name)}</span></button>`; }).join('')}</div>`);
}
// ------------------------------------------------------------ oggetti da sbloccare
// Avatar bloccati, accessori, dorsi delle carte ed emote: li gestisce l'admin, si sbloccano con le
// vittorie online o con i punti di classifica (tutte le stagioni insieme).
const IT = { items: [], anchors: {}, mine: null, loaded: false };
export const items = () => IT;
const itemById = (id) => IT.items.find((i) => i.id === id);
export async function loadItems(popup = false) {
  try { Object.assign(IT, await rpc('items'), { loaded: true }); } catch { return; }
  X.onLook?.();
  if (top()?.k === 'look') draw();
  if (popup) unlockPopup();
}
const owned = (id) => { const it = itemById(id); return !it || (it.cond === 'free' && !it.excl) || !!IT.mine?.owned?.includes(id); };
function condText(it) {
  const pr = IT.mine?.progress || { pts: 0, wins: 0 };
  if (it.cond === 'king') return 'Solo per il Re della Bisca del mese';
  if (it.cond === 'wins') return `Si sblocca con ${it.n} ${it.n === 1 ? 'vittoria' : 'vittorie'} online (ne hai ${pr.wins})`;
  if (it.cond === 'pts') return `Si sblocca con ${it.n} punti in classifica (ne hai ${String(Math.round(pr.pts * 100) / 100).replace('.', ',')})`;
  return '';
}
function avLocked(id) { const it = IT.items.find((i) => i.kind === 'avatar' && i.id === id); return it && !owned(id) ? condText(it) : ''; }
export const avatarLocked = avLocked;
export function openLook() { show({ k: 'look' }); }
export function accSrc(it) { return it.data?.asset ? `api/asset/${it.id}?v=${it.v}` : it.data?.src || `acc/${it.id}.svg`; }
export async function equipBack(id) { try { const r = await rpc('equip', { back: id || null }); setMe(r.me); X.onLook?.(); return true; } catch (e) { X.toast(e.message); return false; } }
export function backSrc(id) { const it = id && itemById(id); return it?.data?.asset ? `api/asset/${id}?v=${it.v}` : null; }

function lookHTML() {
  if (!IT.loaded) { loadItems(); return `${bar('Reazioni e dorso')}<p class="empty">…</p>`; }
  const m = A.me || {};
  const backs = IT.items.filter((i) => i.kind === 'back' && (!i.excl || owned(i.id)));
  const rx = m.rx || [];
  const tile = (it, on, act, img) => {
    const ok = owned(it.id);
    return `<button class="ltile ${on ? 'on' : ''} ${ok ? '' : 'locked'}" ${ok && act ? `data-s="${act}" data-id="${esc(it.id)}"` : `data-s="locked" data-msg="${esc(condText(it))}"`}>
      ${img}<b>${ok ? '' : '🔒 '}${esc(it.name)}</b><small>${ok ? (on ? 'In uso' : 'Tocca per usarlo') : esc(condText(it))}</small></button>`;
  };
  const accs = IT.accOn ? IT.items.filter((i) => i.kind === 'acc' && i.cond !== 'king' && (!i.excl || owned(i.id))) : [];
  const myAv = m.avatar, worn = m.acc || [];
  const fits = (id) => !!IT.places?.[myAv]?.[id];
  const accHTML = accs.length ? `<div class="label">🎩 Accessori sul tuo avatar</div>
    <p class="hint">Tocca per metterlo o toglierlo. Li vedono tutti, al tavolo e in classifica.</p>
    <div class="lprev"><img src="${X.lookSrc(myAv, worn, 'full') || ''}" alt=""></div>
    <div class="lgrid">${accs.map((it) => {
      const ok = owned(it.id), on = worn.includes(it.id), fit = fits(it.id);
      return `<button class="ltile ${on ? 'on' : ''} ${ok && fit ? '' : 'locked'}" ${ok && fit ? `data-s="equip-acc" data-id="${esc(it.id)}"` : `data-s="locked" data-msg="${esc(ok ? 'Non disponibile per il tuo avatar' : condText(it))}"`}>
        <img src="${accSrc(it)}" alt=""><b>${ok ? '' : '🔒 '}${esc(it.name)}</b><small>${!ok ? esc(condText(it)) : !fit ? 'Non va sul tuo avatar' : on ? 'Indossato' : 'Tocca per metterlo'}</small></button>`;
    }).join('')}</div>` : '';
  return `${bar(accs.length ? 'Accessori, reazioni e dorso' : 'Reazioni e dorso')}
    ${accHTML}
    <div class="label">📣 Le tue 4 reazioni vocali</div>
    <p class="hint">In partita online le trovi col tasto del megafono in basso a sinistra: partono su tutti i telefoni del tavolo. Ognuna può essere una di quelle di base o una frase registrata da te (massimo 5 secondi).</p>
    <div class="rxslots">${[0, 1, 2, 3].map((i) => `<div class="rxslot"><span class="n">${i + 1}</span><b>${rx[i] ? esc(rx[i].name) : '<span class="muted">Vuota</span>'}</b>
      ${rx[i] ? `<button class="btn small ghost" data-s="rx-play" data-i="${i}" aria-label="Ascolta">▶️</button>` : ''}<button class="btn small" data-s="rx-change" data-i="${i}">Cambia</button></div>`).join('')}</div>
    <div class="label">Dorso delle tue carte</div>
    <p class="hint">Gli altri lo vedono sulle tue carte coperte.</p>
    <div class="lgrid backs"><button class="ltile ${!m.back ? 'on' : ''}" data-s="equip-back" data-id=""><img src="icons/back.webp" alt=""><b>Classico</b><small>${!m.back ? 'In uso' : 'Tocca per usarlo'}</small></button>
      ${backs.map((it) => tile(it, m.back === it.id, 'equip-back', `<img src="${backSrc(it.id)}" alt="">`)).join('')}</div>`;
}
const rxUrl = (r) => `api/asset/${encodeURIComponent(r.id)}?v=${r.v || 1}`;

// scelta di una reazione per un posto: una di base oppure registrata adesso
const REC = { r: null, data: null, timer: null, slot: 0 };
function rxSheet(slot) {
  REC.slot = slot;
  const base = IT.items.filter((i) => i.kind === 'emote' && i.data?.asset && (!i.excl || owned(i.id)));
  const cur = A.me?.rx?.[slot];
  let recBox;
  if (REC.r) recBox = `<div class="clipbox rec"><span class="recdot"></span><b>Sto registrando… parla adesso</b><button class="btn" data-s="clip-stop">⏹ Ferma</button><small>Si ferma da sola dopo 5 secondi</small></div>`;
  else if (REC.data) recBox = `<div class="clipbox"><b>Ecco la tua frase</b><div class="row2"><button class="btn ghost" data-s="clip-play">▶️ Ascolta</button><button class="btn ghost" data-s="clip-rec">🎙️ Rifai</button></div>
    <input class="field" id="rxname" maxlength="24" placeholder="Nome sul tasto (es. Ciapa!)"><button class="btn" data-s="clip-save">Salva al posto ${slot + 1}</button></div>`;
  else recBox = `<button class="btn" data-s="clip-rec">🎙️ Registrane una tua</button>`;
  openSheet(`<h2>Reazione ${slot + 1}</h2>
    ${recBox}
    ${base.length ? `<div class="label">Oppure una di base</div><div class="rxpick">${base.map((it) => { const ok = owned(it.id); const on = cur && !cur.own && cur.id === it.id;
      return `<div class="rxslot"><b>${ok ? '' : '🔒 '}${esc(it.name)}</b><button class="btn small ghost" data-s="rx-play-base" data-id="${esc(it.id)}" aria-label="Ascolta">▶️</button>${on ? '<span class="muted">In uso</span>' : ok ? `<button class="btn small" data-s="rx-use" data-id="${esc(it.id)}">Usa</button>` : `<button class="btn small ghost" data-s="locked" data-msg="${esc(condText(it))}">Bloccata</button>`}</div>`; }).join('')}</div>` : ''}`);
}
async function clipRec() {
  REC.data = null;
  try { REC.r = await AU.startRecording({ max: 5 }); } catch (e) { X.toast(e.name === 'NotAllowedError' ? 'Serve il permesso del microfono' : e.message || 'Microfono non disponibile'); REC.r = null; return rxSheet(REC.slot); }
  rxSheet(REC.slot);
  REC.timer = setTimeout(clipStop, 5100);
}
async function clipStop() {
  clearTimeout(REC.timer);
  const r = REC.r; REC.r = null;
  if (!r) return;
  const out = await r.stop();
  if (out && out.dataUrl && out.seconds > 0.3) REC.data = out.dataUrl; else X.toast('Registrazione troppo corta');
  if (!$sheet.hidden) rxSheet(REC.slot);
}

// popup "Hai sbloccato…": appena succede (o alla prima apertura dopo)
function unlockPopup() {
  const ids = (IT.mine?.unseen || []).filter((id) => itemById(id));
  if (!ids.length || !$sheet.hidden) return;
  const verb = { acc: 'Aggiungilo al tuo avatar', back: 'Usa questo dorso', avatar: 'Usa questo avatar', emote: 'Mettila tra le tue' };
  openSheet(`<h2>🎉 Hai sbloccato ${ids.length === 1 ? 'un oggetto nuovo' : `${ids.length} oggetti nuovi`}!</h2>
    <div class="unls">${ids.map((id) => { const it = itemById(id); const img = it.kind === 'acc' ? accSrc(it) : it.kind === 'back' ? backSrc(id) : it.kind === 'avatar' ? X.avImg(id) : null;
      return `<div class="unl">${img ? `<img src="${img}" alt="">` : `<span class="em">${it.kind === 'emote' ? '📣' : '🎁'}</span>`}<div><b>${esc(it.name)}</b><small>${it.kind === 'emote' ? 'Nuova reazione vocale' : ''}</small></div>${verb[it.kind] ? `<button class="btn small" data-s="unl-use" data-id="${esc(id)}">${verb[it.kind]}</button>` : ''}</div>`; }).join('')}</div>`);
  rpc('unlockSeen').catch(() => {});
  if (IT.mine) IT.mine.unseen = [];
}

// Banner in alto, dentro il gioco (inviti a giocare, richieste di amicizia)
let bannerT = null;
function banner(html) {
  let el = document.getElementById('socbanner');
  if (!el) { el = document.createElement('div'); el.id = 'socbanner'; el.setAttribute('role', 'status'); document.body.append(el); }
  el.innerHTML = `${html}<button class="bx" data-s="banner-x" aria-label="Chiudi">×</button>`;
  el.hidden = false; el.classList.remove('in'); void el.offsetWidth; el.classList.add('in');
  clearTimeout(bannerT); bannerT = setTimeout(() => { el.hidden = true; }, 25000);
}
const hideBanner = () => { const el = document.getElementById('socbanner'); if (el) el.hidden = true; };
function inviteBanner(n) {
  const d = n.data;
  if (X.lobbyCode() === d.code) return;
  banner(`${avatar(d.from, 'soav')}<span><b>${esc(d.from.username)}</b> ti ha invitato a partecipare a una partita</span><button class="btn small" data-s="inv-ok" data-id="${n.id}">Partecipa</button>`);
}
// invito agli amici dalla sala d'attesa
export async function inviteSheet(code) {
  if (!requireLogin(() => inviteSheet(code))) return;
  let f;
  try { f = await rpc('friends'); } catch (e) { return X.toast(e.message); }
  const list = f.friends;
  const how = (u) => (u.presence === 'online' ? 'Online: lo vede subito' : u.presence === 'game' ? 'In partita: gli compare dentro il gioco' : u.push ? 'Offline: gli arriva la notifica sul telefono' : 'Offline: lo vedrà quando apre Bisca');
  openSheet(`<h2>Invita amici</h2><p class="muted">Amici di qualsiasi community. Chi è dentro Bisca vede subito l'invito con il tasto Partecipa, anche se sta giocando un'altra partita.</p>
    ${list.length ? `<div class="ulist">${list.map((u) => `<label class="urow ${u.presence === 'offline' && !u.push ? 'faint' : ''}"><input type="checkbox" data-inv="${u.id}" ${u.presence !== 'offline' ? 'checked' : ''}>${avatar(u)}<span class="un"><b>${esc(u.username)}</b><small>${dot(u.presence)} ${how(u)}</small></span></label>`).join('')}</div>
      <button class="btn" data-s="inv-send" data-code="${code}">Manda l'invito</button><p class="hint">L'invito vale 15 minuti.</p>` : '<p class="empty">Non hai ancora amici: aggiungili dal pannello in alto a destra nella home.</p>'}`);
}

// ------------------------------------------------------------ eventi
let searchT = null;
function onInput(e) {
  if ($sheet?.contains(e.target) && e.target.id === 'l-user' && V.loginMode === 'register') {
    const el = $sheet.querySelector('#e-user'); const pb = userProblem(e.target.value);
    // mentre si scrive "troppo corto" non serve: si dice solo un carattere sbagliato o un nome troppo lungo
    const show = pb && !/corto/.test(pb) ? pb : '';
    if (el) el.textContent = show; e.target.classList.toggle('bad', !!show);
    return;
  }
  if ($sheet?.contains(e.target) && e.target.id === 'l-pass') { const el = $sheet.querySelector('#e-pass'); if (el?.textContent) el.textContent = ''; e.target.classList.remove('bad'); return; }
  if (!$root.contains(e.target)) return;
  if (e.target.id === 'usearch') {
    V.data.uq = e.target.value;
    clearTimeout(searchT);
    searchT = setTimeout(async () => { try { V.data.found_u = V.data.uq.length >= 2 ? (await rpc('search', { q: V.data.uq })).list : null; } catch {} redrawKeep('#usearch'); }, 300);
  } else if (e.target.id === 'csearch') {
    V.data.cq = e.target.value;
    clearTimeout(searchT);
    searchT = setTimeout(async () => { try { V.data.found = (await rpc('cSearch', { q: V.data.cq })).list; } catch {} redrawKeep('#csearch'); }, 300);
  } else if (e.target.id === 'chatin') {
    e.target.style.height = 'auto'; e.target.style.height = Math.min(120, e.target.scrollHeight) + 'px';
    mentionSuggest(e.target);
  }
}
function redrawKeep(sel) {
  const el = $root.querySelector(sel); const pos = el?.selectionStart;
  draw();
  const n = $root.querySelector(sel); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch {} }
}

async function act(fn, ok) { try { const r = await fn(); if (ok) X.toast(ok); return r; } catch (e) { X.toast(e.message); return null; } }

async function onClick(e) {
  const el = e.target.closest('[data-s]');
  if (!el) { if (e.target === $sheet) closeSheet(); return; }
  if (el.tagName === 'LABEL' || (el.closest('label') && e.target.tagName === 'INPUT')) return;
  const d = el.dataset, v = top();
  switch (d.s) {
    case 'off': return X.toast('Account, amici e community sono nella versione online di Bisca');
    case 'me': if (!loggedIn()) return loginSheet(defaultMode()); V.stack = []; return show({ k: 'me' });
    case 'pw-forgot': return forgotSheet();
    case 'dm-open': return show({ k: 'dm', uid: d.uid });
    case 'dm-send': {
      const i = $root.querySelector('#chatin'); const text = i?.value.trim();
      if (!text) return;
      const v = top();
      i.value = '';
      try { const r = await rpc('dmSend', { uid: v.uid, text }); V.data.dm?.msgs.push(r.msg); draw(); } catch (e) { i.value = text; X.toast(e.message); }
      return;
    }
    case 'dm-block': { const v = top(); try { await rpc('dmBlock', { uid: v.uid, on: d.on === '1' }); load(v); } catch (e) { X.toast(e.message); } return; }
    case 'dm-report': {
      const why = prompt('Cosa vuoi segnalare all\'amministratore? (facoltativo)');
      if (why === null) return;
      try { await rpc('dmReport', { uid: top().uid, why }); X.toast('Segnalazione inviata all\'amministratore'); } catch (e) { X.toast(e.message); }
      return;
    }
    case 'pw-admin': return dmAdmin('Ciao, vorrei cambiare la password del mio account.');
    case 'pw-forgot-send': {
      const username = $sheet.querySelector('#f-user').value.trim(), contact = $sheet.querySelector('#f-contact').value.trim();
      const e = $sheet.querySelector('#e-gen');
      if (!username) { e.textContent = 'Scrivi il tuo username'; return; }
      if (contact.length < 3) { e.textContent = 'Scrivi come ti contattiamo'; return; }
      try { const r = await fetch('api/u', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ op: 'pwRequest', username, contact }) }).then((x) => x.json()); if (r.error) throw new Error(r.error); forgotSheet(true); }
      catch (er) { e.textContent = er.message; }
      return;
    }
    case 'close-sheet': return closeSheet();
    case 'panel': return openPanel();
    case 'back': return back();
    case 'tab': v.tab = d.v; draw(); return load(v);
    case 'sheet-close': return closeSheet();
    case 'lmode': { e?.preventDefault?.(); return keepAuthFields(() => loginSheet(d.v)); }
    case 'reg-av': { regAvatar = regAvatar === d.id ? null : d.id; const sc = $sheet.querySelector('.avstrip')?.scrollLeft || 0; keepAuthFields(() => loginSheet('register')); const st = $sheet.querySelector('.avstrip'); if (st) st.scrollLeft = sc; return; }
    case 'pw-eye': { const i = $sheet.querySelector('#l-pass'); if (i) { i.type = i.type === 'password' ? 'text' : 'password'; i.focus(); } return; }
    case 'do-login': return doAuth('login');
    case 'do-register': return doAuth('register');
    case 'profile': return openProfile(d.uid);
    case 'logout': {
      let endpoint = null;
      try { const reg = await navigator.serviceWorker?.getRegistration(); const sub = await reg?.pushManager?.getSubscription(); endpoint = sub?.endpoint || null; await sub?.unsubscribe(); } catch {}
      await act(() => rpc('logout', { endpoint }));
      store.del('bisca:pushOn'); logoutLocal(); close(); return X.toast('Sei uscito dall\'account');
    }
    case 'pick-av': return avatarSheet();
    case 'c-vrec': return vRec();
    case 'c-vsend': return vStop(true);
    case 'c-vcancel': return vStop(false);
    case 'c-play': { el.classList.add('playing'); AU.playUrl(`api/c/${CH.cid}/audio?id=${d.id}&token=${encodeURIComponent(A.token)}`).then((dur) => setTimeout(() => el.classList.remove('playing'), (dur || 1) * 1000)).catch(() => { el.classList.remove('playing'); X.toast('Non riesco a riprodurlo'); }); return; }
    case 'clip-rec': return clipRec();
    case 'clip-stop': return clipStop();
    case 'clip-play': return REC.data && AU.playUrl(REC.data).catch(() => X.toast('Non riesco a riprodurla'));
    case 'clip-save': { const name = document.getElementById('rxname')?.value || ''; const r = await act(() => rpc('setRx', { slot: REC.slot, data: REC.data, name })); if (r) { REC.data = null; setMe(r.me); X.onLook?.(); closeSheet(); X.toast('Reazione salvata'); draw(); } return; }
    case 'rx-change': REC.data = null; return rxSheet(Number(d.i));
    case 'rx-play': { const r = A.me?.rx?.[Number(d.i)]; return r && AU.playUrl(rxUrl(r)).catch(() => X.toast('Non riesco a riprodurla')); }
    case 'rx-play-base': { const it = itemById(d.id); return it && AU.playUrl(rxUrl(it)).catch(() => X.toast('Non riesco a riprodurla')); }
    case 'rx-use': { const r = await act(() => rpc('setRx', { slot: REC.slot, id: d.id })); if (r) { setMe(r.me); X.onLook?.(); closeSheet(); draw(); } return; }
    case 'locked': return X.toast(d.msg || 'Ancora bloccato');
    case 'look': return show({ k: 'look' });
    case 'equip-acc': {
      const cur = A.me?.acc || [];
      const next = cur.includes(d.id) ? cur.filter((x) => x !== d.id) : [...cur, d.id];
      const r = await act(() => rpc('equip', { acc: next }));
      if (r) { setMe(r.me); X.onLook?.(); draw(); }
      return;
    }
    case 'equip-back': { const r = await act(() => rpc('equip', { back: d.id || null })); if (r) { setMe(r.me); X.onLook?.(); draw(); } return; }
    case 'unl-use': {
      const it = itemById(d.id);
      let r = null;
      if (it?.kind === 'emote') { closeSheet(); show({ k: 'look' }); return; }
      if (it?.kind === 'acc') { const cur = A.me?.acc || []; r = await act(() => rpc('equip', { acc: [...cur.filter((x) => x !== it.id), it.id] })); }
      else if (it?.kind === 'back') r = await act(() => rpc('equip', { back: it.id }));
      else if (it?.kind === 'avatar') { r = await act(() => rpc('setAvatar', { avatar: it.id })); }
      if (r) { setMe(r.me); X.onLook?.(); }
      el.closest('.unl')?.classList.add('done'); el.replaceWith(Object.assign(document.createElement('b'), { textContent: 'Fatto ✓' }));
      return;
    }
    case 'set-av': { const r = await act(() => rpc('setAvatar', { avatar: d.id })); if (r) { setMe(r.me); closeSheet(); load(top()); } return; }
    case 'rename': return openSheet(`<h2>Cambia username</h2><p class="warnbox">Si può fare <b>una volta sola</b>. Poi per cambiarlo serve l'amministratore.</p><input id="rn" class="field" maxlength="20" value="${esc(A.me.username)}" autocapitalize="none"><p class="perr" role="alert"></p><button class="btn" data-s="rename-go" data-s-enter>Cambia</button>`);
    case 'rename-go': { try { const r = await rpc('rename', { username: $sheet.querySelector('#rn').value.trim() }); setMe(r.me); closeSheet(); load(top()); X.toast('Username cambiato'); } catch (err) { $sheet.querySelector('.perr').textContent = err.message; } return; }
    case 'pw': return openSheet(`<h2>Cambia password</h2><label class="label">Password attuale</label><input id="pw0" class="field" type="password" autocomplete="current-password"><label class="label">Nuova password</label><input id="pw1" class="field" type="password" autocomplete="new-password"><p class="perr" role="alert"></p><button class="btn" data-s="pw-go" data-s-enter>Salva</button><p class="hint">Gli altri telefoni collegati con il tuo account verranno scollegati.</p>`);
    case 'pw-go': { try { await rpc('password', { old: $sheet.querySelector('#pw0').value, password: $sheet.querySelector('#pw1').value }); closeSheet(); X.toast('Password cambiata'); } catch (err) { $sheet.querySelector('.perr').textContent = err.message; } return; }
    case 'notifset': return show({ k: 'notifset' });
    case 'quiet': V.data.quiet = JSON.parse(JSON.stringify(A.me?.quiet || defaultQuiet())); V.data.qCustom = ![2, 3, 4, 5].every((x) => sameRanges(V.data.quiet.days[x], V.data.quiet.days[1])); return show({ k: 'quiet' });
    case 'push-on': return enablePush();
    case 'push-on-pop': closeSheet(); return enablePush();
    case 'pmode': V.data.pmode = d.v; return draw();
    case 'pf-group': setTimeout(() => { (V.data.pfOpen ||= {})[d.g] = el.open; }, 0); return;
    case 'wrapped': return show({ k: 'wrapped' });
    case 'wrap-open': closeSheet(); openPanel(); return show({ k: 'wrapped', season: d.v });
    case 'wrap-other': { const t = top(); t.season = d.v; V.data.wrap = null; return load(t); }
    case 'wrap-share': return shareWrap();
    case 'pf-settings': $root.querySelector('#pfset')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); return;
    case 'lvl-info': return openSheet(`<h2>📶 Il livello</h2><p>È la tua forza nelle <b>partite online classificate</b> (almeno 3 giocatori con l'account). Si parte da 1000.</p>
      <ul class="plist2"><li>Ogni partita ti confronta con tutti gli altri al tavolo: guadagni per ognuno che hai davanti, perdi per ognuno che ti sta davanti.</li><li>Battere chi ha un livello più alto vale di più; perdere con chi è più basso costa di più.</li><li>Conta anche quanto resisti: uscire per ultimi vale più che uscire subito.</li><li>Nelle prime 10 partite si muove di più, poi si assesta.</li></ul>
      <p class="muted">Il single player non conta per il livello. La classifica del mese invece usa i <b>punti</b>, che ripartono da zero ogni mese.</p>`);
    case 'c-logo-del': await act(() => rpc('cLogo', { cid: v.cid, data: null }), 'Logo tolto'); return load(v);
    case 'rules': setTimeout(() => { V.data.rulesOpen = el.open; store.set('bisca:rulesSeen3', true); }, 0); return;
    case 'season': return show({ k: 'season', season: d.v });
    case 'palmares': return show({ k: 'palmares' });
    case 'push-test': return act(() => rpc('pushTest'), 'Notifica di prova inviata');
    case 'push-off': { try { const reg = await navigator.serviceWorker?.getRegistration(); const sub = await reg?.pushManager?.getSubscription(); if (sub) { const r = await rpc('pushUnsub', { endpoint: sub.endpoint }); await sub.unsubscribe(); setMe(r.me); } } catch {} store.del('bisca:pushOn'); draw(); return X.toast('Notifiche disattivate su questo telefono'); }
    // amici
    case 'fr-add': await act(() => rpc('friendAdd', { uid: d.uid }), 'Richiesta inviata'); return load(top());
    case 'fr-ok': e.stopPropagation(); hideBanner(); await act(() => rpc('friendAnswer', { uid: d.uid, ok: true }), 'Ora siete amici'); return load(top());
    case 'fr-no': e.stopPropagation(); await act(() => rpc('friendAnswer', { uid: d.uid, ok: false })); return load(top());
    case 'fr-del': await act(() => rpc('friendRemove', { uid: d.uid }), 'Tolto dagli amici'); return back();
    // inviti
    case 'banner-x': return hideBanner();
    case 'inv-ok': {
      e.stopPropagation(); hideBanner();
      const r = await act(() => rpc('inviteAnswer', { id: d.id, ok: true }));
      closeSheet();
      A.notifs = A.notifs.filter((x) => String(x.id) !== String(d.id)); badge();
      if (r?.code) { close(); X.joinCode(r.code); }
      return;
    }
    case 'inv-no': { e.stopPropagation(); hideBanner(); await act(() => rpc('inviteAnswer', { id: d.id, ok: false })); closeSheet(); A.notifs = A.notifs.filter((x) => String(x.id) !== String(d.id)); badge(); if (isOpen()) draw(); return; }
    case 'invite-one': { const code = X.lobbyCode(); if (!code) return; const r = await act(() => rpc('invite', { code, uids: [d.uid] })); if (r) X.toast(r.sent.length ? 'Invito mandato' : r.skipped[0] ? `${r.skipped[0].username} ${r.skipped[0].why}` : 'Invito non mandato'); return; }
    case 'inv-send': {
      const uids = [...$sheet.querySelectorAll('[data-inv]:checked')].map((x) => x.dataset.inv);
      if (!uids.length) return X.toast('Scegli almeno un amico');
      const r = await act(() => rpc('invite', { code: d.code, uids }));
      if (r) { closeSheet(); X.toast([r.sent.length ? `Invito mandato a ${r.sent.join(', ')}` : '', ...r.skipped.map((s) => `${s.username} ${s.why}`)].filter(Boolean).join(' · ')); }
      return;
    }
    case 'join': e.stopPropagation(); close(); return X.joinCode(d.code);
    // community
    case 'comm': {
      V.stack = V.stack.filter((x) => x.k !== 'comm');
      // con una menzione non letta si apre la chat proprio lì
      const men = !d.mid && A.notifs.filter((n) => n.type === 'mention' && n.data?.cid === d.cid).map((n) => n.data.mid).sort((a, b) => a - b)[0];
      return show({ k: 'comm', cid: d.cid, sub: d.sub || 'chat', mid: d.mid ? Number(d.mid) : men || null });
    }
    case 'csub': v.sub = d.v; v.mid = null; if (d.v === 'chat') openChatWs(v.cid); draw(); return load(v);
    case 'c-new': return openSheet(`<h2>Nuova community</h2><label class="label">Nome</label><input id="cn" class="field" maxlength="30" placeholder="es. Bar Sport"><label class="label">Descrizione</label><textarea id="cd" class="field" rows="3" maxlength="300" placeholder="Chi siete, quando giocate…"></textarea>
      <label class="swrow"><input type="checkbox" id="cp" checked> <span><b>Pubblica</b><small>Chiunque la trova e può entrare. Se la togli, si entra solo con un invito o dopo una richiesta.</small></span></label><p class="perr" role="alert"></p><button class="btn" data-s="c-create">Crea</button>`);
    case 'c-create': { try { const r = await rpc('cCreate', { name: $sheet.querySelector('#cn').value, descr: $sheet.querySelector('#cd').value, public: $sheet.querySelector('#cp').checked }); closeSheet(); show({ k: 'comm', cid: r.id, sub: 'chat' }); } catch (err) { $sheet.querySelector('.perr').textContent = err.message; } return; }
    case 'c-join': { const r = await act(() => rpc('cJoin', { cid: d.cid })); if (r?.requested) X.toast('Richiesta inviata agli amministratori'); return load(top()); }
    case 'cinv-ok': { e.stopPropagation(); const r = await act(() => rpc('cJoin', { cid: d.cid })); if (r?.joined) { X.toast('Sei entrato'); return show({ k: 'comm', cid: d.cid, sub: 'chat' }); } return; }
    case 'cinv-no': e.stopPropagation(); await act(() => rpc('cDecline', { cid: d.cid })); return load(top());
    case 'c-acc': await act(() => rpc('cAnswer', { cid: v.cid, uid: d.uid, ok: true }), 'Accettato'); return load(v);
    case 'c-rej': await act(() => rpc('cAnswer', { cid: v.cid, uid: d.uid, ok: false })); return load(v);
    case 'c-member': return memberSheet(d.uid);
    case 'c-role': await act(() => rpc('cRole', { cid: v.cid, uid: d.uid, role: d.role }), 'Ruolo cambiato'); closeSheet(); return load(v);
    case 'c-kick': await act(() => rpc('cKick', { cid: v.cid, uid: d.uid }), 'Tolto dalla community'); closeSheet(); return load(v);
    case 'c-invite': return openSheet(`<h2>Invita nella community</h2><input id="ci-q" class="field" placeholder="Username" autocapitalize="none"><div id="ci-res" class="ulist"></div><button class="btn" data-s="ci-search" data-s-enter>Cerca</button>`);
    case 'ci-search': { const r = await act(() => rpc('search', { q: $sheet.querySelector('#ci-q').value })); const box = $sheet.querySelector('#ci-res'); if (r && box) box.innerHTML = r.list.map((u) => `<div class="urow">${avatar(u)}<span class="un"><b>${esc(u.username)}</b></span><button class="btn small" data-s="ci-send" data-uid="${u.id}">Invita</button></div>`).join('') || '<p class="empty">Nessuno trovato.</p>'; return; }
    case 'ci-send': { const r = await act(() => rpc('cInvite', { cid: v.cid, uid: d.uid }), 'Invito mandato'); if (r) el.disabled = true; return; }
    case 'c-save': await act(() => rpc('cEdit', { cid: v.cid, name: $root.querySelector('#cname')?.value, descr: $root.querySelector('#cdescr')?.value, public: $root.querySelector('#cpublic')?.checked }), 'Salvato'); return load(v);
    case 'c-leave': return openSheet(`<h2>Uscire dalla community?</h2><p class="muted">Non vedrai più la chat. Se sei il proprietario, la community passa a un amministratore o al membro più vecchio.</p><button class="btn" data-s="c-leave-go">Esci</button>`);
    case 'c-leave-go': { const r = await act(() => rpc('cLeave', { cid: v.cid })); closeSheet(); if (r) { closeChatWs(); back(); } return; }
    case 'c-delete': return openSheet(`<h2>Eliminare la community?</h2><p class="muted">Chat, membri e chiamate spariscono per tutti. Non si può tornare indietro.</p><button class="btn danger" data-s="c-delete-go">Elimina</button>`);
    case 'c-delete-go': { const r = await act(() => rpc('cDelete', { cid: v.cid }), 'Community eliminata'); closeSheet(); if (r) { closeChatWs(); back(); } return; }
    case 'c-send': return sendChat();
    case 'c-more': { const first = CH.msgs[0]; if (first && CH.ws?.readyState === 1) CH.ws.send(JSON.stringify({ t: 'more', before: first.id })); return; }
    case 'c-del': if (CH.ws?.readyState === 1) CH.ws.send(JSON.stringify({ t: 'del', id: Number(d.id) })); return;
    case 'ment-pick': {
      const i = $root.querySelector('#chatin');
      const pos = i.selectionStart;
      const before = i.value.slice(0, pos).replace(/@([^@\n]{0,20})$/, `@${d.name} `);
      i.value = before + i.value.slice(pos); i.focus(); i.setSelectionRange(before.length, before.length);
      $root.querySelector('#mentlist').hidden = true;
      return;
    }
    case 'c-call': return openSheet(`<h2>Avvia una partita</h2><p class="muted">Creo una stanza e lo scrivo in chat con il tasto <b>Partecipa</b>. Da lì, se vuoi, avvisi tutta la community con una notifica.</p><button class="btn" data-s="c-call-go">Crea la stanza</button>`);
    case 'c-call-go': {
      closeSheet();
      const cid = v.cid;
      const code = await X.createRoom();
      if (!code) return;
      const r = await act(() => rpc('cLobby', { cid, code }));
      if (r) { X.toast('Partita avviata: è in chat. Tocca Partecipa per entrare nella stanza'); load(v); }
      return;
    }
    case 'c-notify': {
      const r = await act(() => rpc('cNotify', { cid: v.cid }));
      if (r) X.toast(r.sent ? `Avviso mandato a ${r.sent} ${r.sent === 1 ? 'membro' : 'membri'}` : 'Nella community non c\'è nessun altro da avvisare');
      return load(v);
    }
    // orari di silenzio
    case 'q-mode': readQuietInputs(); V.data.qCustom = d.v === '1'; if (!V.data.qCustom) { const q = V.data.quiet; for (const x of [2, 3, 4, 5]) q.days[x] = JSON.parse(JSON.stringify(q.days[1])); } return draw();
    case 'q-add': { readQuietInputs(); const targets = d.k === 'wk' ? [1, 2, 3, 4, 5] : [Number(d.k)]; for (const x of targets) V.data.quiet.days[x].push(['08:00', '12:00']); return draw(); }
    case 'q-del': { readQuietInputs(); const targets = d.k === 'wk' ? [1, 2, 3, 4, 5] : [Number(d.k)]; for (const x of targets) V.data.quiet.days[x].splice(Number(d.i), 1); return draw(); }
    case 'q-exadd': { readQuietInputs(); const dt = $root.querySelector('#q-exd').value; if (!dt) return X.toast('Scegli una data'); V.data.quiet.ex = V.data.quiet.ex.filter((x) => x.d !== dt); V.data.quiet.ex.push({ d: dt, m: $root.querySelector('#q-exm').value }); V.data.quiet.ex.sort((a, b) => a.d.localeCompare(b.d)); return draw(); }
    case 'q-exdel': readQuietInputs(); V.data.quiet.ex.splice(Number(d.i), 1); return draw();
    case 'q-save': { readQuietInputs(); const r = await act(() => rpc('settings', { quiet: V.data.quiet, tz: TZ }), 'Orari salvati'); if (r) { setMe(r.me); back(); } return; }
  }
}
// Immagini dal telefono (fotocamera o galleria): ritaglio quadrato al centro, 256×256, JPEG leggero.
export async function imageToDataUrl(file, size = 256) {
  const url = URL.createObjectURL(file);
  try {
    const im = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const side = Math.min(im.naturalWidth, im.naturalHeight);
    const c = document.createElement('canvas'); c.width = c.height = size;
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, size, size);
    g.drawImage(im, (im.naturalWidth - side) / 2, (im.naturalHeight - side) / 2, side, side, 0, 0, size, size);
    return c.toDataURL('image/jpeg', 0.84);
  } finally { URL.revokeObjectURL(url); }
}
document.addEventListener('change', async (e) => {
  const kind = e.target.dataset?.file;
  if (!kind || !e.target.files?.[0]) return;
  let data;
  try { data = await imageToDataUrl(e.target.files[0]); } catch { return X.toast('Non riesco a leggere questa immagine'); }
  if (kind === 'reg') { regPhoto = data; regAvatar = '__photo'; keepAuthFields(() => loginSheet('register')); return; }
  if (kind === 'me') { const r = await act(() => rpc('setPhoto', { data }), 'Foto aggiornata'); if (r) { setMe(r.me); closeSheet(); load(top()); } return; }
  if (kind === 'logo') { const v = top(); const r = await act(() => rpc('cLogo', { cid: v.cid, data }), 'Logo aggiornato'); if (r) load(v); }
});
// interruttori delle notifiche: si salvano subito
document.addEventListener('change', async (e) => {
  if (['n-invites', 'n-calls', 'n-mentions'].includes(e.target.id)) {
    const notif = { invites: document.getElementById('n-invites').checked, calls: document.getElementById('n-calls').checked, mentions: document.getElementById('n-mentions').checked };
    try { const r = await rpc('settings', { notif }); setMe(r.me); } catch (err) { X.toast(err.message); }
  }
});

function memberSheet(uid) {
  const d = V.data.comm;
  const u = d.members.find((m) => m.id === uid);
  if (!u) return;
  const mine = d.c.role;
  const acts = [];
  if (uid !== A.me.id) {
    if (mine === 'owner') {
      acts.push(u.role === 'admin' ? `<button class="btn ghost" data-s="c-role" data-uid="${uid}" data-role="member">Togli amministratore</button>` : `<button class="btn ghost" data-s="c-role" data-uid="${uid}" data-role="admin">Fai amministratore</button>`);
      acts.push(`<button class="btn ghost" data-s="c-role" data-uid="${uid}" data-role="owner">Passa la proprietà</button>`);
    }
    if (mine === 'owner' || (mine === 'admin' && u.role === 'member')) acts.push(`<button class="btn ghost danger" data-s="c-kick" data-uid="${uid}">Togli dalla community</button>`);
  }
  openSheet(`<div class="invhead">${avatar(u, 'pav')}<p><b>${esc(u.username)}</b><br><span class="muted">${roleName[u.role]} · ${u.rating} punti</span></p></div>
    <button class="btn" data-s="profile" data-uid="${uid}">Vedi il profilo</button>${acts.join('')}`);
  $sheet.querySelector('[data-s="profile"]').addEventListener('click', closeSheet, { once: true });
}

async function enablePush() {
  const sup = pushSupport();
  if (sup !== 'ok') return draw();
  try {
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') { X.toast('Permesso negato: le notifiche restano spente'); return draw(); }
    const reg = await navigator.serviceWorker.ready;
    const { key } = await rpc('pushKey');
    const raw = atob(key.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (key.length % 4)) % 4));
    const appKey = Uint8Array.from(raw, (c) => c.charCodeAt(0));
    let sub = await reg.pushManager.getSubscription();
    if (sub && sub.options?.applicationServerKey && new Uint8Array(sub.options.applicationServerKey).toString() !== appKey.toString()) { await sub.unsubscribe(); sub = null; }
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: appKey });
    const r = await rpc('pushSub', { sub: sub.toJSON() });
    store.set('bisca:pushOn', r.me.id);
    setMe(r.me);
    X.toast('Notifiche attive su questo telefono');
  } catch (e) { X.toast('Non è stato possibile attivarle: ' + (e.message || 'errore')); }
  draw();
}

// ------------------------------------------------------------ single player: statistiche
export function reportSP(r) { if (A.token) rpc('spResult', r).catch(() => {}); }
export async function addFriend(uid) { if (!requireLogin()) return; await act(() => rpc('friendAdd', { uid }), 'Richiesta di amicizia inviata'); }
export const myId = () => A.me?.id || null;
export async function setPhoto(data) { try { const r = await rpc('setPhoto', { data }); setMe(r.me); X.toast('Foto aggiornata'); return r.me.avatar; } catch (e) { X.toast(e.message); return null; } }
export async function setAvatar(id) { if (!A.token) return; try { const r = await rpc('setAvatar', { avatar: id }); setMe(r.me); } catch {} }
