// Segnavite: tiene il conto delle vite delle partite giocate dal vivo, con le carte vere.
// Chi crea il tavolo segna i nomi; gli altri entrano con il codice, guardano, reclamano il proprio
// giocatore e, se l'owner glielo permette, segnano anche loro.

const $app = document.getElementById('app');
const $sheet = document.getElementById('sheet');
const $toast = document.getElementById('toast');

const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DEVICE = store.get('bisca:device') || (() => { const d = Math.random().toString(36).slice(2) + Date.now().toString(36); store.set('bisca:device', d); return d; })();
const settings = store.get('bisca-sp:settings') || {};
const myName = () => (settings.name || '').trim() || 'Ospite';

let toastT;
function toast(msg) { $toast.textContent = msg; $toast.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => ($toast.hidden = true), 2800); }

// tavoli aperti da questo telefono
const KEEP_DAYS = 7;
const tables = {
  // i tavoli non aperti da più di 7 giorni spariscono dall'elenco (sul server si cancellano da soli)
  all() {
    const a = store.get('bisca:vite') || {};
    const old = Object.keys(a).filter((c) => Date.now() - a[c].at > KEEP_DAYS * 864e5 || (a[c].closedUntil && Date.now() > a[c].closedUntil));
    if (old.length) { old.forEach((c) => delete a[c]); store.set('bisca:vite', a); }
    return a;
  },
  put(code, extra = {}) { const a = this.all(); a[code] = { ...(a[code] || {}), at: Date.now(), ...extra }; store.set('bisca:vite', a); },
  del(code) { const a = this.all(); delete a[code]; store.set('bisca:vite', a); },
};

let AVATARS = [];
const avById = (id) => AVATARS.find((a) => a.id === id);
const avImg = (id) => `api/avatars/img/${encodeURIComponent(id)}/circle?v=${avById(id)?.v || 0}`;
fetch('api/avatars', { cache: 'no-store' }).then((r) => r.json()).then((a) => { AVATARS = Array.isArray(a) ? a.filter((x) => !x.hidden) : []; render(); }).catch(() => {});

const ui = { screen: 'list', sheet: null, data: null };
const draft = { n: 4, names: [], avatars: [] };
let T = null; // tavolo aperto: { code, ws, v, retry }

// ---------------------------------------------------------------- collegamento

function openTable(code) {
  closeTable();
  T = { code, ws: null, v: null, retry: 0 };
  tables.put(code);
  ui.screen = 'table';
  setUrl(code);
  render();
  connect();
}
function closeTable() {
  if (T?.ws) { T.ws.onclose = null; try { T.ws.close(); } catch {} }
  if (T) { clearTimeout(T.again); clearInterval(T.ping); }
  T = null;
}
function connect() {
  if (!T) return;
  clearTimeout(T.again);
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const base = location.pathname.replace(/[^/]*$/, '');
  const q = `device=${encodeURIComponent(DEVICE)}&name=${encodeURIComponent(myName())}`;
  const ws = new WebSocket(`${proto}://${location.host}${base}api/lives/${T.code}/ws?${q}`);
  T.ws = ws;
  ws.onopen = () => { T.retry = 0; clearInterval(T.ping); T.ping = setInterval(() => ws.readyState === 1 && ws.send('{"t":"ping"}'), 25000); render(); };
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.t === 'state') {
      if (m.v.closedUntil) m.v.closedUntil -= (m.now || Date.now()) - Date.now(); // orologio del telefono
      const was = T.v?.closedUntil;
      T.v = m.v;
      tables.put(T.code, { closedUntil: m.v.closedUntil || null });
      if (m.v.closedUntil && !was) { closeSheet(); toast('Il tavolo è stato chiuso'); }
      render(); if (ui.sheet) drawSheet();
    }
    else if (m.t === 'error') toast(m.msg);
    else if (m.t === 'gone') { const c = T.code; tables.del(c); closeTable(); closeSheet(); ui.screen = 'list'; setUrl(null); toast('Il tavolo non c\'è più'); render(); }
  };
  ws.onclose = async () => {
    if (!T || T.ws !== ws) return;
    clearInterval(T.ping);
    try {
      const r = await fetch(`api/lives/${T.code}/info`, { cache: 'no-store' });
      if (r.status === 404) { tables.del(T.code); closeTable(); closeSheet(); ui.screen = 'list'; setUrl(null); toast('Il tavolo non c\'è più'); return render(); }
    } catch {}
    render();
    T.retry++;
    T.again = setTimeout(connect, Math.min(1000 * 2 ** T.retry, 8000));
  };
}
const send = (m) => { if (T?.ws?.readyState === 1) T.ws.send(JSON.stringify(m)); else toast('Riconnessione…'); };
// il telefono si blocca tra un turno e l'altro: appena torna visibile si ricollega
document.addEventListener('visibilitychange', () => { if (!document.hidden && T && T.ws?.readyState !== 1) { T.retry = 0; connect(); } });

function setUrl(code) {
  try { const u = new URL(location.href); if (code) u.searchParams.set('t', code); else u.searchParams.delete('t'); history.replaceState(null, '', u); } catch {}
}

// ---------------------------------------------------------------- disegno

const BACK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';
const SHARE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V4M8 8l4-4 4 4"/><path d="M6 11v8h12v-8"/></svg>';
const topbar = (title, sub, act = 'back') => `<div class="topbar"><button class="iconbtn" data-act="${act}" aria-label="Indietro">${BACK}</button><div class="t"><b>${title}</b>${sub ? `<span>${sub}</span>` : ''}</div></div>`;
const initials = (n) => esc((n || '?').trim().slice(0, 1).toUpperCase());
const avTag = (id, name, cls = 'vav') => (id && avById(id) ? `<img class="${cls}" src="${avImg(id)}" alt="">` : `<span class="${cls}">${initials(name)}</span>`);

function render() {
  if (ui.screen === 'create') return renderCreate();
  if (ui.screen === 'table') return renderTable();
  renderList();
}

function renderList() {
  const all = Object.entries(tables.all()).sort((a, b) => b[1].at - a[1].at);
  const list = all.filter(([, x]) => !x.closedUntil).slice(0, 6);
  const shut = all.filter(([, x]) => x.closedUntil);
  if (shut.length) { clearTimeout(ui.tick); ui.tick = setTimeout(() => ui.screen === 'list' && render(), 30000); }
  $app.innerHTML = `
    ${topbar('Segnavite', 'Le vite delle partite dal vivo', 'home')}
    <p class="muted">Giocate con le carte vere? Uno segna le vite qui, gli altri le vedono dal loro telefono con il codice.</p>
    <div class="modes">
      <button class="mode" data-act="new"><span class="mt"><b>Nuovo tavolo</b><span>Scrivi i nomi: partono tutti da 3 vite</span></span></button>
      <button class="mode alt" data-act="join"><span class="mt"><b>Entra con un codice</b><span>Guarda le vite e reclama il tuo giocatore</span></span></button>
    </div>
    ${list.length ? `<div class="label">I tuoi tavoli</div><div class="recent">${list.map(([c]) => `<div class="vrec"><button data-act="open" data-code="${esc(c)}"><b class="code">${esc(c)}</b><span class="muted">Apri ›</span></button><button class="iconbtn" data-act="forget" data-code="${esc(c)}" aria-label="Togli ${esc(c)} dall'elenco">✕</button></div>`).join('')}</div><p class="hint">Un tavolo esce da solo dall'elenco dopo ${KEEP_DAYS} giorni che non lo apri, e si cancella dopo ${KEEP_DAYS} giorni senza modifiche.</p>` : ''}
    ${shut.length ? `<div class="label">Chiusi di recente</div><div class="recent">${shut.map(([c, x]) => `<button data-act="open" data-code="${esc(c)}"><span><b class="code">${esc(c)}</b> <span class="muted">· ancora ${minsLeft(x.closedUntil)}</span></span><span class="muted">Guarda ›</span></button>`).join('')}</div>` : ''}`;
}

const minsLeft = (until) => { const m = Math.max(1, Math.ceil((until - Date.now()) / 60000)); return m === 1 ? '1 minuto' : m + ' minuti'; };

function renderCreate() {
  const n = draft.n;
  $app.innerHTML = `
    ${topbar('Nuovo tavolo', 'Nomi dei giocatori')}
    <div class="label">Quanti giocate?</div>
    <div class="stepper"><button data-act="n" data-d="-1" ${n <= 2 ? 'disabled' : ''} aria-label="Uno in meno">−</button><div class="val"><b>${n}</b><span>giocatori</span></div><button data-act="n" data-d="1" ${n >= 20 ? 'disabled' : ''} aria-label="Uno in più">+</button></div>
    <div class="label">Nomi <span class="muted">· l'avatar è facoltativo</span></div>
    <div class="vnames">${Array.from({ length: n }, (_, i) => `<div class="vname">
      <button class="vav" data-act="pick-draft" data-i="${i}" aria-label="Avatar">${draft.avatars[i] && avById(draft.avatars[i]) ? `<img src="${avImg(draft.avatars[i])}" alt="">` : '+'}</button>
      <input class="field" data-name="${i}" maxlength="22" placeholder="Giocatore ${i + 1}" value="${esc(draft.names[i] || '')}" autocomplete="off">
    </div>`).join('')}</div>
    <p class="perr" id="cerr" role="alert"></p>
    <button class="btn" data-act="create">Crea il tavolo</button>`;
}

function livesCell(p, edit) {
  const out = p.lives === 0;
  const num = p.bonus && p.lives === 1 ? '<span class="num bonus">BONUS</span>' : out ? '<span class="num zero">FUORI</span>' : `<span class="num">${p.lives}</span>`;
  if (!edit) return `<div class="vlives">${num}</div>`;
  return `<div class="vlives"><button data-act="d" data-pid="${p.id}" data-d="-1" ${out ? 'disabled' : ''} aria-label="Togli una vita a ${esc(p.name)}">−</button>${num}<button data-act="d" data-pid="${p.id}" data-d="1" aria-label="Aggiungi una vita a ${esc(p.name)}">+</button></div>`;
}

function renderTable() {
  const v = T?.v;
  if (!v) { $app.innerHTML = `${topbar('Tavolo ' + esc(T?.code || ''), 'Collegamento…')}`; return; }
  const closed = !!v.closedUntil;
  const edit = v.role !== 'viewer' && !closed;
  const owner = v.role === 'owner' && !closed;
  if (closed) { clearTimeout(ui.tick); ui.tick = setTimeout(() => ui.screen === 'table' && render(), 30000); }
  const mineClaimed = v.players.some((p) => p.mine);
  const conn = T.ws?.readyState === 1 ? '' : ' · riconnessione…';
  const roleTxt = closed ? 'Tavolo chiuso' : owner ? 'Hai creato tu il tavolo' : v.role === 'admin' ? 'Puoi segnare le vite' : 'Stai guardando';
  $app.innerHTML = `
    ${topbar('Segnavite', roleTxt + conn)}
    <div class="vcode"><span class="muted">Codice</span><b>${esc(v.code)}</b>${closed ? '' : '<button class="btn small" data-act="share">Invita</button>'}</div>
    ${closed ? `<div class="vclosed"><b>Tavolo chiuso</b><span>Resta visibile ancora ${minsLeft(v.closedUntil)}, poi si cancella. Fai uno screenshot se ti servono le vite.</span>${v.role === 'owner' ? '<button class="btn small" data-act="reopen">Riapri il tavolo</button>' : ''}</div>` : ''}
    ${v.bonusUsed ? '<p class="hint">La vita bonus è già stata presa.</p>' : '<p class="hint">La vita bonus è ancora libera.</p>'}
    <div class="vrows">${v.players.map((p) => {
      const who = p.mine ? '<small class="me">Sei tu</small>' : p.claimedBy ? `<small>${esc(v.people.find((x) => x.pub === p.claimedBy)?.name || 'reclamato')}</small>` : '';
      const acts = [];
      if (edit && !v.bonusUsed) acts.push(`<button class="vb" data-act="bonus" data-pid="${p.id}">BONUS</button>`);
      if (!closed && !p.claimedBy && !mineClaimed) acts.push(`<button class="vclaim" data-act="claim" data-pid="${p.id}">Sono io</button>`);
      if (!closed && p.mine) acts.push(`<button data-act="claim-av" data-pid="${p.id}">Cambia avatar</button><button data-act="unclaim">Non sono io</button>`);
      return `<div class="vrow ${p.lives === 0 ? 'out' : ''}">
        ${avTag(p.avatar, p.name)}
        <button class="vn" ${owner ? `data-act="edit" data-pid="${p.id}"` : 'tabindex="-1"'}><b>${esc(p.name)}</b>${who}</button>
        ${livesCell(p, edit)}
        ${acts.length ? `<div class="vacts">${acts.join('')}</div>` : ''}
      </div>`;
    }).join('')}</div>
    ${owner ? '<p class="hint">Tocca un nome per cambiarlo, cambiare l\'avatar o toglierlo.</p>' : ''}
    ${edit ? `<div class="vbar"><button class="btn ghost" data-act="undo" ${v.canUndo ? '' : 'disabled'}>Annulla l'ultima</button><button class="btn ghost" data-act="reset">Nuova partita</button></div>` : ''}
    ${owner ? '<div class="vbar"><button class="btn ghost" data-act="add">Aggiungi un giocatore</button><button class="btn ghost" data-act="close-table">Chiudi il tavolo</button></div>' : ''}
    <div class="vsect"><div class="label">Collegati al tavolo</div></div>
    <div class="vpeople">${v.people.map((x) => `<div class="vperson"><i class="${x.online ? 'on' : ''}"></i><span class="pn"><b>${esc(x.name)}${x.pub === v.me ? ' (tu)' : ''}</b>${x.plays ? `<small>è ${esc(x.plays)}</small>` : ''}</span>
      ${x.role === 'owner' ? '<span class="vtag owner">Crea</span>' : owner ? `<button class="btn small ${x.role === 'admin' ? '' : 'ghost'}" data-act="admin" data-pub="${x.pub}" data-on="${x.role === 'admin' ? 0 : 1}">${x.role === 'admin' ? 'Segna ✓' : 'Fai segnare'}</button>` : x.role === 'admin' ? '<span class="vtag admin">Segna</span>' : ''}
    </div>`).join('')}</div>
    ${owner ? '<p class="hint">Chi ha "Segna" può cambiare le vite anche se tu esci. Solo tu puoi cambiare nomi e avatar.</p>' : ''}`;
}

// ---------------------------------------------------------------- finestre

function openSheet(kind, data = null) { ui.sheet = kind; ui.data = data; drawSheet(); }
function closeSheet() { ui.sheet = null; $sheet.hidden = true; $sheet.innerHTML = ''; }
function avListHTML(cur, act) {
  if (!AVATARS.length) return '<p class="hint">Nessun personaggio disponibile.</p>';
  return `<div class="avlist">${AVATARS.map((a) => `<button class="avrow ${cur === a.id ? 'on' : ''}" data-act="${act}" data-id="${esc(a.id)}"><img src="${avImg(a.id)}" alt="" loading="lazy"><span><b>${esc(a.name || a.id)}</b></span></button>`).join('')}</div>`;
}
function drawSheet() {
  const k = ui.sheet, d = ui.data || {}, v = T?.v;
  const P = (id) => v?.players.find((p) => p.id === id);
  let html = '';
  if (k === 'join') html = `<h2>Entra con un codice</h2><input class="field code" id="jcode" maxlength="8" placeholder="CODICE" autocomplete="off" autocapitalize="characters"><p class="perr" id="jerr" role="alert"></p><button class="btn" data-act="join-go">Entra</button>`;
  else if (k === 'avdraft') html = `<h2>Avatar di ${esc(draft.names[d.i] || 'Giocatore ' + (d.i + 1))}</h2>${avListHTML(draft.avatars[d.i], 'av-draft')}<button class="btn ghost" data-act="av-draft" data-id="">Senza avatar</button>`;
  else if (k === 'claimav') html = `<h2>Il tuo avatar</h2><p class="muted">Il nome resta <b>${esc(P(d.pid)?.name)}</b>, così chi segna non si confonde.</p>${avListHTML(settings.avatarPick, 'av-claim')}<button class="btn ghost" data-act="av-claim" data-id="">Senza avatar</button>`;
  else if (k === 'bonus') {
    const p = P(d.pid);
    const others = v.players.filter((x) => x.id !== d.pid && x.lives <= 1);
    const rest = v.players.filter((x) => x.id !== d.pid && x.lives > 1);
    html = `<h2>Vita bonus a ${esc(p?.name)}</h2>
      <p class="muted">Qualcun altro ha preso la bonus in questo turno?</p>
      <details class="vchecks" ${others.length ? 'open' : ''}><summary>Scegli chi altro</summary>
        ${[...others, ...rest].map((x) => `<label><input type="checkbox" data-bpid="${x.id}"> ${esc(x.name)} <span class="muted">· ${x.lives === 0 ? 'fuori' : x.lives === 1 ? '1 vita' : x.lives + ' vite'}</span></label>`).join('') || '<p class="hint">Nessun altro.</p>'}
      </details>
      <p class="hint">Dopo la conferma il tasto BONUS sparisce per tutti. Se sbagli c'è "Annulla l'ultima".</p>
      <button class="btn" data-act="bonus-go">Conferma</button>`;
  } else if (k === 'edit') {
    const p = P(d.pid);
    if (!p) return closeSheet();
    html = `<h2>${esc(p.name)}</h2>
      <div class="label">Nome</div><input class="field" id="ename" maxlength="22" value="${esc(p.name)}"><button class="btn" data-act="rename" data-pid="${p.id}">Salva il nome</button>
      ${p.claimedBy ? `<p class="hint">${esc(v.people.find((x) => x.pub === p.claimedBy)?.name || 'Qualcuno')} si è preso questo giocatore e ha scelto l'avatar da solo.</p><button class="btn ghost" data-act="unclaim-owner" data-pid="${p.id}">Sgancia il suo telefono</button>`
        : `<div class="label">Avatar</div>${avListHTML(p.ownAvatar, 'av-owner')}<button class="btn ghost" data-act="av-owner" data-id="">Senza avatar</button>`}
      <button class="btn ghost" data-act="remove" data-pid="${p.id}">Togli dal tavolo</button>`;
  } else if (k === 'add') html = `<h2>Aggiungi un giocatore</h2><input class="field" id="aname" maxlength="22" placeholder="Nome"><button class="btn" data-act="add-go">Aggiungi</button>`;
  else if (k === 'closeT') html = `<h2>Chiudere il tavolo?</h2><p class="muted">Il tavolo <b>${esc(v?.code)}</b> e tutte le vite spariscono per tutti, e non si può tornare indietro.</p><button class="btn" style="background:var(--red);color:#111" data-act="close-go">Sì, chiudi il tavolo</button>`;
  else if (k === 'reset') html = `<h2>Nuova partita?</h2><p class="muted">Tutti tornano a 3 vite e la vita bonus torna libera. Nomi e telefoni restano.</p><button class="btn" data-act="reset-go">Sì, ricomincia</button>`;
  $sheet.innerHTML = `<div class="box" role="dialog" aria-modal="true">${html}<button class="btn ghost" data-act="close">Chiudi</button></div>`;
  $sheet.hidden = false;
  if (k === 'join') setTimeout(() => document.getElementById('jcode')?.focus(), 50);
}

// ---------------------------------------------------------------- azioni

async function createTable() {
  const players = Array.from({ length: draft.n }, (_, i) => ({ name: (draft.names[i] || '').trim(), avatar: draft.avatars[i] || null }));
  const err = document.getElementById('cerr');
  if (players.some((p) => !p.name)) { err.textContent = 'Scrivi tutti i nomi'; return; }
  try {
    const res = await fetch('api/lives', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ device: DEVICE, name: myName(), players }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Errore');
    draft.names = []; draft.avatars = [];
    openTable(data.code);
  } catch (e) { err.textContent = e.message || 'Errore di rete'; }
}

async function joinGo() {
  const code = (document.getElementById('jcode')?.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const err = document.getElementById('jerr');
  if (code.length < 4) { err.textContent = 'Codice troppo corto'; return; }
  try {
    const r = await fetch(`api/lives/${code}/info`, { cache: 'no-store' });
    if (!r.ok) { err.textContent = 'Nessun tavolo con questo codice'; return; }
    closeSheet(); openTable(code);
  } catch { err.textContent = 'Errore di rete'; }
}

async function share() {
  const url = `${location.origin}${location.pathname}?t=${T.v.code}`;
  try { if (navigator.share) { await navigator.share({ title: 'Bisca · Segnavite', text: `Le vite della partita: codice ${T.v.code}`, url }); return; } } catch (e) { if (e.name === 'AbortError') return; }
  try { await navigator.clipboard.writeText(url); toast('Link copiato'); } catch { toast(`Codice: ${T.v.code}`); }
}

$app.addEventListener('input', (e) => { const i = e.target.dataset?.name; if (i != null) draft.names[Number(i)] = e.target.value; });

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) { if (e.target === $sheet) closeSheet(); return; }
  const d = el.dataset;
  switch (d.act) {
    case 'home': location.href = './'; return;
    case 'back': closeTable(); closeSheet(); ui.screen = 'list'; setUrl(null); return render();
    case 'close': return closeSheet();
    case 'new': ui.screen = 'create'; return render();
    case 'join': return openSheet('join');
    case 'join-go': return joinGo();
    case 'open': return openTable(d.code);
    case 'forget': tables.del(d.code); return render();
    case 'close-table': return openSheet('closeT');
    case 'close-go': closeSheet(); return send({ t: 'close' });
    case 'reopen': send({ t: 'reopen' }); return toast('Tavolo riaperto');
    case 'n': draft.n = Math.max(2, Math.min(20, draft.n + Number(d.d))); return render();
    case 'pick-draft': return openSheet('avdraft', { i: Number(d.i) });
    case 'av-draft': draft.avatars[ui.data.i] = d.id || null; closeSheet(); return render();
    case 'create': return createTable();
    case 'share': return share();
    case 'd': return send({ t: 'delta', pid: d.pid, d: Number(d.d) });
    case 'bonus': return openSheet('bonus', { pid: d.pid });
    case 'bonus-go': {
      const pids = [ui.data.pid, ...[...$sheet.querySelectorAll('[data-bpid]:checked')].map((x) => x.dataset.bpid)];
      closeSheet(); return send({ t: 'bonus', pids });
    }
    case 'undo': return send({ t: 'undo' });
    case 'reset': return openSheet('reset');
    case 'reset-go': closeSheet(); return send({ t: 'reset' });
    case 'claim':
      if (settings.avatarPick) { send({ t: 'claim', pid: d.pid, avatar: settings.avatarPick }); return toast('Ora sei tu: puoi cambiare avatar quando vuoi'); }
      return openSheet('claimav', { pid: d.pid });
    case 'claim-av': return openSheet('claimav', { pid: d.pid });
    case 'av-claim': send({ t: 'claim', pid: ui.data.pid, avatar: d.id || null }); return closeSheet();
    case 'unclaim': return send({ t: 'unclaim' });
    case 'unclaim-owner': send({ t: 'unclaim', pid: d.pid }); return closeSheet();
    case 'edit': return openSheet('edit', { pid: d.pid });
    case 'rename': { const n = document.getElementById('ename')?.value || ''; send({ t: 'rename', pid: d.pid, name: n }); return closeSheet(); }
    case 'av-owner': send({ t: 'setAvatar', pid: ui.data.pid, avatar: d.id || null }); return closeSheet();
    case 'remove': if (!el.dataset.sure) { el.dataset.sure = 1; el.textContent = 'Tocca ancora per confermare'; return; } send({ t: 'removePlayer', pid: d.pid }); return closeSheet();
    case 'add': return openSheet('add');
    case 'add-go': { const n = document.getElementById('aname')?.value || ''; send({ t: 'addPlayer', name: n }); return closeSheet(); }
    case 'admin': return send({ t: 'admin', pub: d.pub, on: d.on === '1' });
  }
});
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  if (ui.sheet === 'join') joinGo();
  else if (ui.sheet === 'add') document.querySelector('[data-act="add-go"]')?.click();
});

// avvio: ?t=CODICE apre subito il tavolo
const start = new URLSearchParams(location.search).get('t');
if (start) openTable(start.toUpperCase().replace(/[^A-Z0-9]/g, '')); else render();
