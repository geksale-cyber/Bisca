# Bisca

Web app per giocare a Bisca con le carte trevigiane dal telefono: single player contro la CPU e multiplayer con gli amici, da 3 a 13 al tavolo.
Gira tutta su Cloudflare (piano gratuito): pagine statiche, una stanza di gioco per partita (Durable Object con WebSocket) e un archivio delle partite da cui la CPU impara.

## Pubblicarla online

Serve un account Cloudflare (gratuito). Due strade:

**Dal browser, con GitHub** (nessuna installazione)
1. Crea un repository su GitHub e carica tutto il contenuto di questa cartella (non la cartella stessa: `wrangler.toml` deve stare nella pagina principale del repository).
2. Su Cloudflare: Workers & Pages → Crea → Importa un repository → scegli il repository. Cloudflare trova `wrangler.toml` e pubblica.
3. Alla fine ti dà l'indirizzo, tipo `https://bisca.<tuo-nome>.workers.dev`.

**Dal computer**
```
npm install
npx wrangler login
npx wrangler deploy
```

## Installarla sul telefono

- iPhone (Safari): apri il link → Condividi → "Aggiungi alla schermata Home".
- Android (Chrome): apri il link → menu ⋮ → "Installa app".

## Come si usa

- **Home**: la tavolata animata (tocca un personaggio, quello nascosto o l'asso di denari), poi "Gioca con i tuoi amici", "Single player", "Spettatore" e "Come scaricare l'app". "Allenati e impara la Bisca" apre le lezioni di Fabrizio Corona su tre livelli (Principiante, Intermedio, Avanzato). La Lezione 0 è una mano guidata; le altre sono situazioni preparate: decidi, vedi a parole quanto è probabile che vada bene, leggi il ragionamento, poi Riprova, "E se…?" (una variante), "Guarda come va" (si gioca il resto della mano) o Avanti. I contatori (prese in palio, chiamate, differenza, carte più forti ancora in giro) ci sono solo nelle lezioni. L'ultima è una partita vera con il maestro che fa domande e, se vuoi, dà un consiglio a parole. Un livello si apre quando completi il precedente; i progressi restano sul telefono.
- **Single player**: nome e avatar, quanti avversari (2-12), difficoltà e vista. La CPU aspetta 5 secondi prima di ogni mossa (4 a difficile).
- **Crea / Accedi a una stanza**: nome e avatar si scelgono subito, prima di entrare. Un personaggio già preso nella stanza non si può scegliere. Dal link d'invito si sceglie se giocare o guardare.
- **Vista del tavolo**: "Tavolo" (ovale blu, giocatori attorno in senso antiorario, carte giocate accanto a chi le ha tirate) o "Classica" (fila dei giocatori in alto). Si cambia dal menu durante la partita o prima del single player.
- **Giocare**: si tocca la carta e parte subito (l'asso di denari chiede alta o bassa). Nel menu c'è l'opzione "Chiedi conferma prima di giocare".
- **Pulsanti rapidi** (accanto alla mano):
  - **Presa**: mai l'asso di denari. Se ti manca solo questa presa, la tua carta più alta. Se te ne servono altre, la più bassa che prende di sicuro; se nessuna è sicura, la più alta come consiglio (segnato con "?"). Disattivato se sei già a posto (bordo rosso) o se nessuna carta prende.
  - **Parcheggio**: quando apri tu, la carta più bassa. Altrimenti solo carte che restano sotto la migliore sul tavolo: tiene da parte le carte che servono per le prese mancanti (una in più se le chiamate superano le mani) e parcheggia la più scarsa; se sei a posto butta la più alta che resta sotto. L'asso basso solo come ultima scelta. Disattivato se nessuna carta resta sotto.
- **Tempo per giocare (multiplayer)**: chi è online ha 1 minuto per mossa (il conto alla rovescia compare negli ultimi 15 secondi). Chi va offline ha 30 secondi per rientrare; poi gioca la CPU al suo posto, e da lì in avanti ogni sua mossa parte dopo 7 secondi finché non rientra. Le CPU aggiunte dall'host giocano dopo 6 secondi.
- **Spettatori**: dalla home "Spettatore" mostra le partite in corso e le stanze in attesa. Chi guarda (anche chi è stato eliminato) vede solo le carte giocate: le mani non partono proprio dal server. Può chiedere a un giocatore di vedere le sue carte: se dice sì le vede fino alla fine della partita (tranne nel turno da 1 carta); se dice no può chiedere a un altro. I giocatori vedono l'occhio con il numero di spettatori.
- **Fine partita**: "Inizia una nuova partita, torna in lobby" oppure "torna al menù principale".
- **Chat** (solo multiplayer) con @tag, **espulsione** dal turno successivo, **cambio host** se l'host resta offline più di un minuto.

## Pannello admin

`https://<il-tuo-indirizzo>/admin.html` con la chiave `STATS_KEY` di `wrangler.toml`.
- **Utenti**: gli account con punti, partite multiplayer e single player, iscrizione e ultimo accesso. Puoi impostare una nuova password, cambiare lo username (anche dopo che l'utente ha usato il suo unico cambio) e bloccare un account.
- **Partite**: le partite finite giocate con gli account, con piazzamenti, abbandoni e punti di ranking (multiplayer) o il risultato (single player).
- **Visite**: telefoni, partite e grafici degli ultimi 30 giorni. I nomi qui sono quelli della fase di test e non sono collegati agli account.
- **Backup**: scarica un file JSON con tutto (archivio, avatar con le immagini, account, amici, partite, community, classifica, dorsi e reazioni vocali). Le password sono solo in forma cifrata. Ogni lunedì notte se ne fa uno da solo (Cron Trigger in `wrangler.toml`, salvato nel Durable Object `Vault`): si tengono gli ultimi 6, scaricabili dal tasto Backup.
- **Avatar**: aggiungi (PNG, WebP o JPG già scontornati, anche tanti insieme, oppure direttamente uno zip; con un `index.json` vengono letti nomi e pose), rinomina, posa (serve alla scena della home), frase della nuvoletta, visibile/nascosto, ordine, sostituisci immagine, elimina. Gli avatar stanno nell'archivio sul server, non nei file dell'app. Chi aveva un avatar nascosto o eliminato ne sceglie un altro.
- **Blocco** di ogni avatar: per tutti, oppure si sblocca con N vittorie online o N punti in classifica (somma di tutte le stagioni).
- **Accessori** (tavola degli accessori): per ogni accessorio e ogni avatar lo trascini, lo ingrandisci o rimpicciolisci (pizzico, rotella o cursore), lo ruoti (due dita, Maiusc + rotella o cursore) e lo specchi; si salva da solo. "Non va su questo" lo esclude per quell'avatar. Si parte da una posizione proposta in automatico. A lato l'anteprima com'è al tavolo. Gli accessori si cambiano da qui: nuovo accessorio da un'immagine scontornata (PNG, WebP, SVG), cambio immagine (le posizioni restano), nome, blocco, nascondi, elimina. Un interruttore li accende per i giocatori solo quando hai finito; un accessorio compare solo sugli avatar dove è posizionato. La corona va da sola al Re della Bisca del mese.
- **Reazioni e dorsi**: reazioni vocali di base (audio MP3/M4A/WAV caricati, anche tanti insieme, o registrati dal pannello; tagliati a 5 secondi; nome, ordine, blocco) e dorsi delle carte (immagini o zip, adattati a 240×504). Si possono nascondere, eliminare e mettere a sblocco con vittorie online o punti in classifica.
- La prima volta l'elenco è vuoto: carica la cartella "avatar-iniziali" (i 40 personaggi con il loro index.json).

## Ultima mano

Nei turni da 2 carte in su l'ultima mano si gioca come le altre: ognuno ha una carta sola e la tira quando tocca a lui. Se non la tira entro 2 secondi scende da sola, tanto è obbligata (se è l'asso di denari, poi si sceglie alta o bassa come sempre). Poi la solita pausa per vedere chi ha preso e il riepilogo del turno.

## Versione 4.0

- **Profilo nuovo**: testata con avatar (matita per cambiarlo), livello, posizione e punti del mese; Online e Single player uno sotto l'altro (vittorie, podi nei tavoli da 6 o più, piazzamento medio; nel single player anche le vittorie per difficoltà); impostazioni in fondo in due gruppi richiudibili (Personalizzazione, Account). Nel profilo degli altri: **💬 Scrivi** e il **testa a testa** (partite online insieme, chi è arrivato davanti).
- **Livello** (`public/lib/rating.js`): media dei confronti con tutti gli avversari × peso del tavolo √((N−1)/3) (4 giocatori = 1, 13 = 2), con il margine di resistenza; K 40 nelle prime 10 partite, poi 24. Al primo avvio si ricalcola su tutte le partite classificate (i punti mensili non cambiano).
- **Pronto ovunque**: in sala d'attesa ogni giocatore vero mette Pronto; chi ha creato la stanza avvia solo quando ci sono tutti (gli arriva una vibrazione). A fine partita: Partecipa alla prossima / Non giocare la prossima / Torna alla sala d'attesa / Esci. La riga "Manca il Pronto di: …" la vedono tutti, anche tra un turno e l'altro. Chi arriva a partita iniziata la guarda e gli si chiede se vuole giocare la prossima.
- **Asso di denari** nel turno da 1 carta: si decide da solo (chiamata 0 = basso, 1 = alto).
- **Gioco rapido** (single player, nel menu della partita, solo per quella partita): la CPU gioca in 0,5 s e chiama in 1 s.
- **Stati Online / In partita**: "In partita" solo mentre si gioca davvero; il telefono manda un battito ogni 25 s e dopo 90 s di silenzio si è offline.
- **Audio su iPhone**: le reazioni suonano con il lettore audio normale (anche col silenzioso) e su iPhone si registra col registratore nativo (mp4). Nell'admin, **🔊 Prova audio** usa lo stesso sistema.
- **Chat privata 1:1** (scheda Messaggi nel pannello social): storico, non letti, notifiche, blocca e segnala; solo i due la leggono. **Password dimenticata** dalla schermata di accesso (username + contatto, arriva all'admin); da collegati "Richiedi cambio password" apre la chat con l'admin.
- **@tutti** nella chat della partita (notifica a chi è fuori dall'app).
- **Doppi account**: l'ultimo username resta scritto; avviso se ci si registra su un telefono dove c'è già stato un account; nell'admin "forse collegato a…" (codice casuale del browser, solo indizio), **Unisci** (partite e punti rimessi a posto: sfida del giorno una volta, al massimo 3 single player al giorno, partita comune una volta) ed **Elimina**.
- **Admin**: scheda **Numeri** (attivi al giorno, in 7 e 30 giorni, ritorno dopo 7 e 30 giorni, partite al giorno), scheda **Errori** (arrivano da soli dai telefoni), richieste di password in Utenti.
- **Riepilogo della stagione** da condividere come immagine (dal profilo; nei primi 10 giorni del mese compare da solo).

## Versione 3.1

- **Chiamate sopra le carte**: quando tocca a te chiamare, i numeri stanno sopra la mano (si vedono senza scorrere); finite le chiamate torna tutto come prima.
- **Reazioni vocali dentro la chat**: in alto nella chat ci sono due schede, "💬 Chat" e "📣 Reazioni" (le tue 4 reazioni, "Registra al volo e manda", audio acceso/spento). Niente più tasto col megafono sul tavolo.
- **Chiudere la partita**: dal menu, "Chiudi la partita (votano tutti)". Arriva un popup a tutti; si chiude con il sì di almeno il 75% dei giocatori veri (le CPU non votano; chi è fuori da più di 2 turni, o eliminato e uscito, conta come CPU). Con un solo giocatore vero si chiude subito. Si torna in sala d'attesa e la partita non conta. La richiesta resta aperta un minuto.
- **Spettatore**: sul tasto della home c'è il contatore live delle partite in corso.
- **Classifica**: "Sei 5° nella stagione di novembre 2026"; sotto, "Vedi le altre stagioni" apre l'albo d'oro (podio di ogni stagione passata, toccandola si apre la classifica completa). Il regolamento parte sempre chiuso.
- **Sfida del giorno: 3 tentativi**, ognuno con carte diverse (uguali per tutti allo stesso tentativo): il primo superato vale 2 punti. Un tentativo è usato appena inizi; uscire a metà lo fa contare come perso. Finiti i tentativi (o superata) si rigioca per allenarsi con carte sempre nuove, senza punti.
- **Admin, cancellare partite**: in Utenti, aprendo un account, "Cancella le partite di un giorno" (solo online, solo single player o tutte): spariscono dalle sue statistiche, dai suoi punti della stagione e dal suo livello; gli altri giocatori non cambiano.
- **Admin, Disponibilità**: una tabella con tutti gli avatar, accessori, dorsi e reazioni: blocco (per tutti, vittorie, punti), visibile o nascosto, quanti account ce l'hanno.
- **Admin, regali**: in Utenti, aprendo un account, sezione Oggetti: regali qualsiasi oggetto a sblocco anche senza vittorie o punti, e lo togli. Un oggetto nascosto regalato diventa esclusivo: lo ha solo chi lo riceve (gli altri lo vedono addosso a lui). La corona resta solo al Re della Bisca del mese.

## Versione 3.0

- **Classifica a stagioni** (`public/lib/season.js`): una stagione per mese, ora italiana. Partita online: +1 per ogni giocatore con l'account battuto, −0,5 per ognuno che ti batte, al massimo −3 a partita; il totale del mese non va sotto zero. Single player: contano le prime 3 partite vinte del giorno, medio ×0,25 e difficile ×0,5 (facile no). Sfida del giorno: +2 se superata. Il primo del mese prima diventa **Re della Bisca** per tutto il mese dopo, con il cerchio d'oro attorno all'avatar. Le partite online delle versioni precedenti sono state ricalcolate.
- **Sfida del giorno** (`public/lib/daily.js`): uguale per tutti, nasce dalla data (Sopravvivi, Cecchino, Ultimo in piedi, Partenza in salita contro CPU a difficile). Serve l'account; dalla 3.1 ci sono 3 tentativi con carte diverse. Calendario del mese; i giorni passati non si giocano.
- **Accessori sull'avatar** (`public/lib/look.js`): si mettono dal profilo, li vedono tutti; posizioni decise dall'admin sulla tavola degli accessori, avatar per avatar.
- **Avatar, accessori, dorsi e reazioni a sblocco**: l'admin decide quali sono per tutti e quali si sbloccano con le vittorie online o i punti in classifica; quando se ne sblocca uno compare il popup per usarlo.
- **Dorsi delle carte**: si scelgono dal profilo o dal menu della partita; gli altri li vedono sulle tue carte coperte.
- **Reazioni vocali** (`public/lib/audio.js`): in partita online, tasto col megafono in basso a sinistra. Si apre un pannellino con le tue 4 reazioni e il tasto "Registra al volo" (massimo 5 secondi); partono su tutti i telefoni del tavolo con la nuvoletta di chi le ha mandate. Le 4 si scelgono dal profilo ("Reazioni vocali e dorso delle carte"): una di quelle di base messe dall'admin o una frase registrata da sé. Chi non sceglie ha le prime 4 di base. Una ogni 3,5 secondi; l'audio si spegne dal pannellino. Messaggi vocali anche nella chat delle community (fino a 20 secondi).
- **Tocca a te**: dopo 5 secondi fuori dall'app arriva la notifica (con vibrazione dove il telefono la permette); in partita, dopo 5 secondi senza toccare nulla, il telefono vibra (Android) e compare "È IL TUO TURNO".
- **Pausa**: chi ha creato la stanza la mette dal menu; gli altri la chiedono e devono accettare tutti. Massimo 10 minuti; alla ripresa arriva una notifica e si preme tutti "Pronto" (al massimo un minuto di attesa). Il tempo del turno riparte da dove si era fermato.
- Avatar e oggetti restano in cache sul telefono (service worker).

## Account, ranking e community (Versione 2)

- **Account**: username (da 3 a 20 caratteri: lettere anche accentate, numeri, spazi, punto, trattino, trattino basso, apostrofo; deve iniziare con una lettera o un numero; maiuscole e minuscole contano uguale; spazi doppi e spazi ai bordi tolti da soli) e password (almeno 4 caratteri, spazi ai bordi tolti), niente email. La finestra parte da "Sono nuovo" (da "Ho già un account" se sul telefono c'è già stato un account); ogni problema si legge in rosso sotto il campo sbagliato mentre si scrive; l'avatar è facoltativo (se non si sceglie se ne assegna uno a caso). Si resta collegati finché non si fa logout. Lo username si cambia da soli una volta, poi solo dall'admin. L'avatar si cambia quando si vuole e non identifica nessuno: due persone possono avere lo stesso.
- **Multiplayer** solo con account: in stanza il nome è lo username. Lo stesso account che rientra (anche da un altro telefono) ritrova il suo posto. Il single player si gioca anche senza account; con l'account la partita finita va nelle statistiche, mai nel ranking.
- **Ranking**: si parte da 1000. È un Elo a coppie (`public/lib/rating.js`): ogni giocatore è confrontato con ogni altro sull'ordine di eliminazione; chi esce nello stesso turno pareggia; il margine (turni e vite di distanza) pesa fino a +50%. Battere chi ha più punti vale di più, perdere con chi ne ha meno costa di più. I primi 10 incontri muovono di più (K 20 per ogni avversario, poi 12). Il ranking (livello) resta accanto ai punti della stagione. Conta solo una partita finita con almeno 3 giocatori con l'account e almeno 3 turni; le CPU non contano. Chi abbandona (sostituito dalla CPU fino alla fine) conta come eliminato nel turno in cui se n'è andato. Ogni partita si registra una volta sola; le partite ripetute tra le stesse persone nelle 24 ore pesano un quarto in meno ciascuna.
- **Social** (tasto in alto a destra nella home, con il totale delle novità): schede Amici (richieste e inviti a giocare in cima, contatore dedicato), Community (menzioni @, chiamate aperte, richieste e inviti per ogni community, contatore dedicato) e Classifica (con il regolamento spiegato e il podio). Il riquadro per attivare le notifiche è in cima ad Amici, Community e dentro ogni community finché non sono attive su quel telefono.
- **Foto e loghi**: l'avatar può essere una foto scattata o presa dalla galleria (ritagliata e rimpicciolita sul telefono); proprietario e amministratori possono mettere un logo alla community.
- **Statistiche del profilo**, separate tra online e single player: vittorie, podi (solo nei tavoli da 6 o più), piazzamento medio come "top X%" (per ogni partita la posizione a metà del proprio posto diviso per i giocatori al tavolo: arrivare primo su 4 vale 12,5%, ultimo 87,5%; poi la media), chiamate esatte in percentuale, vite bonus da chiamata (3, 4 o 5 centrate) e vite bonus a zero contate a parte, turni giocati di media, vittorie di fila (adesso e record), record di punti in classifica, e per il single player le vittorie per difficoltà. I dettagli si contano dalle partite giocate dalla versione 2.6 in poi.
- **Notifiche**: al primo ingresso nel pannello social un popup propone di attivarle; poi la campanella 🔔 (accanto alla ricerca amici, accanto a "Le tue community" e nel riquadro di ogni community) apre le impostazioni. Sul telefono arrivano tre tipi: inviti a giocare degli amici, partite avviate nelle community, menzioni. Inviti e partite rispettano gli orari di silenzio, le menzioni no. Gli inviti arrivano dentro l'app a chi è online o sta giocando (anche in single player), e sul telefono a chi è offline con le notifiche attive.
- **Amici**: ricerca per username (o toccando il nome di un giocatore in partita: "Aggiungi agli amici"), richieste da accettare, stato online / in partita / offline in tempo reale, inviti diretti nella stanza (solo dentro l'app, niente push). A fine partita "Rivincita con gli stessi giocatori" riporta tutti in sala d'attesa con la proposta.
- **Community**: chiunque ne crea una (nome unico, descrizione, pubblica o privata). Ruoli: proprietario, amministratori, membri. Le private si raggiungono con un invito o una richiesta accettata. Ogni community ha la sua chat in tempo reale (un Durable Object per community: nessun limite di membri), con menzioni @username collegate all'account e tendina dei membri. Anti-spam: un messaggio ogni 0,7 secondi e al massimo 20 al minuto, al massimo 5 menzioni per messaggio e una notifica al minuto per la stessa coppia.
- **Avvia una partita** (dentro la community): crea una stanza e scrive in chat un messaggio con lo stato della stanza e il tasto Partecipa. Chi l'ha avviata ha anche "Avvisa la community", che manda la notifica agli altri membri: una volta per partita e al massimo ogni 30 minuti. Una sola partita aperta per community; il messaggio mostra quando la partita è iniziata o la stanza è chiusa.
- **Inviti diretti** dalla sala d'attesa ("Invita amici"): solo agli amici online, di qualsiasi community. Arrivano dentro il gioco come banner in alto con il tasto Partecipa e restano tra gli Inviti a giocare nella scheda Amici. Le notifiche push restano solo per menzioni e partite della community. Il riquadro per attivarle è dentro ogni community, sopra la chat; la campanella in alto a destra nel riquadro della community apre notifiche e orari di silenzio.
- **Notifiche push** (`src/push.js`, Web Push senza servizi esterni; le chiavi le genera il server la prima volta): solo chiamate e menzioni, ognuna attivabile a parte. Su iPhone funzionano solo con Bisca installata nella schermata Home (iOS 16.4 o successivo). Le chiamate rispettano gli **orari di silenzio** (`public/lib/quiet.js`: più fasce al giorno, feriali e weekend o giorno per giorno, festività italiane con Pasqua e Pasquetta, eccezioni su date precise, fuso orario dell'utente), le menzioni no. Le chiamate silenziate non arrivano dopo: restano tra le notifiche in app.
- **Vite bonus**: chi chiama 3, 4 o 5 e prende esattamente quel numero guadagna una vita, senza tetto. È separata dalla vita bonus del primo che arriva a zero.

## La CPU

- Vede solo quello che vedrebbe un giocatore. Per chiamare e per giocare immagina centinaia di distribuzioni delle carte coerenti con le chiamate fatte e sceglie la mossa che più spesso le fa centrare la chiamata.
- Ogni CPU ha un carattere (più prudente o più spavalda) che la situazione sposta.
- Impara dalle partite: ogni chiamata e giocata delle persone viene salvata nell'archivio, con un profilo per ogni nome.
- Livelli: facile (sbaglia apposta ogni tanto), medio, difficile.
- Dalla 2.7: chi deve fare una presa sola non prende per forza subito. Confronta "prendo adesso e poi le altre carte devono perdere" con "parcheggio adesso e prendo dopo" (è il caso della lezione 7 del tutorial). Lo spavaldo apre con la carta più forte solo quando le chiamate superano le carte; se sono di meno non regala scarichi. A difficile la chiamata è quasi sempre la migliore trovata e il carattere pesa meno della metà di prima.
- Torneo CPU nuova contro CPU vecchia a difficile (200 partite): chiamate centrate +1,5/+3 punti percentuali; a medio pari.

## Provarla sul computer

```
npm install
npm run dev                         # http://localhost:8787
npm test                            # regole e prove sulla CPU
npx wrangler dev --var CPU_DELAY_MS:60 --var PROXY_DELAY_MS:1500   # in un altro terminale
node test/e2e-extra.mjs             # timer, subentro, spettatori (vedi intestazione del file)
npm run e2e                         # partita multiplayer completa via WebSocket
node test/e2e-v2.mjs                # account, amici, community, chat, ranking, admin
npm run bench                       # torneo CPU contro CPU
```

## File

- `public/lib/engine.js` — tutte le regole (le usano sia l'app sia il server)
- `public/lib/ai.js` — la CPU
- `public/app.js`, `public/style.css`, `public/index.html` — l'app
- `public/carte/` — le 40 carte (dalle tue foto)
- `public/lib/quick.js` — i tasti rapidi Presa e Parcheggio
- `public/lib/tutorial.js` — le lezioni: carte preparate, scenari con varianti, mosse delle CPU e frasi del maestro (le probabilità vengono da `evaluateOptions` in `ai.js` e sono mostrate solo a parole)
- `public/admin.html` — pannello admin (statistiche e avatar)
- `public/icons/` — icone dell'app, titolo della home e dorso delle carte
- `src/worker.js` — server: stanze, CPU lato server, archivio partite e profili, instradamento
- `src/hub.js` — account, sessioni, amici, presenza, notifiche, statistiche, ranking, community (Durable Object `Hub`)
- `src/community.js` — chat di ogni community (Durable Object `Community`)
- `src/push.js` — notifiche push
- `public/social.js` — nell'app: accesso, profilo, amici, community, classifica, notifiche, orari di silenzio
- `tools/build-artifact.mjs` — prepara la versione single player per la pagina su Claude
- `wrangler.toml` — configurazione Cloudflare

## Segnavite (partite dal vivo)

Dalla home, "Segnavite" apre `vite.html`: chi crea il tavolo scrive i nomi (avatar facoltativo), tutti partono da 3 vite e si segnano con − e +. Il tasto BONUS si usa una volta sola: chiede se qualcun altro ha preso la bonus nello stesso turno e poi sparisce per tutti. "Annulla l'ultima" torna indietro di un passo, "Nuova partita" rimette tutti a 3.
Gli altri entrano con il codice (o il link), vedono le vite in diretta e possono reclamare il proprio giocatore con "Sono io": il nome resta quello scritto dal creatore, l'avatar lo sceglie chi reclama. Il creatore può dare a chiunque il permesso di segnare ("Fai segnare"): da lì in poi anche quel telefono cambia le vite, anche se il creatore esce. Solo il creatore cambia nomi e avatar (quelli dei giocatori non reclamati), aggiunge e toglie giocatori.
Il tavolo vive sul server (Durable Object `LifeTable`, `public/lib/lives.js` per le regole): bloccare il telefono non perde niente, e si cancella da solo dopo 7 giorni senza modifiche, oppure con "Chiudi il tavolo" (solo il creatore, con un popup di conferma): da chiuso resta visibile per 5 minuti senza modifiche ("Chiusi di recente"), il creatore può riaprirlo, poi si cancella. Nell'elenco "I tuoi tavoli" si può togliere un tavolo con la ✕; quelli non aperti da 7 giorni spariscono da soli.
