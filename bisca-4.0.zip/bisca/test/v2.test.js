import test from 'node:test';
import assert from 'node:assert/strict';
import * as RT from '../public/lib/rating.js';
import { isQuiet, italianHolidays, easter, cleanQuiet } from '../public/lib/quiet.js';

test('Elo: battere chi è più forte vale di più, perdere con chi è più debole costa di più', () => {
  const a = RT.rate([{ uid: 'a', rating: 1000, games: 20, place: 1, surv: 10 }, { uid: 'b', rating: 1200, games: 20, place: 2, surv: 8 }, { uid: 'c', rating: 1000, games: 20, place: 3, surv: 5 }]);
  const b = RT.rate([{ uid: 'a', rating: 1000, games: 20, place: 1, surv: 10 }, { uid: 'b', rating: 800, games: 20, place: 2, surv: 8 }, { uid: 'c', rating: 1000, games: 20, place: 3, surv: 5 }]);
  assert.ok(a.a > b.a, 'vincere contro un 1200 vale più che contro un 800');
  const c = RT.rate([{ uid: 'x', rating: 1200, games: 20, place: 3, surv: 3 }, { uid: 'y', rating: 900, games: 20, place: 1, surv: 9 }, { uid: 'z', rating: 900, games: 20, place: 2, surv: 6 }]);
  assert.ok(c.x < -10, 'il forte che perde con i deboli perde tanto');
  const sum = Object.values(a).reduce((p, q) => p + q, 0);
  assert.ok(Math.abs(sum) < 0.5, 'con lo stesso K i punti si conservano');
});

test('Elo: pareggio, partite ripetute, nuovi account', () => {
  const t = RT.rate([{ uid: 'a', rating: 1000, games: 20, place: 1, surv: 5 }, { uid: 'b', rating: 1000, games: 20, place: 1, surv: 5 }, { uid: 'c', rating: 1000, games: 20, place: 3, surv: 2 }]);
  assert.equal(t.a, t.b);
  const full = RT.rate([{ uid: 'a', rating: 1000, games: 20, place: 1, surv: 5 }, { uid: 'b', rating: 1000, games: 20, place: 2, surv: 2 }, { uid: 'c', rating: 1000, games: 20, place: 3, surv: 1 }]);
  const rep = RT.rate([{ uid: 'a', rating: 1000, games: 20, place: 1, surv: 5 }, { uid: 'b', rating: 1000, games: 20, place: 2, surv: 2 }, { uid: 'c', rating: 1000, games: 20, place: 3, surv: 1 }], { repeat: RT.repeatFactor(2) });
  assert.ok(rep.a < full.a && rep.a > 0, 'le partite ripetute tra le stesse persone pesano meno');
  assert.equal(RT.kFactor(3), 40); assert.equal(RT.kFactor(30), 24);
  const t4 = RT.rate([1, 2, 3, 4].map((p) => ({ uid: 'p' + p, rating: 1000, games: 20, place: p, surv: 5 - p })));
  const t13 = RT.rate(Array.from({ length: 13 }, (_, i) => ({ uid: 'p' + (i + 1), rating: 1000, games: 20, place: i + 1, surv: 13 - i })));
  assert.ok(t13.p1 > t4.p1 && t13.p1 < 2.2 * t4.p1, 'un tavolo da 13 vale circa il doppio di uno da 4, non quattro volte');
});

test('ordine finale: chi abbandona conta come eliminato in quel momento', () => {
  const s = { roundNo: 20, winners: ['p1'], players: [{ id: 'p1', lives: 2 }, { id: 'p2', outRound: 18, eliminated: true }, { id: 'p3', outRound: 12, eliminated: true }, { id: 'c', cpu: { level: 'medio' }, outRound: 15 }] };
  const o = RT.finalOrder(s, {});
  assert.deepEqual(o.map((x) => x.id), ['p1', 'p2', 'c', 'p3']);
  const o2 = RT.finalOrder(s, { p1: 10 });
  assert.equal(o2[o2.length - 1].id, 'p1');
  assert.equal(o2.find((x) => x.id === 'p1').won, false);
});

test('festività italiane e Pasqua', () => {
  assert.deepEqual(easter(2026), { month: 4, day: 5 });
  const h = italianHolidays(2026);
  assert.ok(h.has('04-06') && h.has('12-08') && h.has('06-02'));
});

test('orari di silenzio: fasce, giorni, festività, eccezioni, fuso', () => {
  const cfg = cleanQuiet({ on: true, days: { 1: [['08:00', '12:00'], ['14:00', '18:00']], 0: [['00:00', '23:59']] }, holiday: 'sunday', ex: [{ d: '2026-11-10', m: 'free' }] });
  const at = (iso) => new Date(iso);
  assert.equal(isQuiet(cfg, at('2026-11-09T09:30:00+01:00')), true, 'lunedì mattina');
  assert.equal(isQuiet(cfg, at('2026-11-09T13:00:00+01:00')), false, 'lunedì pausa pranzo');
  assert.equal(isQuiet(cfg, at('2026-11-09T15:00:00+01:00')), true, 'lunedì pomeriggio');
  assert.equal(isQuiet(cfg, at('2026-11-07T15:00:00+01:00')), false, 'sabato libero');
  assert.equal(isQuiet(cfg, at('2026-12-08T15:00:00+01:00')), true, '8 dicembre come domenica');
  assert.equal(isQuiet({ ...cfg, on: false }, at('2026-11-09T09:30:00+01:00')), false, 'programmazione spenta');
  assert.equal(isQuiet(cfg, at('2026-11-09T08:30:00Z')), true, 'fuso: 08:30 UTC = 09:30 a Roma');
  const night = cleanQuiet({ on: true, days: { 2: [['22:00', '07:00']] } });
  assert.equal(isQuiet(night, at('2026-11-10T23:00:00+01:00')), true, 'fascia a cavallo della mezzanotte');
  assert.equal(cleanQuiet({ days: { 1: [['25:00', '12:00']] } }).days[1].length, 0, 'orari non validi scartati');
});
