// Test end-to-end della Versione 2: account, amici, presenza, inviti, community, chat, menzioni,
// chiamate "Chi gioca a Bisca?", partita classificata con ranking, rivincita, admin.
//   npx wrangler dev --var CPU_DELAY_MS:60
//   node test/e2e-v2.mjs [http://127.0.0.1:8787]
import assert from 'node:assert/strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const WSBASE = BASE.replace(/^http/, 'ws');
const KEY = 'Uy9XLF7sRgMf';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let checks = 0;
const ok = (c, m) => { assert.ok(c, m); checks++; console.log('  ✓', m); };
const RUN = Date.now().toString(36).slice(-5);

async function post(path, body) {
  const res = await fetch(BASE + '/api/' + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: res.status, data: await res.json() };
}
const u = (op, b = {}) => post('u', { op, ...b }).then((r) => r.data);

class Sock {
  constructor(url) { this.msgs = []; this.waiters = []; this.url = url; }
  open() {
    return new Promise((res, rej) => {
      this.ws = new WebSocket(this.url);
      this.ws.onmessage = (ev) => { const m = JSON.parse(ev.data); this.msgs.push(m); this.waiters = this.waiters.filter((w) => !w()); };
      this.ws.onopen = () => res(this);
      this.ws.onerror = rej;
    });
  }
  until(pred, ms = 8000) {
    const hit = () => this.msgs.find(pred);
    if (hit()) return Promise.resolve(hit());
    return new Promise((res, rej) => {
      const t = setTimeout(() => rej(new Error('timeout ' + this.url)), ms);
      this.waiters.push(() => { const h = hit(); if (h) { clearTimeout(t); res(h); return true; } return false; });
    });
  }
  send(m) { this.ws.send(JSON.stringify(m)); }
  close() { try { this.ws.close(); } catch {} }
}

// ---------------------------------------------------------------- account
console.log('account');
const bad = await u('register', { username: 'a@b', password: 'segreto1' });
ok(/Username/.test(bad.error), 'username non valido rifiutato');
ok(/Username/.test((await u('register', { username: '-ab', password: 'segreto1' })).error), 'username che inizia con un simbolo rifiutato');
ok(/4 caratteri/.test((await u('register', { username: `x${RUN}`, password: '123' })).error), 'password troppo corta');
const spaced = await u('register', { username: `  Nicolò  D'Ag ${RUN.slice(-3)} `, password: ' pass ' });
ok(spaced.token && spaced.me.username === `Nicolò D'Ag ${RUN.slice(-3)}`, 'username con spazi, accenti e apostrofo (spazi doppi tolti)');
ok((await u('login', { username: `nicolò  d'ag ${RUN.slice(-3)}`, password: 'pass ' })).token, 'login senza maiuscole e con spazio in fondo alla password');
const names = ['Tom', 'Ada', 'Bea', 'Ugo'].map((n) => `${n}${RUN}`);
const S = {};
for (const n of names) { const r = await u('register', { username: n, password: 'segreto1', avatar: 'il-gabibbo', tz: 'Europe/Rome' }); S[n] = r; }
ok(Object.values(S).every((r) => r.token && r.me.rating === 1000), 'quattro account creati, partono da 1000');
ok(/già preso/.test((await u('register', { username: names[0].toUpperCase(), password: 'segreto1' })).error), 'username unico senza differenze di maiuscole');
const [tom, ada, bea, ugo] = names.map((n) => S[n]);
ok((await u('login', { username: names[0], password: 'sbagliata' })).error, 'password sbagliata');
const tom2 = await u('login', { username: names[0].toLowerCase(), password: 'segreto1' });
ok(tom2.token && tom2.token !== tom.token, 'login da un altro telefono');
const rn = await u('rename', { token: ugo.token, username: `Ugo2${RUN}` });
ok(rn.me?.username === `Ugo2${RUN}` && rn.me.canRename === false, 'cambio username una volta');
ok(/amministratore/.test((await u('rename', { token: ugo.token, username: `Ugo3${RUN}` })).error), 'la seconda volta serve l\'admin');
const av = await u('setAvatar', { token: ada.token, avatar: 'jose-mourinho' });
ok(av.me.avatar === 'jose-mourinho', 'cambio avatar');
ok((await u('me', { token: 'falso' })).auth === false, 'sessione falsa rifiutata');

// ---------------------------------------------------------------- presenza e amici
console.log('amici e presenza');
const wsT = await new Sock(`${WSBASE}/api/u/ws?token=${tom.token}`).open();
await wsT.until((m) => m.t === 'hello');
const sr = await u('search', { token: tom.token, q: names[1].slice(0, 5) });
ok(sr.list.some((x) => x.username === names[1]), 'ricerca per username');
await u('friendAdd', { token: tom.token, uid: ada.me.id });
const wsA = await new Sock(`${WSBASE}/api/u/ws?token=${ada.token}`).open();
const hello = await wsA.until((m) => m.t === 'hello');
ok(hello.me.unread >= 1, 'la richiesta di amicizia arriva come notifica in app');
await u('friendAnswer', { token: ada.token, uid: tom.me.id, ok: true });
await wsT.until((m) => m.t === 'notif' && m.n.type === 'friend_ok');
const fl = await u('friends', { token: tom.token });
ok(fl.friends.length === 1 && fl.friends[0].presence === 'online', 'amici reciproci, Ada online');
wsA.send({ t: 'status', game: 'ABCDE' });
await wsT.until((m) => m.t === 'presence' && m.state === 'game');
ok(true, 'stato "in partita" in tempo reale');
wsA.send({ t: 'status', game: null });
await u('friendAdd', { token: tom.token, uid: bea.me.id });
await u('friendAnswer', { token: bea.token, uid: tom.me.id, ok: true });

// ---------------------------------------------------------------- inviti in partita
console.log('inviti');
const room = await post('games', { session: tom.token });
const code = room.data.code;
wsA.send({ t: 'status', game: 'ZZZZZ' });
await sleep(150);
const inv = await u('invite', { token: tom.token, code, uids: [ada.me.id, bea.me.id] });
ok(inv.sent.length === 2, 'l\'invito arriva anche a chi è in un\'altra partita o offline');
wsA.send({ t: 'status', game: null });
await sleep(100);
const inv2 = await u('invite', { token: tom.token, code, uids: [ada.me.id] });
ok(inv2.sent.length === 1, 'invito mandato');
const n = await wsA.until((m) => m.t === 'notif' && m.n.type === 'invite');
const acc = await u('inviteAnswer', { token: ada.token, id: n.n.id, ok: true });
ok(acc.code === code, 'invito accettato: porta alla stanza giusta');
const jA = await post(`games/${code}/join`, { session: ada.token });
const jB = await post(`games/${code}/join`, { session: bea.token });
ok(jA.status === 200 && jB.status === 200, 'Ada e Bea entrano');

// ---------------------------------------------------------------- community
console.log('community');
const cc = await u('cCreate', { token: tom.token, name: `Bar Sport ${RUN}`, descr: 'Il giovedì', public: false });
ok(cc.id, 'community privata creata');
ok(/Esiste già/.test((await u('cCreate', { token: ada.token, name: `bar sport ${RUN}` })).error), 'nome unico');
const cid = cc.id;
const jr = await u('cJoin', { token: ada.token, cid });
ok(jr.requested, 'privata: si chiede di entrare');
const g1 = await u('cGet', { token: tom.token, cid });
ok(g1.requests.length === 1, 'il proprietario vede la richiesta');
await u('cAnswer', { token: tom.token, cid, uid: ada.me.id, ok: true });
await u('cInvite', { token: tom.token, cid, uid: bea.me.id });
ok((await u('cJoin', { token: bea.token, cid })).joined, 'Bea entra con l\'invito');
ok(/Non puoi/.test((await u('cKick', { token: ada.token, cid, uid: bea.me.id })).error), 'un membro non toglie gli altri');
await u('cRole', { token: tom.token, cid, uid: ada.me.id, role: 'admin' });
const g2 = await u('cGet', { token: ada.token, cid });
ok(g2.c.role === 'admin' && g2.members.length === 3, 'Ada admin, tre membri');
ok((await fetch(`${BASE}/api/c/${cid}/history?token=${ugo.token}`)).status === 403, 'chi non è membro non legge la chat');

// chat e menzioni
const cT = await new Sock(`${WSBASE}/api/c/${cid}/ws?token=${tom.token}`).open();
const cA = await new Sock(`${WSBASE}/api/c/${cid}/ws?token=${ada.token}`).open();
await cT.until((m) => m.t === 'history');
cT.send({ t: 'msg', text: `@${names[1]} giochiamo?`, mentions: [ada.me.id, ugo.me.id] });
const got = await cA.until((m) => m.t === 'msg');
ok(got.m.text.includes('giochiamo') && got.m.men.length === 1 && got.m.men[0] === ada.me.id, 'messaggio in tempo reale, menzione solo ai membri');
const mn = await wsA.until((m) => m.t === 'notif' && m.n.type === 'mention');
ok(mn.n.data.mid === got.m.id && mn.n.data.cid === cid, 'la menzione arriva ad Ada con il messaggio giusto');
cT.send({ t: 'msg', text: 'spam' });
const er = await cT.until((m) => m.t === 'error');
ok(/un messaggio alla volta/.test(er.msg), 'anti-spam');
const hist = await (await fetch(`${BASE}/api/c/${cid}/history?token=${bea.token}&around=${got.m.id}`)).json();
ok(hist.msgs.some((x) => x.id === got.m.id), 'si può aprire la chat sul messaggio');

// partita avviata dalla community: messaggio in chat, poi avviso a tutti
const lobby1 = await u('cLobby', { token: tom.token, cid, code });
ok(lobby1.ok, 'partita avviata dalla community');
const lm = await cA.until((m) => m.t === 'msg' && m.m.kind === 'lobby');
ok(lm.m.code === code, 'in chat compare il messaggio con la stanza');
ok(/C'è già una partita/.test((await u('cLobby', { token: ada.token, cid, code })).error), 'una sola partita aperta per community');
ok(/non è più|avvisare/.test((await u('cNotify', { token: ada.token, cid })).error || 'non è più'), 'avvisa solo chi l\'ha avviata');
const call = await u('cNotify', { token: tom.token, cid });
ok(call.ok && call.sent === 2, 'avviso mandato agli altri due membri');
const cn = await wsA.until((m) => m.t === 'notif' && m.n.type === 'call');
ok(cn.n.data.code === code, 'l\'avviso porta alla stanza');
ok(/già avvisato/.test((await u('cNotify', { token: tom.token, cid })).error), 'si avvisa una volta sola per partita');

// ---------------------------------------------------------------- partita classificata
console.log('partita classificata');
const R = {};
for (const [k, id] of [['T', room.data], ['A', jA.data], ['B', jB.data]]) {
  const c = new Sock(`${WSBASE}/api/games/${code}/ws?token=${id.token}`); await c.open(); R[k] = c; c.me = id.playerId;
}
const last = (c) => [...c.msgs].reverse().find((m) => m.t === 'state');
R.A.send({ t: 'lobbyReady', on: true }); R.B.send({ t: 'lobbyReady', on: true });
await sleep(300);
R.T.send({ t: 'start' });
await R.T.until((m) => m.t === 'state' && m.s.phase === 'calling');
const g3 = await u('cGet', { token: ada.token, cid });
ok(!g3.call, 'partita iniziata: la chiamata scade da sola');
const byPid = Object.fromEntries(Object.values(R).map((c) => [c.me, c]));
let guard = 0, readyFor = null;
while (last(R.T).s.phase !== 'finished') {
  if (++guard > 3000) throw new Error('troppe mosse');
  if (guard % 200 === 0) { const x = last(R.T).s; console.log('   …', x.phase, x.round?.n, x.round?.turnId, x.round?.pendingJolly, Object.values(R).map((c) => c.msgs.filter((m) => m.t === 'error').slice(-1).map((m) => m.msg)).join('|')); }
  const s = last(R.T).s, r = s.round;
  if (s.phase === 'roundEnd') { if (readyFor !== r.n) { readyFor = r.n; for (const c of Object.values(R)) if (!s.players.find((p) => p.id === c.me).eliminated) c.send({ t: 'ready' }); } await sleep(120); continue; }
  const actor = r.pendingJolly || r.turnId;
  const c = byPid[actor];
  if (!c) { await sleep(80); continue; }
  const v = last(c).s.round;
  if (!v || (v.pendingJolly || v.turnId) !== actor) { await sleep(40); continue; }
  if (s.phase === 'calling') { let k = 0; if (actor === v.dealerId) { const sum = Object.values(v.calls).reduce((p, q) => p + q, 0); if (v.cards - sum === 0) k = 1; } c.send({ t: 'call', n: k }); }
  else if (v.pendingJolly) c.send({ t: 'jolly', v: 'low' });
  else if (v.cards === 1) c.send({ t: 'play' });
  else { const card = v.hands[actor][0]; c.send({ t: 'play', card, jolly: card === 30 ? 'low' : undefined }); }
  const before = JSON.stringify(s.round?.trick) + s.phase + JSON.stringify(s.round?.calls);
  for (let i = 0; i < 50; i++) { await sleep(30); const x = last(R.T).s; if (JSON.stringify(x.round?.trick) + x.phase + JSON.stringify(x.round?.calls) !== before) break; }
}
await sleep(500);
const pt = await u('profile', { uid: tom.me.id });
const pa = await u('profile', { uid: ada.me.id });
ok(pt.stats.mp.games === 1 && pa.stats.mp.games === 1, 'partita registrata una volta per ciascuno');
const ratings = [pt, pa, await u('profile', { uid: bea.me.id })].map((p) => p.user.rating);
const playedRounds = last(R.T).s.roundNo;
if (playedRounds >= 3) {
  ok(ratings.some((r) => r !== 1000) && Math.abs(ratings.reduce((a, b) => a + b, 0) - 3000) <= 2, `ranking aggiornato a somma costante: ${ratings.join(', ')}`);
  ok(pt.stats.history.length === 1, 'storico del ranking');
} else {
  ok(ratings.every((r) => r === 1000), `partita di soli ${playedRounds} turni: non classificata`);
}
ok(pt.stats.mp.precision != null && pt.stats.mp.calls > 0 && pt.stats.mp.top >= 1 && pt.stats.mp.surv > 0, `statistiche dettagliate: precisione ${pt.stats.mp.precision}%, top ${pt.stats.mp.top}%, ${pt.stats.mp.surv} turni`);
ok(pt.stats.bestRating >= pt.user.rating, 'record di punti');
const lb = await u('leaderboard', { token: tom.token });
if (playedRounds >= 3) ok(lb.list.length >= 3 && lb.me.pos >= 1, 'classifica generale');
else ok((await u('leaderboard', { token: tom.token })).me, 'classifica raggiungibile');

// rivincita
R.A.send({ t: 'rematch' });
const lob = await R.T.until((m) => m.t === 'state' && m.s.phase === 'lobby' && m.s.rematch);
ok(lob.s.rematch.by === R.A.me && lob.s.players.length === 3, 'rivincita: tutti di nuovo in sala con la proposta');

// single player
const sp1 = await u('spResult', { token: bea.token, id: 'g1', won: true, players: 4, rounds: 12 });
const sp2 = await u('spResult', { token: bea.token, id: 'g1', won: true, players: 4, rounds: 12 });
const pb = await u('profile', { uid: bea.me.id });
ok(sp1.ok && sp2.dup && pb.stats.sp.games === 1 && pb.stats.sp.wins === 1, 'single player registrato una volta, fuori dal ranking');

// 3.0: classifica a stagioni
const lb3 = await u('leaderboard', { token: tom.token });
if (playedRounds >= 3) {
  const pts = lb3.list.map((x) => x.pts);
  ok(lb3.season && lb3.name && pts.length >= 3 && pts.every((x) => x >= 0) && Math.max(...pts) > 0 && Math.max(...pts) <= 2, `punti di stagione della partita a 3: ${pts.join(', ')}`);
}
const spd = [];
for (let i = 0; i < 4; i++) spd.push(await u('spResult', { token: bea.token, id: `d${i}`, won: true, place: 1, players: 4, rounds: 9, level: 'difficile' }));
ok(spd[0].pts === 1.5 && spd[2].counted && !spd[3].counted, `single player difficile: +1,5 a vittoria in 4, massimo 3 al giorno (${spd.map((x) => x.pts).join(', ')})`);
const spf = await u('spResult', { token: ada.token, id: 'f1', won: true, place: 1, players: 4, rounds: 9, level: 'facile' });
ok(spf.pts == null, 'single player facile: non conta');
const today = (await u('dailyMonth', { token: bea.token })).today;
const ds1 = await u('dailyStart', { token: bea.token, day: today });
const dl1 = await u('dailyEnd', { token: bea.token, day: today, ok: false });
const ds2 = await u('dailyStart', { token: bea.token, day: today });
ok(ds1.fresh && ds1.attempt === 1 && dl1.left === 2 && ds2.fresh && ds2.attempt === 2, 'sfida del giorno: persa al primo, c\'è il secondo tentativo');
const ds3 = await u('dailyStart', { token: bea.token, day: today });
const ds4 = await u('dailyStart', { token: bea.token, day: today });
ok(ds3.fresh && ds3.attempt === 3 && !ds4.fresh, 'al massimo 3 tentativi');
const de1 = await u('dailyEnd', { token: bea.token, day: today, ok: true });
const de2 = await u('dailyEnd', { token: bea.token, day: today, ok: true });
ok(de1.counted && de1.pts === 2 && !de2.counted, 'sfida superata: +2 una volta sola');
ok((await u('dailyStart', { token: bea.token, day: '2020-01-01' })).error, 'le sfide dei giorni passati non si giocano');
// reazioni vocali: l'admin carica quelle di base, ognuno ne ha 4 (le prime libere se non sceglie)
const adm = (b) => fetch(`${BASE}/api/admin/hub?key=${KEY}`, { method: 'POST', body: JSON.stringify(b) }).then((r) => r.json());
const wav = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=';
const rxIds = [];
for (let i = 0; i < 5; i++) rxIds.push((await adm({ op: 'itemSave', item: { kind: 'emote', name: `Base ${i}`, cond: i === 4 ? 'pts' : 'free', n: i === 4 ? 500 : 0, ord: i + 1 }, asset: wav })).id);
// accessori: spenti finché l'admin non li accende; compaiono solo dove sono posizionati
ok(!(await u('items', { token: bea.token })).items.some((i) => i.kind === 'acc'), 'accessori spenti: i giocatori non li vedono');
const occ = (await adm({ op: 'items' })).items.find((i) => i.id === 'occhiali');
await adm({ op: 'itemSave', item: { ...occ, cond: 'free' } });
await adm({ op: 'place', av: 'tizio', acc: 'occhiali', value: { x: 0.5, y: 0.3, s: 0.4, r: -5, f: 1 } });
await adm({ op: 'place', av: 'caio', acc: 'occhiali', off: true });
await adm({ op: 'accOn', on: true });
const itOn = await u('items', { token: bea.token });
ok(itOn.accOn && itOn.places.tizio.occhiali.f === 1 && itOn.places.caio.occhiali === 0, 'posizioni della tavola arrivano ai giocatori');
const eqa = await u('equip', { token: bea.token, acc: ['occhiali', 'sigaro', 'corona'] });
ok(eqa.me.acc.join() === 'occhiali', 'si indossa solo quello sbloccato (niente corona a mano)');
await adm({ op: 'accOn', on: false });
// regali dall'admin: anche oggetti nascosti (esclusivi), e si tolgono
const excl = (await adm({ op: 'itemSave', item: { kind: 'emote', name: 'Esclusiva', cond: 'free', hidden: true, ord: 50 }, asset: wav })).id;
ok((await u('setRx', { token: bea.token, slot: 3, id: excl })).error, "un oggetto nascosto non si usa senza regalo");
await adm({ op: 'gift', uid: bea.me.id, item: excl, on: true });
const ui1 = await adm({ op: 'userItems', uid: bea.me.id });
ok(ui1.list.find((i) => i.id === excl).gift, "regalo registrato");
ok((await u('items', { token: ada.token })).items.find((i) => i.id === excl)?.excl, "l'esclusiva c'è per tutti (per vederla) ma segnata come esclusiva");
ok(!(await u('items', { token: ada.token })).mine.owned.includes(excl) && (await u('items', { token: bea.token })).mine.owned.includes(excl), 'ce l\'ha solo chi l\'ha ricevuta');
ok((await u('setRx', { token: bea.token, slot: 3, id: excl })).me.rx[3].id === excl, "e la può usare");
await adm({ op: 'gift', uid: bea.me.id, item: excl, on: false });
ok(!(await u('items', { token: bea.token })).mine.owned.includes(excl), 'regalo tolto');
ok(Array.isArray((await u('palmares')).list), 'albo d\'oro delle stagioni');
ok((await u('me', { token: bea.token })).me.acc.length === 0, 'spenti: nessuno li vede addosso');
const me0 = (await u('me', { token: bea.token })).me;
ok(me0.rx.length === 4 && me0.rx.map((r) => r.name).join() === 'Base 0,Base 1,Base 2,Base 3', 'senza scelte: le prime 4 reazioni di base');
ok((await u('setRx', { token: bea.token, slot: 0, id: rxIds[4] })).error, 'una reazione bloccata non si usa');
const r1 = await u('setRx', { token: bea.token, slot: 1, data: wav, name: 'Ciapa!' });
ok(r1.me.rx[1].name === 'Ciapa!' && /^rx-/.test(r1.me.rx[1].id), 'reazione registrata da sé');
const own = r1.me.rx[1].id;
ok((await fetch(`${BASE}/api/asset/${own}?v=1`)).ok, "l'audio si scarica");
const r2 = await u('setRx', { token: bea.token, slot: 1, id: rxIds[3] });
ok(r2.me.rx[1].id === rxIds[3] && !(await fetch(`${BASE}/api/asset/${own}?v=1`)).ok, 'cambiandola, quella registrata si cancella');
ok(r2.me.rx[0].id === rxIds[0] && r2.me.rx[2].id === rxIds[1], 'gli altri posti si riempiono con quelle di base rimaste');

// foto profilo, logo community, statistiche single player per difficoltà, notifiche lette per community
const tiny = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=';
const ph = await u('setPhoto', { token: bea.token, data: tiny });
ok(/^ph-/.test(ph.me.avatar), 'foto profilo come avatar');
const [, puid, pv] = /^ph-(u[0-9a-f]+)-(\d+)$/.exec(ph.me.avatar);
const img = await fetch(`${BASE}/api/uphoto/${puid}?v=${pv}`);
ok(img.ok && /image\/jpeg/.test(img.headers.get('content-type')), 'la foto si scarica');
ok(/Il logo/.test((await u('cLogo', { token: bea.token, cid, data: tiny })).error), 'il logo lo cambia solo chi amministra');
await u('cLogo', { token: tom.token, cid, data: tiny });
const withLogo = await u('cGet', { token: tom.token, cid });
ok(withLogo.c.logo && (await fetch(`${BASE}/api/clogo/${cid}?v=${withLogo.c.logo}`)).ok, 'logo della community');
await u('spResult', { token: bea.token, id: 'g2', won: true, players: 5, rounds: 20, level: 'difficile' });
const pl = await u('profile', { uid: bea.me.id });
ok(pl.stats.spLevels.difficile.wins === 5, 'vittorie single player divise per difficoltà');
const before = (await u('notifs', { token: ada.token })).list.filter((x) => x.data?.cid === cid && ['mention', 'call'].includes(x.type)).length;
await u('notifReadWhere', { token: ada.token, cid, types: ['mention', 'call'] });
const after = (await u('notifs', { token: ada.token })).list.filter((x) => x.data?.cid === cid && ['mention', 'call'].includes(x.type)).length;
ok(before > after && after === 0, 'aprendo la community le sue notifiche diventano lette');

// ---------------------------------------------------------------- admin
console.log('admin');
const ad = await (await fetch(`${BASE}/api/admin/hub?key=${KEY}`, { method: 'POST', body: JSON.stringify({ op: 'users' }) })).json();
ok(ad.list.some((x) => x.username === names[0]), 'l\'admin vede gli utenti');
ok((await fetch(`${BASE}/api/admin/hub?key=sbagliata`, { method: 'POST', body: '{"op":"users"}' })).status === 403, 'senza chiave niente admin');
await fetch(`${BASE}/api/admin/hub?key=${KEY}`, { method: 'POST', body: JSON.stringify({ op: 'setPassword', uid: bea.me.id, password: 'nuova123' }) });
ok((await u('login', { username: names[2], password: 'nuova123' })).token, 'password cambiata dall\'admin');
const games = await (await fetch(`${BASE}/api/admin/hub?key=${KEY}`, { method: 'POST', body: JSON.stringify({ op: 'games' }) })).json();
ok(games.list.some((g) => g.data.code === code && (g.rated || playedRounds < 3)), 'l\'admin vede la partita');
const bk = await fetch(`${BASE}/api/admin/backup?key=${KEY}`);
const bj = await bk.json();
ok(bk.ok && bj.account.users.length >= 4 && Array.isArray(bj.archivio.events), 'backup scaricabile');

// cancellare le partite di un giorno di un account
const today2 = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const dry = await adm({ op: 'delGames', uid: bea.me.id, day: today2, mode: 'sp', dry: true });
const beforeDel = true;
const del = await adm({ op: 'delGames', uid: bea.me.id, day: today2, mode: 'sp' });
const afterDel = true;
ok(dry.count >= 4 && del.removed === dry.count, `partite single player del giorno cancellate (${del.removed})`);
ok((await adm({ op: 'delGames', uid: bea.me.id, day: today2, mode: 'sp', dry: true })).count === 0 && afterDel && beforeDel, 'non ci sono più');
// ---------------------------------------------------------------- 4.0
console.log('4.0');
// chat privata
const dm1 = await u('dmSend', { token: ada.token, uid: tom.me.id, text: 'ciao Tom' });
ok(dm1.msg?.mine, 'messaggio privato mandato');
const tl = await u('dmList', { token: tom.token });
ok(tl.list[0]?.user.id === ada.me.id && tl.list[0].unread === 1, 'Tom vede la conversazione con un non letto');
const tg = await u('dmGet', { token: tom.token, uid: ada.me.id });
ok(tg.msgs.length === 1 && !tg.msgs[0].mine, 'Tom legge il messaggio');
ok((await u('dmList', { token: tom.token })).list[0].unread === 0, 'letto: non letti a zero');
ok((await u('dmGet', { token: ugo.token, uid: ada.me.id })).msgs.length === 0, 'un terzo non vede la conversazione degli altri due');
await u('dmBlock', { token: tom.token, uid: ada.me.id, on: true });
ok(/Non puoi/.test((await u('dmSend', { token: ada.token, uid: tom.me.id, text: 'ehi' })).error), 'bloccato: non può più scrivere');
await u('dmBlock', { token: tom.token, uid: ada.me.id, on: false });
// richiesta password dimenticata
ok((await u('pwRequest', { username: `Ugo2${RUN}`, contact: 'scrivimi su WhatsApp' })).ok, 'richiesta di password dimenticata');
ok((await adm({ op: 'pwRequests' })).list.some((r) => r.uid === ugo.me.id && !r.done), 'arriva all\'admin con l\'account giusto');
// testa a testa, riepilogo, numeri, errori
const pr = await u('profile', { token: tom.token, uid: ada.me.id });
ok(pr.h2h && pr.h2h.games >= 1, `testa a testa (${pr.h2h?.games} partite insieme)`);
const wr = await u('wrapped', { token: tom.token, season: (await u('leaderboard')).season });
ok(wr.mp.games >= 1 && wr.name, 'riepilogo della stagione');
const mt = await adm({ op: 'metrics' });
ok(mt.days.length === 30 && mt.users >= 4, 'numeri da data room');
await u('clientError', { kind: 'audio', msg: 'Prova errore', ua: 'iPhone OS 17_1 Safari' });
ok((await adm({ op: 'errors' })).list.some((e) => e.msg === 'Prova errore' && /iPhone/.test(e.devices[0])), 'errore dal telefono arrivato all\'admin');
// codice del browser e unione di due account
const dup = await u('register', { username: `Dup${RUN}`, password: 'segreto1', dev: 'abcdef0123456789' });
await u('login', { username: `Ugo2${RUN}`, password: 'segreto1', dev: 'abcdef0123456789' });
ok((await adm({ op: 'linked', uid: ugo.me.id })).list.some((x) => x.id === dup.me.id), 'stesso browser: account forse collegati');
const today3 = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Rome', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
await u('dailyStart', { token: dup.token, day: today3 }); await u('dailyEnd', { token: dup.token, day: today3, ok: true });
const dSt = (await u('dailyStart', { token: ugo.token, day: today3 })); if (dSt.fresh) await u('dailyEnd', { token: ugo.token, day: today3, ok: true });
const lbBefore = (await u('leaderboard')).list.find((r) => r.id === ugo.me.id)?.pts || 0;
const mg = await adm({ op: 'merge', keep: ugo.me.id, drop: dup.me.id });
ok(mg.ok, 'account uniti');
const lbAfter = (await u('leaderboard')).list.find((r) => r.id === ugo.me.id)?.pts || 0;
ok(lbAfter === lbBefore, `sfida del giorno fatta con tutti e due: contata una volta (${lbBefore} → ${lbAfter})`);
ok((await u('login', { username: `Dup${RUN}`, password: 'segreto1' })).error, 'l\'account doppio non esiste più');
console.log(`OK: ${checks} controlli superati`);
for (const s of [wsT, wsA, cT, cA, ...Object.values(R)]) s.close();
process.exit(0);
