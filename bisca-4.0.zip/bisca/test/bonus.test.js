import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../public/lib/engine.js';

// mano preparata: 4 giocatori, 5 carte. "me" ha le 5 carte più alte e decide quante prenderne.
function round({ myCall, myTake, lives = 3, others = { a: 0, b: 0, c: 0 } }) {
  const s = E.createGame({ code: 'T', hostId: 'me', hostName: 'Io' });
  for (const id of ['a', 'b', 'c']) E.addPlayer(s, { id, name: id, cpu: { level: 'medio' } });
  E.startGame(s, { rng: () => 0.2 });
  s.order = ['me', 'a', 'b', 'c'];
  for (const p of s.players) p.lives = p.id === 'me' ? lives : 3;
  const r = s.round;
  Object.assign(r, {
    cards: 5, dealerId: 'c', seats: ['me', 'a', 'b', 'c'],
    hands: { me: [...[39, 38, 37, 36, 35].slice(0, myTake), ...[0, 1, 2, 3, 4].slice(0, 5 - myTake)], a: [20, 21, 22, 23, 24], b: [10, 11, 12, 13, 14], c: [5, 6, 7, 8, 9] },
    calls: {}, won: { me: 0, a: 0, b: 0, c: 0 }, turnId: 'me', trick: { leader: 'me', plays: [] }, trickNo: 1,
  });
  E.makeCall(s, 'me', myCall);
  E.makeCall(s, 'a', others.a); E.makeCall(s, 'b', others.b);
  let cc = others.c; if (cc === E.forbiddenCall(s)) cc = cc + 1; E.makeCall(s, 'c', cc);
  // "me" prende le prime myTake mani aprendo forte, poi apre basso e un altro prende
  let taken = 0;
  while (s.phase === 'playing') {
    const t = r.turnId;
    const h = r.hands[t];
    let card;
    if (t === 'me') card = taken < myTake ? Math.max(...h) : Math.min(...h);
    else card = (taken >= myTake && r.trick.plays.length) ? Math.max(...h) : Math.min(...h);
    if (t === 'me' && r.trick.plays.length === 0 && taken >= myTake) {
      // io apro basso; gli altri devono superarmi: chi ha coppe (c) prende con la più alta
    }
    const before = r.trickNo;
    E.playCard(s, t, card);
    if (r.trickNo !== before || s.phase !== 'playing') taken = r.won.me;
  }
  return { s, x: r.results.me, me: s.players.find((p) => p.id === 'me') };
}

for (const n of [3, 4, 5]) {
  test(`chiama ${n} e ne prende ${n}: +1 vita`, () => {
    const { x, me } = round({ myCall: n, myTake: n });
    assert.equal(x.won, n);
    assert.equal(x.bonus3, 1);
    assert.equal(me.lives, 4);
  });
}

test('chiamata da 3 sbagliata: nessun bonus', () => {
  const { x, me } = round({ myCall: 3, myTake: 5 });
  assert.equal(x.won, 5);
  assert.equal(x.bonus3, 0);
  assert.equal(me.lives, 1);
});

test('chiamate basse centrate: niente bonus, niente vite perse', () => {
  const { x, me } = round({ myCall: 5, myTake: 5, lives: 4 });
  assert.equal(me.lives, 5, 'nessun tetto: da 4 a 5');
  const r2 = round({ myCall: 0, myTake: 0 });
  assert.equal(r2.x.bonus3, 0);
  assert.equal(r2.me.lives, 3);
});

test('più giocatori col bonus nello stesso turno, e la vita del primo a zero resta separata', () => {
  const s = E.createGame({ code: 'T', hostId: 'p1', hostName: 'P1' });
  for (const id of ['p2', 'p3', 'p4']) E.addPlayer(s, { id, name: id, cpu: { level: 'medio' } });
  E.startGame(s, { rng: () => 0.2 });
  s.order = ['p1', 'p2', 'p3', 'p4'];
  s.players.find((p) => p.id === 'p4').lives = 1;
  const r = s.round;
  // 8 carte: p1 e p2 prendono 3 a testa? Con 5 carte a testa: p1 ha i 5 denari alti, p2 i 5 denari bassi (senza asso), p3 coppe, p4 bastoni
  Object.assign(r, {
    cards: 5, dealerId: 'p4', seats: ['p1', 'p2', 'p3', 'p4'],
    hands: { p1: [39, 38, 37, 25, 26], p2: [36, 35, 34, 27, 28], p3: [20, 21, 22, 23, 24], p4: [0, 1, 2, 3, 4] },
    calls: {}, won: { p1: 0, p2: 0, p3: 0, p4: 0 }, turnId: 'p1', trick: { leader: 'p1', plays: [] }, trickNo: 1,
  });
  E.makeCall(s, 'p1', 3); E.makeCall(s, 'p2', 3); E.makeCall(s, 'p3', 0); E.makeCall(s, 'p4', 1);
  // p1 apre con i denari alti (3 mani), poi p2 con i suoi (le altre 2 restano a p2 con coppe alte? no: p2 ha 25-28? no)
  while (s.phase === 'playing') {
    const t = r.turnId, h = r.hands[t];
    E.playCard(s, t, Math.max(...h));
  }
  const res = r.results;
  // controllo coerenza: chi centra una chiamata >= 3 ha il bonus, chi no non ce l'ha
  for (const id of r.seats) {
    const x = res[id];
    assert.equal(x.bonus3, x.call >= 3 && x.won === x.call ? 1 : 0, id);
  }
  // p4 aveva 1 vita e chiamava 1 senza prendere: arriva a zero e riceve la vita del primo a zero, separata dal bonus chiamata
  assert.equal(res.p4.won, 0);
  assert.equal(res.p4.zeroBonus, true);
  assert.equal(res.p4.after, 1);
  assert.equal(s.bonusZeroUsed, true);
});
