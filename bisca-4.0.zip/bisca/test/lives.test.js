import test from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../public/lib/lives.js';

const mk = () => L.createTable({ code: 'ABCDE', device: 'own', pub: 'P0', name: 'Thomas', players: ['Giacomo', 'Marco', { name: 'Luca', avatar: 'x' }] });

test('si parte tutti da 3, i ruoli contano', () => {
  const st = mk();
  assert.deepEqual(st.players.map((p) => p.lives), [3, 3, 3]);
  assert.equal(L.roleOf(st, 'own'), 'owner');
  L.touchDevice(st, 'dev2', 'Giacomo vero', 'P2');
  assert.equal(L.apply(st, 'dev2', { t: 'delta', pid: 'p1', d: -1 }), 'Solo chi segna le vite può cambiarle');
  assert.equal(L.apply(st, 'own', { t: 'delta', pid: 'p1', d: -1 }), null);
  assert.equal(st.players[0].lives, 2);
  assert.equal(L.apply(st, 'own', { t: 'admin', pub: 'P2', on: true }), null);
  assert.equal(L.apply(st, 'dev2', { t: 'delta', pid: 'p1', d: -1 }), null);
  assert.equal(st.players[0].lives, 1);
  assert.match(L.apply(st, 'dev2', { t: 'rename', pid: 'p1', name: 'X' }), /Solo chi ha creato/);
});

test('bonus una volta sola, anche a più giocatori, e si può annullare', () => {
  const st = mk();
  for (let i = 0; i < 3; i++) { L.apply(st, 'own', { t: 'delta', pid: 'p1', d: -1 }); L.apply(st, 'own', { t: 'delta', pid: 'p2', d: -1 }); }
  assert.equal(L.apply(st, 'own', { t: 'bonus', pids: ['p1', 'p2'] }), null);
  assert.deepEqual(st.players.slice(0, 2).map((p) => [p.lives, p.bonus]), [[1, true], [1, true]]);
  assert.match(L.apply(st, 'own', { t: 'bonus', pids: ['p3'] }), /già stata presa/);
  L.apply(st, 'own', { t: 'undo' });
  assert.equal(st.bonusUsed, false);
  assert.equal(st.players[0].lives, 0);
  L.apply(st, 'own', { t: 'bonus', pids: ['p1'] });
  L.apply(st, 'own', { t: 'delta', pid: 'p1', d: -1 });
  assert.deepEqual([st.players[0].lives, st.players[0].bonus], [0, false]);
  assert.equal(L.apply(st, 'own', { t: 'delta', pid: 'p1', d: -1 }), null); // già a zero: niente
  assert.equal(st.players[0].lives, 0);
});

test('reclamare tiene il nome, l\'owner non tocca l\'avatar di chi ha reclamato', () => {
  const st = mk();
  L.touchDevice(st, 'dev2', 'Io', 'P2');
  assert.equal(L.apply(st, 'dev2', { t: 'claim', pid: 'p1', avatar: 'gabibbo' }), null);
  const v = L.viewFor(st, 'dev2');
  assert.equal(v.players[0].name, 'Giacomo');
  assert.equal(v.players[0].avatar, 'gabibbo');
  assert.equal(v.players[0].mine, true);
  assert.ok(!JSON.stringify(v).includes('dev2') && !JSON.stringify(v).includes('"own"'), 'mai i codici dei telefoni');
  assert.match(L.apply(st, 'own', { t: 'setAvatar', pid: 'p1', avatar: 'y' }), /da solo/);
  L.touchDevice(st, 'dev3', 'Altro', 'P3');
  assert.match(L.apply(st, 'dev3', { t: 'claim', pid: 'p1' }), /già di qualcun altro/);
  L.apply(st, 'dev2', { t: 'claim', pid: 'p2' });
  assert.equal(st.players[0].claimedBy, null);
  assert.equal(L.apply(st, 'own', { t: 'rename', pid: 'p2', name: 'Marcolino' }), null);
  assert.equal(st.players[1].name, 'Marcolino');
});

test('reset e aggiunte', () => {
  const st = mk();
  L.apply(st, 'own', { t: 'delta', pid: 'p1', d: -1 });
  L.apply(st, 'own', { t: 'addPlayer', name: 'Nuovo' });
  assert.equal(st.players.length, 4);
  L.apply(st, 'own', { t: 'reset' });
  assert.ok(st.players.every((p) => p.lives === 3) && !st.bonusUsed && st.gameNo === 2);
  assert.throws(() => L.createTable({ code: 'X', device: 'd', pub: 'p', players: ['Solo'] }));
});
