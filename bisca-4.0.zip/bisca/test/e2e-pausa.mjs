// Pausa ed emote al tavolo, contro il server locale (npx wrangler dev):  node test/e2e-pausa.mjs
import assert from 'node:assert/strict';

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const WSBASE = BASE.replace(/^http/, 'ws');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let checks = 0;
const ok = (c, m) => { assert.ok(c, m); checks++; console.log('  ✓', m); };
async function post(path, body) {
  const res = await fetch(BASE + '/api/' + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: res.status, data: await res.json() };
}
class Client {
  constructor(ident) { this.ident = ident; this.msg = null; this.emotes = []; this.errors = []; this.waiters = []; }
  get s() { return this.msg?.s; }
  connect() {
    return new Promise((resolve) => {
      this.ws = new WebSocket(`${WSBASE}/api/games/${this.ident.code}/ws?token=${this.ident.token}`);
      this.ws.onmessage = (ev) => {
        const m = JSON.parse(ev.data);
        if (m.t === 'state') { this.msg = m; resolve(this); }
        if (m.t === 'emote') this.emotes.push(m);
        if (m.t === 'error') this.errors.push(m.msg);
        this.waiters = this.waiters.filter((w) => !w());
      };
    });
  }
  until(pred, ms = 15000) {
    if (this.msg && pred()) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('timeout')), ms);
      this.waiters.push(() => { if (pred()) { clearTimeout(t); resolve(); return true; } return false; });
    });
  }
  send(m) { this.ws.send(JSON.stringify(m)); }
}
const RUN = Date.now().toString(36).slice(-5);
const acct = async (n) => (await post('u', { op: 'register', username: `${n}${RUN}`.slice(0, 16), password: 'segreto1' })).data;
const uT = await acct('Pino'), uA = await acct('Lisa');
const h = await post('games', { session: uT.token });
const code = h.data.code;
const a = await post(`games/${code}/join`, { session: uA.token });
const T = await new Client({ ...h.data, code }).connect();
const A = await new Client({ ...a.data, code }).connect();
T.send({ t: 'addCpu', n: 1, level: 'facile' });
await T.until(() => T.s.players.length === 3);
A.send({ t: 'lobbyReady', on: true });
await new Promise((r) => setTimeout(r, 300));
T.send({ t: 'start' });
await T.until(() => T.s.phase === 'calling');

console.log('reazioni');
const WAV = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=';
A.send({ t: 'emote', kind: 'live', data: WAV });
await T.until(() => T.emotes.length === 1);
ok(T.emotes[0].kind === 'live' && T.emotes[0].pid === a.data.playerId, 'la reazione al volo arriva a tutti');
A.send({ t: 'emote', kind: 'live', data: WAV });
await A.until(() => A.errors.length === 1);
ok(T.emotes.length === 1, 'troppo ravvicinata: non parte');
await sleep(3600);
A.send({ t: 'emote', kind: 'live', data: 'data:text/html;base64,AAAA' });
await sleep(300);
ok(T.emotes.length === 1, 'registrazione non valida scartata');

console.log('pausa');
A.send({ t: 'pause' });
await A.until(() => A.errors.length === 2);
ok(!T.msg.pause, "solo chi ha creato la stanza mette la pausa diretta");
A.send({ t: 'pauseReq' });
await T.until(() => T.msg.pause?.req);
ok(T.msg.pause.req.by === a.data.playerId, 'richiesta di pausa arrivata');
T.send({ t: 'pauseVote', yes: false });
await A.until(() => !A.msg.pause);
ok(true, 'un no annulla la richiesta');
A.send({ t: 'pauseReq' });
await T.until(() => T.msg.pause?.req);
T.send({ t: 'pauseVote', yes: true });
await A.until(() => A.msg.pause?.at);
ok(true, 'tutti sì: partita in pausa');
const turnBefore = T.s.round.turnStartedAt;
// durante la pausa non si gioca
const turn = T.s.round.turnId;
const C = turn === h.data.playerId ? T : turn === a.data.playerId ? A : null;
if (C) { C.send({ t: 'call', n: 0 }); await C.until(() => C.errors.length > (C === A ? 2 : 0)); ok(C.s.round.calls[turn] == null, 'in pausa non si chiama'); }
await sleep(1500);
ok(Object.keys(T.s.round.calls).length === Object.keys(A.s.round.calls).length && T.msg.pause?.at, 'la CPU non gioca durante la pausa');
T.send({ t: 'resume' });
await A.until(() => A.msg.pause?.resuming);
ok(true, 'ripresa: si aspetta il Pronto');
T.send({ t: 'pauseReady' });
await sleep(300);
ok(A.msg.pause?.resuming?.ready.length === 1, 'uno pronto, si aspetta ancora');
A.send({ t: 'pauseReady' });
await T.until(() => !T.msg.pause);
ok(T.s.round.turnStartedAt >= turnBefore + 1000, 'si riparte e il tempo del turno non è andato perso');
console.log('chiudere la partita');
// 2 giocatori veri: serve il sì di entrambi (75% di 2 = 2)
A.send({ t: 'closeReq' });
await T.until(() => T.msg.close);
ok(T.msg.close.need === 2 && T.msg.close.voters.length === 2, 'votano solo i giocatori veri (la CPU no)');
T.send({ t: 'closeVote', yes: false });
await A.until(() => !A.msg.close);
ok(A.s.phase !== 'lobby', 'basta un no su due: si continua');
A.send({ t: 'closeReq' });
await T.until(() => T.msg.close);
T.send({ t: 'closeVote', yes: true });
await A.until(() => A.s.phase === 'lobby');
ok(!A.msg.close && A.s.players.length === 3, 'chiusa: tutti in sala d\'attesa, niente classifica');
console.log('pronto e spettatori');
A.send({ t: 'sitOut', on: true });
await T.until(() => T.s.spectators.some((p) => p.id === a.data.playerId));
ok(!T.s.players.some((p) => p.id === a.data.playerId), 'in sala d\'attesa "non gioco questa": diventa spettatore');
A.send({ t: 'lobbyReady', on: true });
await T.until(() => T.s.players.some((p) => p.id === a.data.playerId) && T.s.lobbyReady.includes(a.data.playerId));
ok(true, 'Pronto da spettatore: torna al tavolo');
T.send({ t: 'start' });
await T.until(() => T.s.phase === 'calling');
const uC = await acct('Carla');
const jc = await post(`games/${code}/join`, { session: uC.token, as: 'spectator' });
const Cs = await new Client({ ...jc.data, code }).connect();
Cs.send({ t: 'wantsIn', on: true });
await T.until(() => (T.s.wantsIn || []).includes(jc.data.playerId));
ok(true, 'lo spettatore arrivato tardi si prenota per la prossima');
A.send({ t: 'closeReq' });
await T.until(() => T.msg.close);
T.send({ t: 'closeVote', yes: true });
await T.until(() => T.s.phase === 'lobby');
ok(T.s.spectators.some((p) => p.id === jc.data.playerId), 'a fine partita resta spettatore finché non mette Pronto');
Cs.send({ t: 'lobbyReady', on: true });
await T.until(() => T.s.players.some((p) => p.id === jc.data.playerId));
ok(T.s.lobbyReady.includes(jc.data.playerId), 'con il Pronto entra al tavolo');
console.log(`OK: ${checks} controlli superati`);
process.exit(0);
